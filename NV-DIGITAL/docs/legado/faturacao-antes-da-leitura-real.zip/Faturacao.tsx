import { tenantStorage } from "../../store/tenantStorage";
import { useState, useMemo, useRef, useEffect } from "react";
import { useApp } from "../../store/AppContext";
import { Fatura, LinhaFatura, formatCurrency } from "../../store/storage";
import {
  generateFaturaHTML,
  downloadFatura,
  gerarHashFatura,
  gerarHashFaturaAsync,
} from "../../utils/faturaGenerator";
import { Session } from "../../store/auth";
// 🆕 Import do componente NotasCredito (caminho relativo)
import NotasCreditoPage from "./NotasCredito";
// ═══════════════════════════════════════════════════════════════════════════════
// SEÇÃO 1: FUNÇÕES AUXILIARES
// ═══════════════════════════════════════════════════════════════════════════════
function todayStr() {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}
function addDays(dateStr: string, days: number): string {
  const p = dateStr.split("/");
  if (p.length !== 3) return dateStr;
  const d = new Date(`${p[2]}-${p[1]}-${p[0]}`);
  d.setDate(d.getDate() + days);
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}
function isVencida(dv: string, estado: string) {
  if (estado !== "emitida") return false;
  const p = dv.split("/");
  if (p.length !== 3) return false;
  return new Date(`${p[2]}-${p[1]}-${p[0]}`) < new Date();
}
function diasParaVencimento(dv: string): number {
  const p = dv.split("/");
  if (p.length !== 3) return 0;
  const venc = new Date(`${p[2]}-${p[1]}-${p[0]}`);
  const hoje = new Date();
  const diff = venc.getTime() - hoje.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}
function formatDateLong(dateStr: string): string {
  const meses = [
    "Janeiro",
    "Fevereiro",
    "Março",
    "Abril",
    "Maio",
    "Junho",
    "Julho",
    "Agosto",
    "Setembro",
    "Outubro",
    "Novembro",
    "Dezembro",
  ];
  const p = dateStr.split("/");
  if (p.length !== 3) return dateStr;
  return `${parseInt(p[0])} de ${meses[parseInt(p[1]) - 1]} de ${p[2]}`;
}
function getMesAno(dateStr: string): { mes: number; ano: number } {
  const p = dateStr.split("/");
  if (p.length !== 3) return { mes: 0, ano: 0 };
  return { mes: parseInt(p[1]), ano: parseInt(p[2]) };
}
function nowTimeStr() {
  const n = new Date();
  return `${String(n.getHours()).padStart(2, "0")}:${String(n.getMinutes()).padStart(2, "0")}:${String(n.getSeconds()).padStart(2, "0")}`;
}
function getTimestamp() {
  return new Date().toISOString();
}
function gerarId(): string {
  return Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
}
function emptyLinha(): LinhaFatura {
  return {
    descricao: "",
    quantidade: 1,
    precoUnitario: 0,
    ivaIsento: false,
    unidade: "",
  };
}
// ═══════════════════════════════════════════════════════════════════════════════
// SEÇÃO 2: VALIDAÇÕES
// ═══════════════════════════════════════════════════════════════════════════════
function validarNIF(nif: string): boolean {
  if (!nif) return true;
  const nifLimpo = nif.replace(/\D/g, "");
  return nifLimpo.length === 9 || nifLimpo.length === 14;
}
function validarBI(bi: string): boolean {
  if (!bi) return true;
  const biLimpo = bi.replace(/\s/g, "");
  return /^[A-Za-z0-9]{14}$/.test(biLimpo);
}
function validarPassaporte(passaporte: string): boolean {
  if (!passaporte) return true;
  const passLimpo = passaporte.replace(/[^A-Za-z0-9]/g, "");
  return passLimpo.length >= 6 && passLimpo.length <= 12;
}
function validarEmail(email: string): boolean {
  if (!email) return true;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function validarTelefone(telefone: string): boolean {
  if (!telefone) return true;
  const telLimpo = telefone.replace(/\D/g, "");
  return telLimpo.length >= 9;
}
// ═══════════════════════════════════════════════════════════════════════════════
// SEÇÃO 3: CONSTANTES
// ═══════════════════════════════════════════════════════════════════════════════
const TIPO_DOC_OPTS = [
  { value: "factura", label: "Factura", code: "FT", estadoDefault: "emitida" },
  {
    value: "factura-global",
    label: "Factura Global",
    code: "FG",
    estadoDefault: "emitida",
  },
  {
    value: "pro-forma",
    label: "Pró-Forma",
    code: "PF",
    estadoDefault: "rascunho",
  },
];
const FORMA_PAG_OPTS = [
  "Numerário",
  "Transferência Bancária",
  "Multicaixa Express",
  "Multicaixa (TPA)",
  "Cheque",
  "Crédito",
  "Outro",
];
const FORMA_PAG_ICONS: Record<string, string> = {
  Numerário: "💵",
  "Transferência Bancária": "🏦",
  "Multicaixa Express": "📱",
  "Multicaixa (TPA)": "💳",
  Cheque: "📝",
  Crédito: "📅",
  Outro: "💰",
};
const ESTADO_CORES: Record<string, { bg: string; text: string; dot: string }> =
  {
    rascunho: {
      bg: "bg-amber-50",
      text: "text-amber-700",
      dot: "bg-amber-400",
    },
    emitida: { bg: "bg-blue-50", text: "text-blue-700", dot: "bg-blue-500" },
    paga: {
      bg: "bg-emerald-50",
      text: "text-emerald-700",
      dot: "bg-emerald-500",
    },
    anulada: { bg: "bg-red-50", text: "text-red-600", dot: "bg-red-400" },
  };
const ESTADO_LABEL: Record<string, string> = {
  rascunho: "Rascunho",
  emitida: "Emitida",
  paga: "Paga",
  anulada: "Anulada",
};
const TIPO_LABEL: Record<string, string> = {
  factura: "Factura",
  "factura-recibo": "Factura-Recibo",
  "factura-global": "Factura Global",
  "pro-forma": "Pró-Forma",
  "nota-credito": "Nota de Crédito",
};
const TIPO_AVATAR: Record<string, { code: string; bg: string }> = {
  factura: { code: "FT", bg: "bg-[#00AEEF]" },
  "factura-recibo": { code: "FR", bg: "bg-teal-500" },
  "factura-global": { code: "FG", bg: "bg-violet-500" },
  "pro-forma": { code: "PF", bg: "bg-amber-500" },
  "nota-credito": { code: "NC", bg: "bg-orange-500" },
};
const MESES = [
  "Janeiro",
  "Fevereiro",
  "Março",
  "Abril",
  "Maio",
  "Junho",
  "Julho",
  "Agosto",
  "Setembro",
  "Outubro",
  "Novembro",
  "Dezembro",
];
const PROVINCIAS_ANGOLA = [
  "Bengo",
  "Benguela",
  "Bié",
  "Cabinda",
  "Cuando Cubango",
  "Cuanza Norte",
  "Cuanza Sul",
  "Cunene",
  "Huambo",
  "Huíla",
  "Luanda",
  "Lunda Norte",
  "Lunda Sul",
  "Malanje",
  "Moxico",
  "Namibe",
  "Uíge",
  "Zaire",
];
// ═══════════════════════════════════════════════════════════════════════════════
// 🆕 SEÇÃO 3B: CONSTANTES DO POS EXPANDIDO
// ═══════════════════════════════════════════════════════════════════════════════
const POS_CATEGORIA_ICONS: Record<string, string> = {
  Serviços: "🛠️",
  Medicamentos: "💊",
  Exames: "🧪",
  Consultas: "🩺",
  Internamento: "🏥",
  Urgências: "🚑",
  Vacinas: "💉",
  Hematologia: "🩸",
  Bioquímica: "🧬",
  Urinálise: "🧫",
  Parasitologia: "🔬",
  Sorologia: "🦠",
  Pacotes: "📦",
  Geral: "📋",
  "Sem Categoria": "📁",
};
const POS_ATALHOS_TECLADO = [
  { tecla: "F1", acao: "favoritos", label: "Favoritos", icon: "⭐" },
  { tecla: "F2", acao: "recentes", label: "Recentes", icon: "🕐" },
  { tecla: "F3", acao: "promocoes", label: "Promoções", icon: "🏷️" },
  { tecla: "F4", acao: "populares", label: "Populares", icon: "🔥" },
  { tecla: "F5", acao: "stock_baixo", label: "Stock Baixo", icon: "⚠️" },
  { tecla: "F6", acao: "todos", label: "Todos", icon: "📦" },
];
// ═══════════════════════════════════════════════════════════════════════════════
// SEÇÃO 4: TIPOS
// ═══════════════════════════════════════════════════════════════════════════════
interface TemplateFatura {
  id: string;
  nome: string;
  descricao?: string;
  tipoDocumento: string;
  linhas: LinhaFatura[];
  observacoes?: string;
  criadoEm: string;
  usadoCount: number;
  categoria?: string;
}
interface NotificacaoItem {
  id: string;
  tipo: "vencimento" | "stock" | "pagamento" | "sistema" | "info";
  titulo: string;
  mensagem: string;
  data: string;
  hora: string;
  lida: boolean;
  faturaId?: number;
  produtoId?: number;
}
interface LogAuditoria {
  id: string;
  timestamp: string;
  usuario: string;
  acao: string;
  modulo: string;
  detalhes: string;
}
interface ConfigSistema {
  nomeClinica: string;
  nif: string;
  endereco: string;
  telefone: string;
  email: string;
  serie: string;
  moeda: string;
  ivaTaxa: number;
  tema: "claro" | "escuro";
  autoSalvar: boolean;
  alertasStock: boolean;
  alertasVencimento: boolean;
  diasAlertaVencimento: number;
  imprimirAutomatico: boolean;
  backupAutomatico: boolean;
}
interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: string;
  attachments?: { type: string; url: string; name: string }[];
}
interface DadosExtraidosBI {
  nome?: string;
  bi?: string;
  dataNascimento?: string;
  sexo?: string;
  naturalidade?: string;
  filiacao?: string;
  endereco?: string;
  foto?: string;
}
interface FormaPagamentoItem {
  id: string;
  forma: string;
  valor: number;
  valorRecebido?: number;
  referencia?: string;
}
// ═══════════════════════════════════════════════════════════════════════════════
// 🆕 SEÇÃO 4B: TIPOS DO POS EXPANDIDO
// ═══════════════════════════════════════════════════════════════════════════════
interface ProdutoFavorito {
  produtoId: number;
  adicionadoEm: string;
  ordem: number;
}
interface ItemCarrinhoPOS {
  produtoId: number;
  nome: string;
  codigo?: string;
  preco: number;
  quantidade: number;
  ivaIsento: boolean;
  desconto: number;
  adicionadoEm: string;
}
interface ProdutoRecente {
  produtoId: number;
  ultimaVezUsado: string;
  vezesUsado: number;
}
interface PromocaoProduto {
  id: string;
  produtoId?: number;
  categoria?: string;
  nome: string;
  desconto: number;
  dataInicio: string;
  dataFim: string;
  ativa: boolean;
}
type POSFiltroRapido =
  | "todos"
  | "favoritos"
  | "recentes"
  | "promocoes"
  | "populares"
  | "stock_baixo";
type POSOrdenacao =
  | "nome"
  | "preco_asc"
  | "preco_desc"
  | "popularidade"
  | "recentes";
// ═══════════════════════════════════════════════════════════════════════════════
// SEÇÃO 5: COMPONENTES UI
// ═══════════════════════════════════════════════════════════════════════════════
function FTAvatar({ tipo }: { tipo?: string }) {
  const cfg = TIPO_AVATAR[tipo ?? "factura"] ?? TIPO_AVATAR["factura"];
  return (
    <div
      className={`w-10 h-10 rounded-full ${cfg.bg} flex items-center justify-center flex-shrink-0 shadow-sm`}
    >
      <span className="text-white text-xs font-black tracking-tight">
        {cfg.code}
      </span>
    </div>
  );
}
function Toast({
  message,
  type,
  onClose,
}: {
  message: string;
  type: "success" | "error" | "info" | "warning";
  onClose: () => void;
}) {
  useEffect(() => {
    const timer = setTimeout(onClose, 4000);
    return () => clearTimeout(timer);
  }, [onClose]);
  const config = {
    success: { bg: "bg-emerald-500", icon: "✓" },
    error: { bg: "bg-red-500", icon: "✕" },
    info: { bg: "bg-blue-500", icon: "ℹ" },
    warning: { bg: "bg-amber-500", icon: "⚠" },
  };
  const cfg = config[type];
  return (
    <div
      className={`fixed top-4 right-4 ${cfg.bg} text-white px-6 py-3 rounded-lg shadow-2xl z-[200] flex items-center gap-3 animate-slide-in min-w-[300px]`}
    >
      <span className="text-xl font-bold">{cfg.icon}</span>
      <span className="text-sm font-medium flex-1">{message}</span>
      <button
        onClick={onClose}
        className="ml-2 text-white/70 hover:text-white text-lg"
      >
        ×
      </button>
    </div>
  );
}
function ModalWrapper({
  title,
  subtitle,
  onClose,
  children,
  size = "md",
}: {
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: React.ReactNode;
  size?: "sm" | "md" | "lg" | "xl" | "full";
}) {
  const sizeClasses = {
    sm: "max-w-md",
    md: "max-w-lg",
    lg: "max-w-3xl",
    xl: "max-w-5xl",
    full: "max-w-6xl",
  };
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 animate-fade-in">
      <div
        className={`bg-white rounded-2xl shadow-2xl w-full ${sizeClasses[size]} max-h-[90vh] flex flex-col`}
      >
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between flex-shrink-0">
          <div>
            <h3 className="font-bold text-lg text-gray-800">{title}</h3>
            {subtitle && (
              <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 w-8 h-8 flex items-center justify-center rounded hover:bg-gray-100 text-lg"
          >
            ×
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}
function StatCard({
  icon,
  label,
  value,
  sublabel,
  color,
}: {
  icon: string;
  label: string;
  value: string;
  sublabel?: string;
  color: string;
}) {
  return (
    <div
      className={`bg-gradient-to-br ${color} text-white rounded-xl p-4 shadow-lg`}
    >
      <div className="flex items-center justify-between mb-2">
        <div className="text-xs opacity-80">{label}</div>
        <div className="text-2xl">{icon}</div>
      </div>
      <div className="text-2xl font-black">{value}</div>
      {sublabel && <div className="text-xs opacity-80 mt-1">{sublabel}</div>}
    </div>
  );
}
function Badge({
  children,
  color = "gray",
}: {
  children: React.ReactNode;
  color?: string;
}) {
  const colors: Record<string, string> = {
    gray: "bg-gray-100 text-gray-700",
    blue: "bg-blue-100 text-blue-700",
    green: "bg-emerald-100 text-emerald-700",
    red: "bg-red-100 text-red-700",
    amber: "bg-amber-100 text-amber-700",
    violet: "bg-violet-100 text-violet-700",
    teal: "bg-teal-100 text-teal-700",
    orange: "bg-orange-100 text-orange-700",
    purple: "bg-purple-100 text-purple-700",
  };
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full text-xs px-2 py-0.5 font-semibold ${colors[color]}`}
    >
      {children}
    </span>
  );
}
// ═══════════════════════════════════════════════════════════════════════════════
// 🆕 SEÇÃO 5B: SUBCOMPONENTES DO POS EXPANDIDO
// ═══════════════════════════════════════════════════════════════════════════════
function POSProdutoCard({
  produto,
  moeda,
  ivaTaxaDefault,
  onAdd,
  onQuickAdd,
  onFavoritar,
  isFavorito,
  promocao,
  tamanho = "medio",
  atalhoNumero,
}: {
  produto: any;
  moeda: string;
  ivaTaxaDefault: number;
  onAdd: () => void;
  onQuickAdd: () => void;
  onFavoritar: () => void;
  isFavorito: boolean;
  promocao?: PromocaoProduto;
  tamanho?: "pequeno" | "medio" | "grande";
  atalhoNumero?: number;
}) {
  const precoComDesconto =
    promocao && promocao.ativa
      ? produto.preco * (1 - promocao.desconto / 100)
      : produto.preco;
  const tamanhoClasses = {
    pequeno: "p-2",
    medio: "p-3",
    grande: "p-4",
  };
  return (
    <div
      className={`group relative bg-white border border-gray-200 rounded-xl hover:border-[#00AEEF] hover:shadow-lg transition-all text-left overflow-hidden ${tamanhoClasses[tamanho]}`}
    >
      {promocao && promocao.ativa && (
        <div className="absolute top-0 right-0 bg-gradient-to-br from-red-500 to-orange-500 text-white text-[10px] font-black px-2 py-0.5 rounded-bl-lg shadow-md z-10">
          -{promocao.desconto}%
        </div>
      )}
      {atalhoNumero !== undefined && (
        <div className="absolute top-1 left-1 bg-gray-800 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center z-10 opacity-60 group-hover:opacity-100 transition">
          {atalhoNumero}
        </div>
      )}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onFavoritar();
        }}
        className={`absolute top-1 right-1 w-6 h-6 rounded-full flex items-center justify-center transition-all z-10 ${
          isFavorito
            ? "bg-amber-400 text-white shadow-md scale-100"
            : "bg-white/80 text-gray-300 hover:text-amber-400 opacity-0 group-hover:opacity-100"
        }`}
        title={isFavorito ? "Remover dos favoritos" : "Adicionar aos favoritos"}
      >
        ★
      </button>
      <div className="w-full aspect-square max-h-20 rounded-lg bg-gradient-to-br from-[#00AEEF]/15 to-[#00AEEF]/5 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
        <span className="text-2xl">
          {POS_CATEGORIA_ICONS[produto.categoria || "Sem Categoria"] || "📦"}
        </span>
      </div>
      <div
        className="text-xs font-bold text-gray-800 truncate group-hover:text-[#00AEEF] transition-colors mb-0.5"
        title={produto.nome}
      >
        {produto.nome}
      </div>
      {produto.codigo && (
        <div className="text-[9px] text-gray-400 font-mono truncate mb-1">
          {produto.codigo}
        </div>
      )}
      <div className="flex items-baseline gap-1 mb-1.5">
        {promocao && promocao.ativa ? (
          <>
            <span className="text-sm font-black text-red-600">
              {formatCurrency(precoComDesconto, moeda)}
            </span>
            <span className="text-[10px] text-gray-400 line-through">
              {formatCurrency(produto.preco, moeda)}
            </span>
          </>
        ) : (
          <span className="text-sm font-black text-[#00AEEF]">
            {formatCurrency(produto.preco, moeda)}
          </span>
        )}
      </div>
      <div className="flex items-center justify-between text-[9px] mb-2">
        {produto.ivaIsento ? (
          <span className="bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded">
            s/IVA
          </span>
        ) : (
          <span className="bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded">
            {ivaTaxaDefault}%
          </span>
        )}
        <span
          className={`px-1.5 py-0.5 rounded ${
            produto.stock <= (produto.stockMinimo || 0)
              ? "bg-red-100 text-red-700"
              : produto.stock <= (produto.stockMinimo || 0) * 2
                ? "bg-amber-100 text-amber-700"
                : "bg-emerald-50 text-emerald-600"
          }`}
        >
          {produto.stock || 0} un
        </span>
      </div>
      <div className="flex gap-1">
        <button
          type="button"
          onClick={onQuickAdd}
          className="flex-1 bg-[#00AEEF] text-white text-[10px] font-bold py-1.5 rounded hover:bg-[#0099d4] transition flex items-center justify-center gap-1"
        >
          + Adicionar
        </button>
        <button
          type="button"
          onClick={onAdd}
          className="w-7 bg-gray-100 text-gray-600 text-[10px] font-bold py-1.5 rounded hover:bg-gray-200 transition flex items-center justify-center"
          title="Adicionar com opções"
        >
          ⚙
        </button>
      </div>
    </div>
  );
}
function POSCarrinhoItem({
  item,
  moeda,
  onUpdateQtd,
  onRemove,
  onDesconto,
}: {
  item: ItemCarrinhoPOS;
  moeda: string;
  onUpdateQtd: (qtd: number) => void;
  onRemove: () => void;
  onDesconto: (desc: number) => void;
}) {
  const subtotal = item.preco * item.quantidade;
  const descontoValor = subtotal * (item.desconto / 100);
  const total = subtotal - descontoValor;
  return (
    <div className="bg-white border border-gray-200 rounded-lg p-2 hover:border-[#00AEEF]/50 transition group">
      <div className="flex items-start gap-2">
        <div className="flex-1 min-w-0">
          <div className="text-xs font-bold text-gray-800 truncate">
            {item.nome}
          </div>
          {item.codigo && (
            <div className="text-[9px] text-gray-400 font-mono">
              {item.codigo}
            </div>
          )}
          <div className="text-[10px] text-gray-500 mt-0.5">
            {formatCurrency(item.preco, moeda)} × {item.quantidade}
            {item.desconto > 0 && (
              <span className="text-red-500 ml-1">(-{item.desconto}%)</span>
            )}
          </div>
        </div>
        <div className="text-right flex-shrink-0">
          <div className="text-xs font-black text-[#00AEEF]">
            {formatCurrency(total, moeda)}
          </div>
          {item.desconto > 0 && (
            <div className="text-[9px] text-red-500 line-through">
              {formatCurrency(subtotal, moeda)}
            </div>
          )}
        </div>
      </div>
      <div className="flex items-center gap-1 mt-2">
        <button
          type="button"
          onClick={() => onUpdateQtd(Math.max(1, item.quantidade - 1))}
          className="w-5 h-5 rounded bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-bold flex items-center justify-center transition"
        >
          −
        </button>
        <input
          type="number"
          value={item.quantidade}
          onChange={(e) => onUpdateQtd(Math.max(1, Number(e.target.value)))}
          className="w-10 text-center text-xs border border-gray-200 rounded py-0.5 focus:outline-none focus:border-[#00AEEF]"
        />
        <button
          type="button"
          onClick={() => onUpdateQtd(item.quantidade + 1)}
          className="w-5 h-5 rounded bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-bold flex items-center justify-center transition"
        >
          +
        </button>
        <div className="flex-1" />
        <button
          type="button"
          onClick={() => {
            const novoDesc = prompt("Desconto (%):", String(item.desconto));
            if (novoDesc !== null) {
              const v = Math.max(0, Math.min(100, Number(novoDesc) || 0));
              onDesconto(v);
            }
          }}
          className="w-5 h-5 rounded bg-amber-50 hover:bg-amber-100 text-amber-600 text-[10px] font-bold flex items-center justify-center transition"
          title="Aplicar desconto"
        >
          %
        </button>
        <button
          type="button"
          onClick={onRemove}
          className="w-5 h-5 rounded bg-red-50 hover:bg-red-100 text-red-500 text-[10px] font-bold flex items-center justify-center transition"
          title="Remover"
        >
          ×
        </button>
      </div>
    </div>
  );
}
// ═══════════════════════════════════════════════════════════════════════════════
// SEÇÃO 6: COMPONENTE PRINCIPAL
// ═══════════════════════════════════════════════════════════════════════════════
export default function Faturacao({ session }: { session: Session }) {
  const {
    data,
    addFatura,
    updateFatura,
    removeFatura,
    addMovimento,
    addProduto,
    addPaciente,
    updateProduto,
    updatePaciente,
  } = useApp();
  const produtos = (data.produtos ?? []).filter((p) => p.ativo);
  const todosProdutos = data.produtos ?? [];
  const moeda = data.config.moeda || "AOA";
  const ivaTaxaDefault = data.config.ivaTaxa || 14;
  const hoje = todayStr();
  const [view, setView] = useState<"lista" | "form">("lista");
  const [editId, setEditId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [filtroEstado, setFiltroEstado] = useState("todos");
  const [filtroTipo, setFiltroTipo] = useState("todos");
  const [filtroData, setFiltroData] = useState("");
  const [clienteNome, setClienteNome] = useState("");
  const [clienteNif, setClienteNif] = useState("");
  const [clienteEndereco, setClienteEndereco] = useState("");
  const [pacienteId, setPacienteId] = useState("");
  const [linhas, setLinhas] = useState<LinhaFatura[]>([]);
  const [observacoes, setObservacoes] = useState("");
  const [refExterna, setRefExterna] = useState("");
  const [estado, setEstado] = useState<Fatura["estado"]>("emitida");
  const [dataEmissao, setDataEmissao] = useState(hoje);
  const [dataVenc, setDataVenc] = useState(addDays(hoje, 30));
  const [ivaTaxa, setIvaTaxa] = useState(ivaTaxaDefault);
  const [desconto, setDesconto] = useState(0);
  const [tipoDocumento, setTipoDocumento] = useState("factura");
  const [formasPagamento, setFormasPagamento] = useState<FormaPagamentoItem[]>(
    [],
  );
  const [formaPagamento, setFormaPagamento] = useState("");
  const [valorRecebido, setValorRecebido] = useState<number | "">(0);
  const [usarMultiplasFormas, setUsarMultiplasFormas] = useState(false);
  const [produtoSearch, setProdutoSearch] = useState("");
  const [produtoQtd, setProdutoQtd] = useState(1);
  const [showDropdown, setShowDropdown] = useState(false);
  const [showRascunhos, setShowRascunhos] = useState(true);
  const [dropdownIndex, setDropdownIndex] = useState(-1);
  const [showProdutosPanel, setShowProdutosPanel] = useState(false);
  const [catalogSearch, setCatalogSearch] = useState("");
  const [catalogCat, setCatalogCat] = useState<string | null>(null);
  const [catalogViewMode, setCatalogViewMode] = useState<"grid" | "list">(
    "grid",
  );
  const [nifError, setNifError] = useState("");
  const [facturaPremiada, setFacturaPremiada] = useState(false);
  const [ncModal, setNcModal] = useState<{ fatura: Fatura } | null>(null);
  const [ncMotivo, setNcMotivo] = useState("");
  const [reciboModal, setReciboModal] = useState<{ fatura: Fatura } | null>(
    null,
  );
  const [reciboFormaPag, setReciboFormaPag] = useState("");
  const [showNovoProduto, setShowNovoProduto] = useState(false);
  const [editandoProdutoId, setEditandoProdutoId] = useState<number | null>(
    null,
  );
  const [novoProduto, setNovoProduto] = useState({
    nome: "",
    codigo: "",
    preco: 0,
    categoria: "",
    ivaIsento: false,
    descricao: "",
    stock: 0,
    stockMinimo: 0,
  });
  const [novoProdutoError, setNovoProdutoError] = useState("");
  const [salvandoProduto, setSalvandoProduto] = useState(false);
  const [showNovoCliente, setShowNovoCliente] = useState(false);
  const [editandoClienteId, setEditandoClienteId] = useState<number | null>(
    null,
  );
  const [novoCliente, setNovoCliente] = useState({
    nome: "",
    nif: "",
    bi: "",
    passaporte: "",
    telefone: "",
    email: "",
    endereco: "",
    observacoes: "",
    tipoDocumento: "nif",
  });
  const [novoClienteError, setNovoClienteError] = useState("");
  const [salvandoCliente, setSalvandoCliente] = useState(false);
  const [showGestaoProdutos, setShowGestaoProdutos] = useState(false);
  const [showGestaoClientes, setShowGestaoClientes] = useState(false);
  const [gestaoSearch, setGestaoSearch] = useState("");
  const [gestaoCat, setGestaoCat] = useState<string | null>(null);
  const [showDashboard, setShowDashboard] = useState(false);
  const [showDetalhesCliente, setShowDetalhesCliente] = useState<{
    clienteId: number;
  } | null>(null);
  const [showDetalhesProduto, setShowDetalhesProduto] = useState<{
    produtoId: number;
  } | null>(null);
  const [showRelatorios, setShowRelatorios] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [showLogs, setShowLogs] = useState(false);
  const [showNotificacoes, setShowNotificacoes] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [showNotasCreditoPage, setShowNotasCreditoPage] = useState(false);
  const [relatorioTipo, setRelatorioTipo] = useState<
    "resumo" | "iva" | "clientes" | "produtos" | "pagamentos" | "vencidos"
  >("resumo");
  const [relatorioPeriodo, setRelatorioPeriodo] = useState<
    "dia" | "semana" | "mes" | "trimestre" | "ano" | "personalizado"
  >("mes");
  const [relatorioDataInicio, setRelatorioDataInicio] = useState("");
  const [relatorioDataFim, setRelatorioDataFim] = useState("");
  const [templates, setTemplates] = useState<TemplateFatura[]>(() => {
    try {
      const saved = tenantStorage.getItem("templates_fatura");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [showNovoTemplate, setShowNovoTemplate] = useState(false);
  const [templateEditando, setTemplateEditando] =
    useState<TemplateFatura | null>(null);
  const [templateForm, setTemplateForm] = useState<TemplateFatura>({
    id: "",
    nome: "",
    descricao: "",
    tipoDocumento: "factura",
    linhas: [],
    observacoes: "",
    criadoEm: hoje,
    usadoCount: 0,
    categoria: "Geral",
  });
  const [logs, setLogs] = useState<LogAuditoria[]>(() => {
    try {
      const saved = tenantStorage.getItem("logs_auditoria");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [logFiltro, setLogFiltro] = useState<
    "todos" | "faturas" | "produtos" | "clientes" | "sistema"
  >("todos");
  const [notificacoes, setNotificacoes] = useState<NotificacaoItem[]>([]);
  const [configForm, setConfigForm] = useState<ConfigSistema>({
    nomeClinica: data.config.nomeClinica || "",
    nif: data.config.nif || "",
    endereco: data.config.endereco || "",
    telefone: data.config.telefone || "",
    email: data.config.email || "",
    serie: data.config.serie || "A",
    moeda: data.config.moeda || "AOA",
    ivaTaxa: data.config.ivaTaxa || 14,
    tema: "claro",
    autoSalvar: true,
    alertasStock: true,
    alertasVencimento: true,
    diasAlertaVencimento: 7,
    imprimirAutomatico: false,
    backupAutomatico: true,
  });
  const [showChat, setShowChat] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: gerarId(),
      role: "assistant",
      content:
        "Olá! Sou seu assistente inteligente. Posso ajudar com:\n• 📄 Faturar\n• 🔍 Localizar cliente ou produto\n• 👤 Criar cliente\n• 📦 Criar produto\n• 📊 Dashboard e relatórios\nComo posso ajudar?",
      timestamp: nowTimeStr(),
    },
  ]);
  const [chatInput, setChatInput] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadTipo, setUploadTipo] = useState<"cliente" | "produto">(
    "cliente",
  );
  const [uploadArquivo, setUploadArquivo] = useState<File | null>(null);
  const [uploadPreview, setUploadPreview] = useState<string>("");
  const [uploadExtraindo, setUploadExtraindo] = useState(false);
  const [uploadDadosExtraidos, setUploadDadosExtraidos] = useState<any>(null);
  const recognitionRef = useRef<any>(null);
  const [toast, setToast] = useState<{
    message: string;
    type: "success" | "error" | "info" | "warning";
  } | null>(null);
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);
  const [cancelAction, setCancelAction] = useState<() => void>(() => {});
  const [confirmModal, setConfirmModal] = useState<{
    title: string;
    message: string;
    onConfirm: () => void;
    confirmText?: string;
    cancelText?: string;
    type?: "warning" | "danger" | "info";
  } | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [posFiltroRapido, setPosFiltroRapido] =
    useState<POSFiltroRapido>("todos");
  const [posOrdenacao, setPosOrdenacao] = useState<POSOrdenacao>("nome");
  const [posTamanhoCard, setPosTamanhoCard] = useState<
    "pequeno" | "medio" | "grande"
  >("medio");
  const [posFavoritos, setPosFavoritos] = useState<ProdutoFavorito[]>(() => {
    try {
      const saved = tenantStorage.getItem("pos_favoritos");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [posRecentes, setPosRecentes] = useState<ProdutoRecente[]>(() => {
    try {
      const saved = tenantStorage.getItem("pos_recentes");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [posCarrinho, setPosCarrinho] = useState<ItemCarrinhoPOS[]>([]);
  const [posShowCarrinho, setPosShowCarrinho] = useState(true);
  const [posBarcodeInput, setPosBarcodeInput] = useState("");
  const [posShowDetalhesProduto, setPosShowDetalhesProduto] = useState<
    number | null
  >(null);
  const [posPromocoes, setPosPromocoes] = useState<PromocaoProduto[]>(() => {
    try {
      const saved = tenantStorage.getItem("pos_promocoes");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [posPrecoIntervalo, setPosPrecoIntervalo] = useState<[number, number]>([
    0, 1000000,
  ]);
  const [posMostrarSemStock, setPosMostrarSemStock] = useState(true);
  const [posModoCaixa, setPosModoCaixa] = useState(false);
  const posBarcodeRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    try {
      tenantStorage.setItem("pos_favoritos", JSON.stringify(posFavoritos));
    } catch {}
  }, [posFavoritos]);
  useEffect(() => {
    try {
      tenantStorage.setItem("pos_recentes", JSON.stringify(posRecentes));
    } catch {}
  }, [posRecentes]);
  useEffect(() => {
    try {
      tenantStorage.setItem("pos_promocoes", JSON.stringify(posPromocoes));
    } catch {}
  }, [posPromocoes]);
  function toggleFavorito(produtoId: number) {
    setPosFavoritos((prev) => {
      const existe = prev.find((f) => f.produtoId === produtoId);
      if (existe) {
        return prev.filter((f) => f.produtoId !== produtoId);
      }
      return [
        ...prev,
        {
          produtoId,
          adicionadoEm: getTimestamp(),
          ordem: prev.length,
        },
      ].sort((a, b) => a.ordem - b.ordem);
    });
  }
  function registrarUsoRecente(produtoId: number) {
    setPosRecentes((prev) => {
      const existe = prev.find((r) => r.produtoId === produtoId);
      let novos: ProdutoRecente[];
      if (existe) {
        novos = prev.map((r) =>
          r.produtoId === produtoId
            ? {
                ...r,
                ultimaVezUsado: getTimestamp(),
                vezesUsado: r.vezesUsado + 1,
              }
            : r,
        );
      } else {
        novos = [
          { produtoId, ultimaVezUsado: getTimestamp(), vezesUsado: 1 },
          ...prev,
        ];
      }
      return novos.slice(0, 20);
    });
  }
  function adicionarAoCarrinhoPOS(produto: any, quantidade: number = 1) {
    setPosCarrinho((prev) => {
      const existe = prev.find((i) => i.produtoId === produto.id);
      if (existe) {
        return prev.map((i) =>
          i.produtoId === produto.id
            ? { ...i, quantidade: i.quantidade + quantidade }
            : i,
        );
      }
      return [
        ...prev,
        {
          produtoId: produto.id,
          nome: produto.nome,
          codigo: produto.codigo,
          preco: produto.preco,
          quantidade,
          ivaIsento: !!produto.ivaIsento,
          desconto: 0,
          adicionadoEm: getTimestamp(),
        },
      ];
    });
    registrarUsoRecente(produto.id);
    setToast({
      message: `${produto.nome} adicionado ao carrinho`,
      type: "success",
    });
  }
  function atualizarQtdCarrinho(produtoId: number, qtd: number) {
    setPosCarrinho((prev) =>
      prev.map((i) =>
        i.produtoId === produtoId ? { ...i, quantidade: qtd } : i,
      ),
    );
  }
  function removerDoCarrinho(produtoId: number) {
    setPosCarrinho((prev) => prev.filter((i) => i.produtoId !== produtoId));
  }
  function aplicarDescontoCarrinho(produtoId: number, desc: number) {
    setPosCarrinho((prev) =>
      prev.map((i) =>
        i.produtoId === produtoId ? { ...i, desconto: desc } : i,
      ),
    );
  }
  function transferirCarrinhoParaFatura() {
    if (posCarrinho.length === 0) {
      setToast({ message: "Carrinho vazio", type: "warning" });
      return;
    }
    const novasLinhas: LinhaFatura[] = posCarrinho.map((item) => {
      const precoComDesconto = item.preco * (1 - item.desconto / 100);
      return {
        descricao: item.nome,
        quantidade: item.quantidade,
        precoUnitario: precoComDesconto,
        ivaIsento: item.ivaIsento,
        unidade: "",
      };
    });
    setLinhas((prev) => [...prev, ...novasLinhas]);
    setPosCarrinho([]);
    setToast({
      message: `${novasLinhas.length} item(s) transferido(s) para a fatura`,
      type: "success",
    });
    addLog("POS", "Faturas", `Transferidos ${novasLinhas.length} itens do POS`);
  }
  function limparCarrinhoPOS() {
    setConfirmModal({
      title: "Limpar Carrinho",
      message: "Deseja remover todos os itens do carrinho POS?",
      confirmText: "Limpar",
      type: "danger",
      onConfirm: () => {
        setPosCarrinho([]);
        setConfirmModal(null);
        setToast({ message: "Carrinho limpo", type: "success" });
      },
    });
  }
  function processarBarcode(code: string) {
    const produto = produtos.find(
      (p) => p.codigo && p.codigo.toLowerCase() === code.toLowerCase(),
    );
    if (produto) {
      adicionarAoCarrinhoPOS(produto);
      setPosBarcodeInput("");
    } else {
      setToast({
        message: `Produto com código "${code}" não encontrado`,
        type: "error",
      });
    }
  }
  function getPromocaoAtiva(produtoId: number): PromocaoProduto | undefined {
    const hojeDate = new Date();
    return posPromocoes.find(
      (p) =>
        p.ativa &&
        p.produtoId === produtoId &&
        new Date(p.dataInicio) <= hojeDate &&
        new Date(p.dataFim) >= hojeDate,
    );
  }
  const produtosFavoritos = useMemo(() => {
    return posFavoritos
      .map((f) => produtos.find((p) => p.id === f.produtoId))
      .filter((p): p is NonNullable<typeof p> => p !== undefined);
  }, [posFavoritos, produtos]);
  const produtosRecentes = useMemo(() => {
    return posRecentes
      .map((r) => ({
        produto: produtos.find((p) => p.id === r.produtoId),
        vezesUsado: r.vezesUsado,
      }))
      .filter(
        (
          r,
        ): r is {
          produto: NonNullable<ReturnType<typeof produtos.find>>;
          vezesUsado: number;
        } => r.produto !== undefined,
      )
      .slice(0, 10);
  }, [posRecentes, produtos]);
  const produtosPopulares = useMemo(() => {
    const contador: Record<number, number> = {};
    data.faturas.forEach((f) => {
      f.linhas.forEach((l) => {
        const prod = produtos.find((p) => p.nome === l.descricao);
        if (prod) {
          contador[prod.id] = (contador[prod.id] || 0) + l.quantidade;
        }
      });
    });
    return produtos
      .map((p) => ({ produto: p, popularidade: contador[p.id] || 0 }))
      .sort((a, b) => b.popularidade - a.popularidade)
      .slice(0, 20)
      .map((x) => x.produto);
  }, [produtos, data.faturas]);
  const produtosStockBaixo = useMemo(() => {
    return produtos.filter((p) => p.stock <= (p.stockMinimo || 0));
  }, [produtos]);
  const produtosPromocoes = useMemo(() => {
    const hojeDate = new Date();
    const idsPromocao = posPromocoes
      .filter(
        (p) =>
          p.ativa &&
          new Date(p.dataInicio) <= hojeDate &&
          new Date(p.dataFim) >= hojeDate,
      )
      .map((p) => p.produtoId)
      .filter((id): id is number => id !== undefined);
    return produtos.filter((p) => idsPromocao.includes(p.id));
  }, [produtos, posPromocoes]);
  const produtosPOSFiltrados = useMemo(() => {
    let lista = [...produtos];
    if (posFiltroRapido === "favoritos") {
      lista = produtosFavoritos;
    } else if (posFiltroRapido === "recentes") {
      lista = produtosRecentes.map((r) => r.produto);
    } else if (posFiltroRapido === "populares") {
      lista = produtosPopulares;
    } else if (posFiltroRapido === "stock_baixo") {
      lista = produtosStockBaixo;
    } else if (posFiltroRapido === "promocoes") {
      lista = produtosPromocoes;
    }
    if (catalogCat) {
      lista = lista.filter(
        (p) => (p.categoria || "Sem Categoria") === catalogCat,
      );
    }
    if (catalogSearch.trim()) {
      const q = catalogSearch.trim().toLowerCase();
      lista = lista.filter(
        (p) =>
          p.nome.toLowerCase().includes(q) ||
          (p.codigo || "").toLowerCase().includes(q),
      );
    }
    lista = lista.filter(
      (p) => p.preco >= posPrecoIntervalo[0] && p.preco <= posPrecoIntervalo[1],
    );
    if (!posMostrarSemStock) {
      lista = lista.filter((p) => p.stock > 0);
    }
    switch (posOrdenacao) {
      case "preco_asc":
        lista.sort((a, b) => a.preco - b.preco);
        break;
      case "preco_desc":
        lista.sort((a, b) => b.preco - a.preco);
        break;
      case "popularidade":
        lista.sort((a, b) => {
          const pa = produtosPopulares.findIndex((p) => p.id === a.id);
          const pb = produtosPopulares.findIndex((p) => p.id === b.id);
          return (pa === -1 ? 999 : pa) - (pb === -1 ? 999 : pb);
        });
        break;
      case "recentes":
        lista.sort((a, b) => {
          const ra = produtosRecentes.findIndex((r) => r.produto.id === a.id);
          const rb = produtosRecentes.findIndex((r) => r.produto.id === b.id);
          return (ra === -1 ? 999 : ra) - (rb === -1 ? 999 : rb);
        });
        break;
      default:
        lista.sort((a, b) => a.nome.localeCompare(b.nome));
    }
    return lista;
  }, [
    produtos,
    posFiltroRapido,
    catalogCat,
    catalogSearch,
    posPrecoIntervalo,
    posMostrarSemStock,
    posOrdenacao,
    produtosFavoritos,
    produtosRecentes,
    produtosPopulares,
    produtosStockBaixo,
    produtosPromocoes,
  ]);
  const totaisCarrinhoPOS = useMemo(() => {
    let subtotal = 0;
    let totalDescontos = 0;
    let totalIva = 0;
    posCarrinho.forEach((item) => {
      const sub = item.preco * item.quantidade;
      const desc = sub * (item.desconto / 100);
      const base = sub - desc;
      subtotal += sub;
      totalDescontos += desc;
      if (!item.ivaIsento) {
        totalIva += base * (ivaTaxaDefault / 100);
      }
    });
    return {
      subtotal,
      totalDescontos,
      totalIva,
      total: subtotal - totalDescontos + totalIva,
      itens: posCarrinho.reduce((s, i) => s + i.quantidade, 0),
    };
  }, [posCarrinho, ivaTaxaDefault]);
  useEffect(() => {
    if (!showProdutosPanel) return;
    function handlePOSKeys(e: KeyboardEvent) {
      if (e.key === "F1") {
        e.preventDefault();
        setPosFiltroRapido("favoritos");
      } else if (e.key === "F2") {
        e.preventDefault();
        setPosFiltroRapido("recentes");
      } else if (e.key === "F3") {
        e.preventDefault();
        setPosFiltroRapido("promocoes");
      } else if (e.key === "F4") {
        e.preventDefault();
        setPosFiltroRapido("populares");
      } else if (e.key === "F5") {
        e.preventDefault();
        setPosFiltroRapido("stock_baixo");
      } else if (e.key === "F6") {
        e.preventDefault();
        setPosFiltroRapido("todos");
      } else if (e.key === "F7") {
        e.preventDefault();
        posBarcodeRef.current?.focus();
      } else if (e.key === "F8") {
        e.preventDefault();
        transferirCarrinhoParaFatura();
      } else if (e.key === "F9") {
        e.preventDefault();
        limparCarrinhoPOS();
      } else if (e.key === "F10") {
        e.preventDefault();
        setPosShowCarrinho((v) => !v);
      } else if (e.key === "F11") {
        e.preventDefault();
        setPosModoCaixa((v) => !v);
      } else if (e.ctrlKey && e.key === "+") {
        e.preventDefault();
        setPosTamanhoCard((t) =>
          t === "pequeno" ? "medio" : t === "medio" ? "grande" : "pequeno",
        );
      } else if (e.ctrlKey && e.key === "-") {
        e.preventDefault();
        setPosTamanhoCard((t) =>
          t === "grande" ? "medio" : t === "medio" ? "pequeno" : "grande",
        );
      } else if (
        !e.ctrlKey &&
        !e.altKey &&
        !e.metaKey &&
        /^[1-9]$/.test(e.key)
      ) {
        const target = e.target as HTMLElement;
        if (
          target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.tagName === "SELECT"
        )
          return;
        const idx = parseInt(e.key) - 1;
        if (idx < produtosPOSFiltrados.length) {
          e.preventDefault();
          adicionarAoCarrinhoPOS(produtosPOSFiltrados[idx]);
        }
      }
    }
    document.addEventListener("keydown", handlePOSKeys);
    return () => document.removeEventListener("keydown", handlePOSKeys);
  }, [showProdutosPanel, produtosPOSFiltrados]);
  function adicionarFormaPagamento() {
    const novaForma: FormaPagamentoItem = {
      id: gerarId(),
      forma: "",
      valor: 0,
      valorRecebido: undefined,
      referencia: "",
    };
    setFormasPagamento((prev) => [...prev, novaForma]);
  }
  function removerFormaPagamento(id: string) {
    setFormasPagamento((prev) => prev.filter((f) => f.id !== id));
  }
  function atualizarFormaPagamento(
    id: string,
    campo: keyof FormaPagamentoItem,
    valor: any,
  ) {
    setFormasPagamento((prev) =>
      prev.map((f) => (f.id === id ? { ...f, [campo]: valor } : f)),
    );
  }
  function calcularTotalFormasPagamento(): number {
    return formasPagamento.reduce(
      (total, f) => total + (Number(f.valor) || 0),
      0,
    );
  }
  function calcularTrocoForma(forma: FormaPagamentoItem): number {
    if (forma.forma !== "Numerário" || !forma.valorRecebido) return 0;
    return Math.max(0, forma.valorRecebido - forma.valor);
  }
  function distribuirTotalAutomaticamente(totalAlvo: number) {
    if (formasPagamento.length === 0 || totalAlvo === 0) return;
    const valorPorForma = totalAlvo / formasPagamento.length;
    setFormasPagamento((prev) =>
      prev.map((f) => ({ ...f, valor: Math.round(valorPorForma * 100) / 100 })),
    );
  }
  function preencherRestante(id: string, totalFatura: number) {
    const totalAtual = formasPagamento.reduce(
      (s, f) => s + (f.id === id ? 0 : Number(f.valor) || 0),
      0,
    );
    const restante = totalFatura - totalAtual;
    if (restante > 0) {
      atualizarFormaPagamento(id, "valor", Math.round(restante * 100) / 100);
    }
  }
  // 🔧 CORREÇÃO: Adicionado optional chaining (?) para evitar erro quando session é undefined
  function addLog(acao: string, modulo: string, detalhes: string) {
    const novoLog: LogAuditoria = {
      id: gerarId(),
      timestamp: getTimestamp(),
      usuario: session?.funcionarioNome || session?.username || "Sistema",
      acao,
      modulo,
      detalhes,
    };
    setLogs((prev) => {
      const novos = [novoLog, ...prev].slice(0, 500);
      try {
        tenantStorage.setItem("logs_auditoria", JSON.stringify(novos));
      } catch {}
      return novos;
    });
  }
  function gerarNotificacoes(): NotificacaoItem[] {
    const notifs: NotificacaoItem[] = [];
    const hora = nowTimeStr();
    data.faturas.forEach((f) => {
      if (f.estado === "emitida") {
        const dias = diasParaVencimento(f.dataVencimento);
        if (dias < 0) {
          notifs.push({
            id: `venc_${f.id}`,
            tipo: "vencimento",
            titulo: "Fatura Vencida",
            mensagem: `${f.numero} (${f.clienteNome}) venceu há ${Math.abs(dias)} dia(s) - ${formatCurrency(f.total, moeda)}`,
            data: hoje,
            hora,
            lida: false,
            faturaId: f.id,
          });
        } else if (dias <= 7) {
          notifs.push({
            id: `venc_soon_${f.id}`,
            tipo: "vencimento",
            titulo: "Fatura a Vencer",
            mensagem: `${f.numero} vence em ${dias} dia(s) - ${formatCurrency(f.total, moeda)}`,
            data: hoje,
            hora,
            lida: false,
            faturaId: f.id,
          });
        }
      }
    });
    produtos.forEach((p) => {
      if (p.stock <= (p.stockMinimo || 0)) {
        notifs.push({
          id: `stock_${p.id}`,
          tipo: "stock",
          titulo: "Stock Baixo",
          mensagem: `${p.nome} tem apenas ${p.stock} unidades (mín: ${p.stockMinimo || 0})`,
          data: hoje,
          hora,
          lida: false,
          produtoId: p.id,
        });
      }
    });
    return notifs;
  }
  useEffect(() => {
    setNotificacoes(gerarNotificacoes());
  }, [data.faturas, produtos]);
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target as Node) &&
        searchInputRef.current &&
        !searchInputRef.current.contains(e.target as Node)
      ) {
        setShowDropdown(false);
        setDropdownIndex(-1);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.ctrlKey || e.metaKey) {
        if (e.key === "n" || e.key === "N") {
          e.preventDefault();
          handleNovo();
        } else if (e.key === "p" || e.key === "P") {
          e.preventDefault();
          openNovoProdutoModal();
        } else if (e.key === "c" || e.key === "C") {
          e.preventDefault();
          openNovoClienteModal();
        } else if (e.key === "d" || e.key === "D") {
          e.preventDefault();
          setShowDashboard((v) => !v);
        } else if (e.key === "h" || e.key === "H") {
          e.preventDefault();
          setShowChat((v) => !v);
        }
      }
      if (e.key === "Escape") {
        if (showNotasCreditoPage) setShowNotasCreditoPage(false);
        else if (showDashboard) setShowDashboard(false);
        else if (showRelatorios) setShowRelatorios(false);
        else if (showTemplates) setShowTemplates(false);
        else if (showLogs) setShowLogs(false);
        else if (showNotificacoes) setShowNotificacoes(false);
        else if (showConfig) setShowConfig(false);
        else if (showChat) setShowChat(false);
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [
    showDashboard,
    showRelatorios,
    showTemplates,
    showLogs,
    showNotificacoes,
    showConfig,
    showChat,
    showNotasCreditoPage,
  ]);
  useEffect(() => {
    try {
      tenantStorage.setItem("templates_fatura", JSON.stringify(templates));
    } catch {}
  }, [templates]);
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages]);
  function resetForm() {
    setClienteNome("");
    setClienteNif("");
    setClienteEndereco("");
    setPacienteId("");
    setLinhas([]);
    setObservacoes("");
    setRefExterna("");
    setEstado("emitida");
    setDataEmissao(hoje);
    setDataVenc(addDays(hoje, 30));
    setIvaTaxa(ivaTaxaDefault);
    setDesconto(0);
    setTipoDocumento("factura");
    setFormaPagamento("");
    setValorRecebido(0);
    setFormasPagamento([]);
    setUsarMultiplasFormas(false);
    setProdutoSearch("");
    setProdutoQtd(1);
    setShowDropdown(false);
    setDropdownIndex(-1);
    setShowProdutosPanel(false);
    setNifError("");
    setFacturaPremiada(false);
    setEditId(null);
  }
  function handleNovo() {
    resetForm();
    setView("form");
    addLog("Criar", "Faturas", "Iniciando nova fatura");
  }
  function handleEdit(f: Fatura) {
    setClienteNome(f.clienteNome);
    setClienteNif(f.clienteNif);
    setClienteEndereco(f.clienteEndereco);
    setPacienteId(f.pacienteId ? String(f.pacienteId) : "");
    setLinhas(
      f.linhas.length > 0
        ? f.linhas.map((l) => ({ ...l, unidade: l.unidade ?? "" }))
        : [],
    );
    setObservacoes(f.observacoes);
    setRefExterna("");
    setEstado(f.estado);
    setDataEmissao(f.data);
    setDataVenc(f.dataVencimento);
    setIvaTaxa(f.ivaTaxa);
    setDesconto(0);
    setTipoDocumento(f.tipoDocumento ?? "factura");
    setFormaPagamento(f.formaPagamento ?? "");
    setFacturaPremiada(f.facturaPremiada ?? false);
    setShowDropdown(false);
    setDropdownIndex(-1);
    setShowProdutosPanel(false);
    setNifError("");
    setEditId(f.id);
    setView("form");
    addLog("Editar", "Faturas", `Editando ${f.numero}`);
  }
  function handleNotaCredito(f: Fatura) {
    setNcMotivo("");
    setNcModal({ fatura: f });
  }
  function confirmarNotaCredito(f: Fatura, motivo: string) {
    setNcModal(null);
    resetForm();
    setTipoDocumento("nota-credito");
    setClienteNome(f.clienteNome);
    setClienteNif(f.clienteNif);
    setClienteEndereco(f.clienteEndereco);
    setLinhas(
      f.linhas.map((l) => ({ ...l, quantidade: -Math.abs(l.quantidade) })),
    );
    setObservacoes(
      `Nota de Crédito referente ao documento ${f.numero}${motivo ? " — " + motivo : ""}`,
    );
    setEstado("emitida");
    setIvaTaxa(f.ivaTaxa);
    setView("form");
    addLog("Nota Crédito", "Faturas", `NC para ${f.numero}`);
  }
  function handleEmitirRecibo(f: Fatura) {
    setReciboFormaPag(f.formaPagamento ?? "");
    setReciboModal({ fatura: f });
  }
  function confirmarRecibo(f: Fatura, formaPag: string) {
    setReciboModal(null);
    const hora = nowTimeStr();
    const recibo: Omit<Fatura, "id" | "numero"> = {
      serie: f.serie,
      data: hoje,
      horaOperacao: hora,
      dataVencimento: hoje,
      clienteNome: f.clienteNome,
      clienteNif: f.clienteNif,
      clienteEndereco: f.clienteEndereco,
      linhas: f.linhas,
      subtotalSemIva: f.subtotalSemIva,
      totalIva: f.totalIva,
      ivaTaxa: f.ivaTaxa,
      total: f.total,
      estado: "paga",
      observacoes: `Recibo de pagamento da ${f.numero}`,
      pacienteId: f.pacienteId,
      emitidoPor: f.emitidoPor,
      tipoDocumento: "recibo",
      formaPagamento: formaPag,
      facturaPremiada: false,
    };
    addFatura(recibo)
      .then((nova) => {
        gerarHashFaturaAsync(
          { ...nova, numero: nova.numero },
          data.config.nif || "",
        ).then((hash) => updateFatura(nova.id, { codigoHash: hash }));
        const htmlRecibo = generateFaturaHTML(
          { ...nova, tipoDocumento: "recibo" },
          data.config,
          { segundaVia: false },
        );
        downloadFatura(htmlRecibo, nova.numero);
        setToast({ message: "Recibo emitido com sucesso!", type: "success" });
        addLog("Recibo", "Faturas", `Recibo para ${f.numero}`);
      })
      .catch(() => {
        setToast({ message: "Erro ao emitir recibo", type: "error" });
      });
  }
  function openNovoProdutoModal(nomePrePreenchido?: string) {
    setNovoProduto({
      nome: nomePrePreenchido || "",
      codigo: "",
      preco: 0,
      categoria: "",
      ivaIsento: false,
      descricao: "",
      stock: 0,
      stockMinimo: 0,
    });
    setNovoProdutoError("");
    setEditandoProdutoId(null);
    setShowNovoProduto(true);
  }
  function openNovoClienteModal() {
    setNovoCliente({
      nome: "",
      nif: "",
      bi: "",
      passaporte: "",
      telefone: "",
      email: "",
      endereco: "",
      observacoes: "",
      tipoDocumento: "nif",
    });
    setNovoClienteError("");
    setEditandoClienteId(null);
    setShowNovoCliente(true);
  }
  function temDadosNaoSalvosProduto(): boolean {
    return novoProduto.nome.trim() !== "" || novoProduto.preco > 0;
  }
  function temDadosNaoSalvosCliente(): boolean {
    return (
      novoCliente.nome.trim() !== "" ||
      novoCliente.nif.trim() !== "" ||
      novoCliente.bi.trim() !== "" ||
      novoCliente.passaporte.trim() !== "" ||
      novoCliente.telefone.trim() !== ""
    );
  }
  function handleCloseProdutoModal() {
    if (temDadosNaoSalvosProduto()) {
      setCancelAction(() => () => {
        setShowNovoProduto(false);
        setEditandoProdutoId(null);
        setNovoProduto({
          nome: "",
          codigo: "",
          preco: 0,
          categoria: "",
          ivaIsento: false,
          descricao: "",
          stock: 0,
          stockMinimo: 0,
        });
        setNovoProdutoError("");
      });
      setShowCancelConfirm(true);
    } else {
      setShowNovoProduto(false);
      setEditandoProdutoId(null);
      setNovoProduto({
        nome: "",
        codigo: "",
        preco: 0,
        categoria: "",
        ivaIsento: false,
        descricao: "",
        stock: 0,
        stockMinimo: 0,
      });
      setNovoProdutoError("");
    }
  }
  function handleCloseClienteModal() {
    if (temDadosNaoSalvosCliente()) {
      setCancelAction(() => () => {
        setShowNovoCliente(false);
        setEditandoClienteId(null);
        setNovoCliente({
          nome: "",
          nif: "",
          bi: "",
          passaporte: "",
          telefone: "",
          email: "",
          endereco: "",
          observacoes: "",
          tipoDocumento: "nif",
        });
        setNovoClienteError("");
      });
      setShowCancelConfirm(true);
    } else {
      setShowNovoCliente(false);
      setEditandoClienteId(null);
      setNovoCliente({
        nome: "",
        nif: "",
        bi: "",
        passaporte: "",
        telefone: "",
        email: "",
        endereco: "",
        observacoes: "",
        tipoDocumento: "nif",
      });
      setNovoClienteError("");
    }
  }
  async function handleSaveProduto() {
    setNovoProdutoError("");
    if (!novoProduto.nome.trim()) {
      setNovoProdutoError("O nome do produto é obrigatório.");
      return;
    }
    if (novoProduto.preco < 0) {
      setNovoProdutoError("O preço não pode ser negativo.");
      return;
    }
    if (novoProduto.stock < 0) {
      setNovoProdutoError("O stock não pode ser negativo.");
      return;
    }
    const produtoExistente = produtos.find(
      (p) =>
        p.nome.toLowerCase() === novoProduto.nome.trim().toLowerCase() &&
        p.id !== editandoProdutoId,
    );
    if (produtoExistente) {
      setNovoProdutoError(
        `Já existe um produto com o nome "${novoProduto.nome}".`,
      );
      return;
    }
    if (
      novoProduto.codigo &&
      produtos.find(
        (p) =>
          p.codigo === novoProduto.codigo.trim() && p.id !== editandoProdutoId,
      )
    ) {
      setNovoProdutoError(
        `Já existe um produto com o código "${novoProduto.codigo}".`,
      );
      return;
    }
    setSalvandoProduto(true);
    try {
      const produtoData = {
        nome: novoProduto.nome.trim(),
        codigo: novoProduto.codigo.trim() || "",
        preco: Number(novoProduto.preco) || 0,
        categoria: novoProduto.categoria.trim() || "",
        ivaIsento: !!novoProduto.ivaIsento,
        descricao: novoProduto.descricao.trim() || undefined,
        stock: Number(novoProduto.stock) || 0,
        stockMinimo: Number(novoProduto.stockMinimo) || 0,
        ativo: true,
      };
      if (editandoProdutoId !== null) {
        if (updateProduto) {
          await updateProduto(editandoProdutoId, produtoData);
          setToast({
            message: `Produto "${produtoData.nome}" atualizado!`,
            type: "success",
          });
          addLog("Atualizar", "Produtos", produtoData.nome);
        } else throw new Error("Função de edição indisponível");
      } else {
        if (addProduto) {
          await addProduto(produtoData);
          setToast({
            message: `Produto "${produtoData.nome}" criado!`,
            type: "success",
          });
          addLog("Criar", "Produtos", produtoData.nome);
        } else throw new Error("Função de criação indisponível");
      }
      setShowNovoProduto(false);
      setEditandoProdutoId(null);
      setNovoProduto({
        nome: "",
        codigo: "",
        preco: 0,
        categoria: "",
        ivaIsento: false,
        descricao: "",
        stock: 0,
        stockMinimo: 0,
      });
    } catch (err: any) {
      setNovoProdutoError(
        err.message || "Erro ao salvar produto. Tente novamente.",
      );
      setToast({
        message: err.message || "Erro ao salvar produto",
        type: "error",
      });
    } finally {
      setSalvandoProduto(false);
    }
  }
  function handleEditarProduto(produtoId: number) {
    const produto = todosProdutos.find((p) => p.id === produtoId);
    if (!produto) return;
    setNovoProduto({
      nome: produto.nome,
      codigo: produto.codigo || "",
      preco: produto.preco,
      categoria: produto.categoria || "",
      ivaIsento: !!produto.ivaIsento,
      descricao: produto.descricao || "",
      stock: produto.stock || 0,
      stockMinimo: produto.stockMinimo || 0,
    });
    setEditandoProdutoId(produtoId);
    setNovoProdutoError("");
    setShowNovoProduto(true);
  }
  function handleDesativarProduto(produtoId: number) {
    const produto = todosProdutos.find((p) => p.id === produtoId);
    if (!produto) return;
    setConfirmModal({
      title: produto.ativo ? "Desativar Produto" : "Ativar Produto",
      message: produto.ativo
        ? `Deseja desativar "${produto.nome}"?`
        : `Deseja ativar "${produto.nome}"?`,
      confirmText: produto.ativo ? "Desativar" : "Ativar",
      type: produto.ativo ? "warning" : "info",
      onConfirm: async () => {
        try {
          if (updateProduto) {
            await updateProduto(produtoId, {
              ...produto,
              ativo: !produto.ativo,
            });
            setToast({
              message: `"${produto.nome}" ${produto.ativo ? "desativado" : "ativado"}!`,
              type: "success",
            });
            addLog(
              produto.ativo ? "Desativar" : "Ativar",
              "Produtos",
              produto.nome,
            );
          }
        } catch (err) {
          setToast({ message: "Erro ao alterar estado", type: "error" });
        }
        setConfirmModal(null);
      },
    });
  }
  async function handleSaveCliente() {
    setNovoClienteError("");
    if (!novoCliente.nome.trim()) {
      setNovoClienteError("O nome do cliente é obrigatório.");
      return;
    }
    if (
      novoCliente.tipoDocumento === "nif" &&
      novoCliente.nif &&
      !validarNIF(novoCliente.nif)
    ) {
      setNovoClienteError("NIF inválido. Deve ter 9 ou 14 dígitos.");
      return;
    }
    if (
      novoCliente.tipoDocumento === "bi" &&
      novoCliente.bi &&
      !validarBI(novoCliente.bi)
    ) {
      setNovoClienteError("BI inválido.");
      return;
    }
    if (
      novoCliente.tipoDocumento === "passaporte" &&
      novoCliente.passaporte &&
      !validarPassaporte(novoCliente.passaporte)
    ) {
      setNovoClienteError("Passaporte inválido.");
      return;
    }
    if (novoCliente.email && !validarEmail(novoCliente.email)) {
      setNovoClienteError("Email inválido.");
      return;
    }
    if (novoCliente.telefone && !validarTelefone(novoCliente.telefone)) {
      setNovoClienteError("Telefone inválido.");
      return;
    }
    const docValue =
      novoCliente.tipoDocumento === "nif"
        ? novoCliente.nif
        : novoCliente.tipoDocumento === "bi"
          ? novoCliente.bi
          : novoCliente.passaporte;
    if (docValue) {
      const clienteExistente = data.pacientes.find((p) => {
        if (novoCliente.tipoDocumento === "nif" && p.nif === docValue.trim())
          return true;
        if (novoCliente.tipoDocumento === "bi" && p.bi === docValue.trim())
          return true;
        if (
          novoCliente.tipoDocumento === "passaporte" &&
          p.passaporte === docValue.trim()
        )
          return true;
        return false;
      });
      if (clienteExistente && clienteExistente.id !== editandoClienteId) {
        setNovoClienteError(
          `Já existe um cliente com este ${novoCliente.tipoDocumento.toUpperCase()}.`,
        );
        return;
      }
    }
    const clienteNomeExistente = data.pacientes.find(
      (p) =>
        p.nome.toLowerCase() === novoCliente.nome.trim().toLowerCase() &&
        p.id !== editandoClienteId,
    );
    if (clienteNomeExistente) {
      setNovoClienteError(
        `Já existe um cliente com o nome "${novoCliente.nome}".`,
      );
      return;
    }
    setSalvandoCliente(true);
    try {
      const clienteData: any = {
        nome: novoCliente.nome.trim(),
        telefone: novoCliente.telefone.trim() || undefined,
        email: novoCliente.email.trim() || undefined,
        endereco: novoCliente.endereco.trim() || undefined,
        observacoes: novoCliente.observacoes.trim() || undefined,
      };
      if (novoCliente.tipoDocumento === "nif" && novoCliente.nif)
        clienteData.nif = novoCliente.nif.trim();
      if (novoCliente.tipoDocumento === "bi" && novoCliente.bi)
        clienteData.bi = novoCliente.bi.trim();
      if (novoCliente.tipoDocumento === "passaporte" && novoCliente.passaporte)
        clienteData.passaporte = novoCliente.passaporte.trim();
      if (editandoClienteId !== null) {
        if (updatePaciente) {
          await updatePaciente(editandoClienteId, clienteData);
          setToast({
            message: `Cliente "${clienteData.nome}" atualizado!`,
            type: "success",
          });
          addLog("Atualizar", "Clientes", clienteData.nome);
        } else throw new Error("Função de edição indisponível");
      } else {
        if (addPaciente) {
          const novoPaciente = await addPaciente(clienteData);
          setPacienteId(String(novoPaciente.id));
          setClienteNome(novoPaciente.nome);
          setClienteNif(novoPaciente.nif || "");
          setClienteEndereco(novoPaciente.endereco || "");
          setNifError("");
          setToast({
            message: `Cliente "${clienteData.nome}" criado e selecionado!`,
            type: "success",
          });
          addLog("Criar", "Clientes", clienteData.nome);
        } else throw new Error("Função de criação indisponível");
      }
      setShowNovoCliente(false);
      setEditandoClienteId(null);
      setNovoCliente({
        nome: "",
        nif: "",
        bi: "",
        passaporte: "",
        telefone: "",
        email: "",
        endereco: "",
        observacoes: "",
        tipoDocumento: "nif",
      });
    } catch (err: any) {
      setNovoClienteError(
        err.message || "Erro ao salvar cliente. Tente novamente.",
      );
      setToast({
        message: err.message || "Erro ao salvar cliente",
        type: "error",
      });
    } finally {
      setSalvandoCliente(false);
    }
  }
  function handleEditarCliente(clienteId: number) {
    const cliente = data.pacientes.find((p) => p.id === clienteId);
    if (!cliente) return;
    setNovoCliente({
      nome: cliente.nome,
      nif: cliente.nif || "",
      bi: cliente.bi || "",
      passaporte: cliente.passaporte || "",
      telefone: cliente.telefone || "",
      email: cliente.email || "",
      endereco: cliente.endereco || "",
      observacoes: cliente.observacoes || "",
      tipoDocumento: cliente.nif ? "nif" : cliente.bi ? "bi" : "passaporte",
    });
    setEditandoClienteId(clienteId);
    setNovoClienteError("");
    setShowNovoCliente(true);
  }
  function handleSalvarTemplate() {
    if (!templateForm.nome.trim()) {
      setToast({ message: "Nome do template é obrigatório", type: "error" });
      return;
    }
    if (templateForm.linhas.length === 0) {
      setToast({ message: "Adicione pelo menos um item", type: "error" });
      return;
    }
    const template: TemplateFatura = {
      ...templateForm,
      id: templateForm.id || gerarId(),
      criadoEm: hoje,
    };
    setTemplates((prev) => {
      const idx = prev.findIndex((t) => t.id === template.id);
      if (idx >= 0) {
        const novos = [...prev];
        novos[idx] = template;
        return novos;
      }
      return [template, ...prev];
    });
    setToast({
      message: `Template "${template.nome}" salvo!`,
      type: "success",
    });
    setShowNovoTemplate(false);
    setTemplateEditando(null);
    setTemplateForm({
      id: "",
      nome: "",
      descricao: "",
      tipoDocumento: "factura",
      linhas: [],
      observacoes: "",
      criadoEm: hoje,
      usadoCount: 0,
      categoria: "Geral",
    });
    addLog("Salvar", "Templates", template.nome);
  }
  function handleUsarTemplate(template: TemplateFatura) {
    resetForm();
    setTipoDocumento(template.tipoDocumento);
    setLinhas(template.linhas.map((l) => ({ ...l })));
    setObservacoes(template.observacoes || "");
    setTemplates((prev) =>
      prev.map((t) =>
        t.id === template.id ? { ...t, usadoCount: t.usadoCount + 1 } : t,
      ),
    );
    setView("form");
    setShowTemplates(false);
    setToast({
      message: `Template "${template.nome}" aplicado!`,
      type: "success",
    });
    addLog("Usar", "Templates", template.nome);
  }
  function handleEditarTemplate(template: TemplateFatura) {
    setTemplateForm({ ...template });
    setTemplateEditando(template);
    setShowNovoTemplate(true);
  }
  function handleRemoverTemplate(templateId: string) {
    setConfirmModal({
      title: "Remover Template",
      message: "Deseja remover este template?",
      confirmText: "Remover",
      type: "danger",
      onConfirm: () => {
        setTemplates((prev) => prev.filter((t) => t.id !== templateId));
        setToast({ message: "Template removido", type: "success" });
        setConfirmModal(null);
        addLog("Remover", "Templates", templateId);
      },
    });
  }
  function handleCriarTemplateDaFaturaAtual() {
    setTemplateForm({
      id: "",
      nome: "",
      descricao: "",
      tipoDocumento: tipoDocumento,
      linhas: linhas.map((l) => ({ ...l })),
      observacoes: observacoes,
      criadoEm: hoje,
      usadoCount: 0,
      categoria: "Geral",
    });
    setTemplateEditando(null);
    setShowNovoTemplate(true);
  }
  const templatesLaboratorio: TemplateFatura[] = [
    {
      id: "lab_hemograma",
      nome: "Hemograma Completo",
      descricao: "Exames hematológicos básicos",
      tipoDocumento: "pro-forma",
      categoria: "Hematologia",
      linhas: [
        {
          descricao: "Hemograma Completo",
          quantidade: 1,
          precoUnitario: 3500,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Velocidade de Sedimentação (VS)",
          quantidade: 1,
          precoUnitario: 1500,
          ivaIsento: false,
          unidade: "exame",
        },
      ],
      observacoes: "Jejum de 8 horas recomendado",
      criadoEm: hoje,
      usadoCount: 0,
    },
    {
      id: "lab_bioquimica",
      nome: "Painel Bioquímico Básico",
      descricao: "Exames bioquímicos de rotina",
      tipoDocumento: "pro-forma",
      categoria: "Bioquímica",
      linhas: [
        {
          descricao: "Glicemia em Jejum",
          quantidade: 1,
          precoUnitario: 2000,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Ureia",
          quantidade: 1,
          precoUnitario: 2000,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Creatinina",
          quantidade: 1,
          precoUnitario: 2000,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Ácido Úrico",
          quantidade: 1,
          precoUnitario: 2000,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Colesterol Total",
          quantidade: 1,
          precoUnitario: 2000,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Triglicerídeos",
          quantidade: 1,
          precoUnitario: 2000,
          ivaIsento: false,
          unidade: "exame",
        },
      ],
      observacoes: "Jejum obrigatório de 12 horas",
      criadoEm: hoje,
      usadoCount: 0,
    },
    {
      id: "lab_urinalise",
      nome: "Análise de Urina Completa",
      descricao: "Exame completo de urina",
      tipoDocumento: "pro-forma",
      categoria: "Urinálise",
      linhas: [
        {
          descricao: "Análise Macroscópica de Urina",
          quantidade: 1,
          precoUnitario: 1500,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Análise Microscópica de Urina",
          quantidade: 1,
          precoUnitario: 2000,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Urocultura com Antibiograma",
          quantidade: 1,
          precoUnitario: 5000,
          ivaIsento: false,
          unidade: "exame",
        },
      ],
      observacoes: "Primeira urina da manhã",
      criadoEm: hoje,
      usadoCount: 0,
    },
    {
      id: "lab_parasitologia",
      nome: "Exame Parasitológico de Fezes",
      descricao: "Detecção de parasitas intestinais",
      tipoDocumento: "pro-forma",
      categoria: "Parasitologia",
      linhas: [
        {
          descricao: "Exame Parasitológico de Fezes (3 amostras)",
          quantidade: 1,
          precoUnitario: 4500,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Pesquisa de Giardia",
          quantidade: 1,
          precoUnitario: 2500,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Pesquisa de Cryptosporidium",
          quantidade: 1,
          precoUnitario: 3000,
          ivaIsento: false,
          unidade: "exame",
        },
      ],
      observacoes: "Recolher 3 amostras em dias diferentes",
      criadoEm: hoje,
      usadoCount: 0,
    },
    {
      id: "lab_serologia",
      nome: "Painel Serológico",
      descricao: "Exames sorológicos diversos",
      tipoDocumento: "pro-forma",
      categoria: "Sorologia",
      linhas: [
        {
          descricao: "HIV 1/2 (Teste Rápido)",
          quantidade: 1,
          precoUnitario: 3000,
          ivaIsento: true,
          unidade: "exame",
        },
        {
          descricao: "Hepatite B (HBsAg)",
          quantidade: 1,
          precoUnitario: 3500,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Hepatite C (Anti-HCV)",
          quantidade: 1,
          precoUnitario: 3500,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Sífilis (VDRL)",
          quantidade: 1,
          precoUnitario: 2500,
          ivaIsento: false,
          unidade: "exame",
        },
      ],
      observacoes: "",
      criadoEm: hoje,
      usadoCount: 0,
    },
    {
      id: "lab_checkup",
      nome: "Check-up Completo",
      descricao: "Pacote de exames gerais",
      tipoDocumento: "pro-forma",
      categoria: "Pacotes",
      linhas: [
        {
          descricao: "Hemograma Completo",
          quantidade: 1,
          precoUnitario: 3500,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Glicemia",
          quantidade: 1,
          precoUnitario: 2000,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Ureia e Creatinina",
          quantidade: 1,
          precoUnitario: 3500,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Perfil Lipídico",
          quantidade: 1,
          precoUnitario: 6000,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Transaminases (TGO/TGP)",
          quantidade: 1,
          precoUnitario: 4000,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Análise de Urina",
          quantidade: 1,
          precoUnitario: 2500,
          ivaIsento: false,
          unidade: "exame",
        },
        {
          descricao: "Exame Parasitológico de Fezes",
          quantidade: 1,
          precoUnitario: 3000,
          ivaIsento: false,
          unidade: "exame",
        },
      ],
      observacoes: "Jejum de 12 horas. Resultados em 48h.",
      criadoEm: hoje,
      usadoCount: 0,
    },
  ];
  function handleMarcarNotificacaoLida(notifId: string) {
    setNotificacoes((prev) =>
      prev.map((n) => (n.id === notifId ? { ...n, lida: true } : n)),
    );
  }
  function handleMarcarTodasLidas() {
    setNotificacoes((prev) => prev.map((n) => ({ ...n, lida: true })));
    setToast({
      message: "Todas as notificações marcadas como lidas",
      type: "success",
    });
  }
  function handleLimparNotificacoes() {
    setConfirmModal({
      title: "Limpar Notificações",
      message: "Deseja remover todas as notificações?",
      confirmText: "Limpar",
      type: "danger",
      onConfirm: () => {
        setNotificacoes([]);
        setToast({ message: "Notificações limpas", type: "success" });
        setConfirmModal(null);
      },
    });
  }
  function handleAcaoNotificacao(notif: NotificacaoItem) {
    handleMarcarNotificacaoLida(notif.id);
    if (notif.faturaId) {
      const fatura = data.faturas.find((f) => f.id === notif.faturaId);
      if (fatura) {
        setShowNotificacoes(false);
        handleEdit(fatura);
      }
    } else if (notif.produtoId) {
      setShowNotificacoes(false);
      setShowGestaoProdutos(true);
      setGestaoSearch("");
    }
  }
  function handleLimparLogs() {
    setConfirmModal({
      title: "Limpar Logs",
      message: "Deseja remover todos os logs de auditoria?",
      confirmText: "Limpar",
      type: "danger",
      onConfirm: () => {
        setLogs([]);
        try {
          tenantStorage.removeItem("logs_auditoria");
        } catch {}
        setToast({ message: "Logs limpos", type: "success" });
        setConfirmModal(null);
      },
    });
  }
  function handleExportarLogs() {
    const csv = [
      "Data/Hora,Usuário,Ação,Módulo,Detalhes",
      ...logs.map(
        (l) =>
          `${l.timestamp},${l.usuario},${l.acao},${l.modulo},"${l.detalhes}"`,
      ),
    ].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `logs_auditoria_${todayStr().replace(/\//g, "-")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    setToast({ message: "Logs exportados com sucesso", type: "success" });
  }
  function handleSalvarConfig() {
    setToast({ message: "Configurações salvas com sucesso!", type: "success" });
    addLog("Configurar", "Sistema", "Configurações atualizadas");
    setShowConfig(false);
  }
  function handleExportarBackup() {
    const backup = {
      data: new Date().toISOString(),
      faturas: data.faturas,
      produtos: data.produtos,
      pacientes: data.pacientes,
      config: data.config,
      templates,
      logs,
      posFavoritos,
      posRecentes,
      posPromocoes,
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `backup_${todayStr().replace(/\//g, "-")}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setToast({ message: "Backup exportado com sucesso!", type: "success" });
    addLog("Backup", "Sistema", "Backup exportado");
  }
  function calcTotals(ls: LinhaFatura[], taxa: number, desc: number) {
    let sub = 0,
      iva = 0;
    for (const l of ls) {
      const s = l.quantidade * l.precoUnitario;
      sub += s;
      if (!l.ivaIsento) iva += s * (taxa / 100);
    }
    const descVal = sub * (desc / 100);
    return {
      subtotalSemIva: sub - descVal,
      totalIva: iva * (1 - desc / 100),
      total: sub - descVal + iva * (1 - desc / 100),
    };
  }
  const totals = useMemo(
    () => calcTotals(linhas, ivaTaxa, desconto),
    [linhas, ivaTaxa, desconto],
  );
  const totalFormasPagamento = useMemo(
    () => calcularTotalFormasPagamento(),
    [formasPagamento],
  );
  const diferencaPagamento = useMemo(
    () => totals.total - totalFormasPagamento,
    [totals.total, totalFormasPagamento],
  );
  const troco = useMemo(() => {
    if (formaPagamento !== "Numerário" || valorRecebido === "") return 0;
    return Math.max(0, (valorRecebido as number) - totals.total);
  }, [formaPagamento, valorRecebido, totals.total]);
  const trocoNegativo = useMemo(() => {
    if (formaPagamento !== "Numerário" || valorRecebido === "") return false;
    return (
      (valorRecebido as number) < totals.total && (valorRecebido as number) > 0
    );
  }, [formaPagamento, valorRecebido, totals.total]);
  useEffect(() => {
    if (usarMultiplasFormas && formasPagamento.length > 0 && totals.total > 0) {
      const totalAtual = calcularTotalFormasPagamento();
      if (Math.abs(totalAtual - totals.total) > 0.01 && totalAtual === 0) {
        distribuirTotalAutomaticamente(totals.total);
      }
    }
  }, [totals.total, usarMultiplasFormas]);
  const produtosFiltrados = useMemo(() => {
    const q = produtoSearch.trim().toLowerCase();
    if (!q) return [];
    return produtos
      .filter(
        (p) =>
          p.nome.toLowerCase().includes(q) ||
          (p.codigo && p.codigo.toLowerCase().includes(q)),
      )
      .slice(0, 8);
  }, [produtoSearch, produtos]);
  useEffect(() => {
    if (produtosFiltrados.length > 0 && produtoSearch.trim()) {
      setShowDropdown(true);
      setDropdownIndex(-1);
    } else {
      setShowDropdown(false);
      setDropdownIndex(-1);
    }
  }, [produtosFiltrados, produtoSearch]);
  function handleAddProduto(p?: (typeof produtos)[0]) {
    if (p) {
      setLinhas((prev) => [
        ...prev,
        {
          descricao: p.nome,
          quantidade: produtoQtd,
          precoUnitario: p.preco,
          ivaIsento: !!p.ivaIsento,
          unidade: "",
        },
      ]);
    } else if (produtoSearch.trim()) {
      setLinhas((prev) => [
        ...prev,
        {
          descricao: produtoSearch.trim(),
          quantidade: produtoQtd,
          precoUnitario: 0,
          ivaIsento: false,
          unidade: "",
        },
      ]);
    }
    setProdutoSearch("");
    setProdutoQtd(1);
    setShowDropdown(false);
    setDropdownIndex(-1);
    setTimeout(() => searchInputRef.current?.focus(), 50);
  }
  function handleAddProdutoFromPanel(p: (typeof produtos)[0]) {
    setLinhas((prev) => [
      ...prev,
      {
        descricao: p.nome,
        quantidade: 1,
        precoUnitario: p.preco,
        ivaIsento: !!p.ivaIsento,
        unidade: "",
      },
    ]);
  }
  function handleRemoverLinha(i: number) {
    setLinhas((prev) => prev.filter((_, idx) => idx !== i));
  }
  function handleUpdateLinha(
    i: number,
    field: keyof LinhaFatura,
    value: string | number | boolean,
  ) {
    setLinhas((prev) =>
      prev.map((l, idx) => (idx === i ? { ...l, [field]: value } : l)),
    );
  }
  function handleSearchKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (!showDropdown || produtosFiltrados.length === 0) {
      if (e.key === "Enter" && produtoSearch.trim()) {
        e.preventDefault();
        handleAddProduto();
      }
      return;
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setDropdownIndex((i) => Math.min(i + 1, produtosFiltrados.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setDropdownIndex((i) => Math.max(i - 1, -1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (dropdownIndex >= 0)
        handleAddProduto(produtosFiltrados[dropdownIndex]);
      else handleAddProduto(produtosFiltrados[0]);
    } else if (e.key === "Escape") {
      setShowDropdown(false);
      setDropdownIndex(-1);
    }
  }
  async function handleSave() {
    setNifError("");
    const nomeEfectivo = clienteNome.trim() || "Consumidor Final";
    if (
      nomeEfectivo !== "Consumidor Final" &&
      !clienteNif.trim() &&
      !novoCliente.bi &&
      !novoCliente.passaporte
    ) {
      setNifError(
        "É necessário NIF, BI ou Passaporte para clientes identificados.",
      );
      return;
    }
    const linhasValidas = linhas.filter((l) => l.descricao.trim());
    if (linhasValidas.length === 0) {
      setToast({ message: "Adicione pelo menos um item", type: "error" });
      return;
    }
    if (usarMultiplasFormas && formasPagamento.length > 0) {
      const formasInvalidas = formasPagamento.filter(
        (f) => !f.forma || (Number(f.valor) || 0) <= 0,
      );
      if (formasInvalidas.length > 0) {
        setToast({
          message: "Preencha todas as formas de pagamento",
          type: "error",
        });
        return;
      }
      if (Math.abs(diferencaPagamento) > 0.01) {
        setToast({
          message: `Total das formas não corresponde ao total da fatura. Diferença: ${formatCurrency(Math.abs(diferencaPagamento), moeda)}`,
          type: "error",
        });
        return;
      }
    }
    const t = calcTotals(linhasValidas, ivaTaxa, desconto);
    const hora = nowTimeStr();
    let formaPagamentoFinal = formaPagamento;
    if (usarMultiplasFormas && formasPagamento.length > 0) {
      formaPagamentoFinal =
        formasPagamento.length === 1
          ? formasPagamento[0].forma
          : "Múltiplas (" +
            formasPagamento.map((f) => f.forma).join(" + ") +
            ")";
    }
    const dados: Omit<Fatura, "id" | "numero"> = {
      serie: data.config.serie,
      data: dataEmissao,
      horaOperacao: hora,
      dataVencimento: dataVenc,
      clienteNome: nomeEfectivo,
      clienteNif: clienteNif.trim(),
      clienteEndereco: clienteEndereco.trim(),
      linhas: linhasValidas,
      subtotalSemIva: t.subtotalSemIva,
      totalIva: t.totalIva,
      ivaTaxa,
      total: t.total,
      estado,
      observacoes: observacoes.trim(),
      pacienteId: pacienteId ? parseInt(pacienteId) : undefined,
      emitidoPor: session?.funcionarioNome || session?.username,
      tipoDocumento,
      desconto,
      formaPagamento: formaPagamentoFinal,
      facturaPremiada,
      emissaoContagem: 1,
    };
    if (editId !== null) {
      await updateFatura(editId, dados);
      setToast({ message: "Documento atualizado!", type: "success" });
      addLog("Atualizar", "Faturas", `Fatura ${editId}`);
    } else {
      const nova = await addFatura(dados);
      const hash = await gerarHashFaturaAsync(nova, data.config.nif || "");
      await updateFatura(nova.id, { codigoHash: hash });
      if (estado === "paga") {
        await addMovimento({
          data: dataEmissao,
          descricao: `${TIPO_LABEL[tipoDocumento] ?? "Fatura"} ${nova.numero} — ${dados.clienteNome}`,
          tipo: "entrada",
          valor: nova.total,
          categoria: "Faturação",
          faturaId: nova.id,
          referencia: nova.numero,
          registadoPor: session?.funcionarioNome || session?.username,
        });
      }
      setToast({
        message: `${TIPO_LABEL[tipoDocumento] ?? "Documento"} criado!`,
        type: "success",
      });
      addLog("Criar", "Faturas", nova.numero);
    }
    resetForm();
    setView("lista");
  }
  async function handleMarcarPaga(f: Fatura) {
    const method = prompt(
      "Forma de pagamento efectivamente confirmada:",
      f.formaPagamento || "",
    );
    if (!method?.trim()) return;
    try {
      await updateFatura(f.id, {
        estado: "paga",
        formaPagamento: method.trim(),
      });
      setToast({
        message: `Recebimento de ${f.numero} confirmado no servidor.`,
        type: "success",
      });
      addLog("Pagar", "Faturas", f.numero);
    } catch (e) {
      setToast({
        message: e instanceof Error ? e.message : "Recebimento não confirmado.",
        type: "error",
      });
    }
  }
  function handleRemover(f: Fatura) {
    if (f.estado === "emitida" || f.estado === "paga") {
      setToast({
        message: `Não é possível eliminar "${f.numero}" com estado "${ESTADO_LABEL[f.estado]}"`,
        type: "error",
      });
      return;
    }
    setConfirmModal({
      title: "Eliminar Documento",
      message: `Deseja eliminar ${f.numero}?`,
      confirmText: "Eliminar",
      type: "danger",
      onConfirm: async () => {
        await removeFatura(f.id);
        setToast({ message: `${f.numero} eliminado!`, type: "success" });
        setConfirmModal(null);
        addLog("Eliminar", "Faturas", f.numero);
      },
    });
  }
  const filtered = useMemo(() => {
    let items = [...data.faturas];
    if (filtroEstado !== "todos")
      items = items.filter((f) => f.estado === filtroEstado);
    if (filtroTipo !== "todos")
      items = items.filter(
        (f) => (f.tipoDocumento || "factura") === filtroTipo,
      );
    if (search.trim()) {
      const q = search.toLowerCase();
      items = items.filter(
        (f) =>
          f.clienteNome.toLowerCase().includes(q) ||
          f.numero.toLowerCase().includes(q) ||
          (f.clienteNif || "").includes(q),
      );
    }
    return items.sort((a, b) => b.id - a.id);
  }, [data.faturas, filtroEstado, filtroTipo, search]);
  const rascunhos = filtered.filter((f) => f.estado === "rascunho");
  const outros = filtered.filter((f) => f.estado !== "rascunho");
  const catalogCats = useMemo(() => {
    const s = new Set<string>();
    for (const p of produtos) s.add(p.categoria || "Sem Categoria");
    return Array.from(s).sort();
  }, [produtos]);
  const produtosPorCategoria = useMemo(() => {
    const q = catalogSearch.trim().toLowerCase();
    const map: Record<string, typeof produtos> = {};
    for (const p of produtos) {
      const cat = p.categoria || "Sem Categoria";
      if (catalogCat && cat !== catalogCat) continue;
      if (
        q &&
        !p.nome.toLowerCase().includes(q) &&
        !(p.codigo || "").toLowerCase().includes(q)
      )
        continue;
      if (!map[cat]) map[cat] = [];
      map[cat].push(p);
    }
    return map;
  }, [produtos, catalogSearch, catalogCat]);
  const catalogTotalFiltrados = useMemo(
    () =>
      Object.values(produtosPorCategoria).reduce((s, arr) => s + arr.length, 0),
    [produtosPorCategoria],
  );
  const produtosGestao = useMemo(() => {
    let items = [...todosProdutos];
    if (gestaoCat)
      items = items.filter(
        (p) => (p.categoria || "Sem Categoria") === gestaoCat,
      );
    if (gestaoSearch.trim()) {
      const q = gestaoSearch.toLowerCase();
      items = items.filter(
        (p) =>
          p.nome.toLowerCase().includes(q) ||
          (p.codigo || "").toLowerCase().includes(q),
      );
    }
    return items.sort((a, b) => a.nome.localeCompare(b.nome));
  }, [todosProdutos, gestaoCat, gestaoSearch]);
  const clientesGestao = useMemo(() => {
    let items = [...data.pacientes];
    if (gestaoSearch.trim()) {
      const q = gestaoSearch.toLowerCase();
      items = items.filter(
        (p) =>
          p.nome.toLowerCase().includes(q) ||
          (p.nif || "").includes(q) ||
          (p.bi || "").toLowerCase().includes(q) ||
          (p.passaporte || "").toLowerCase().includes(q) ||
          (p.telefone || "").includes(q) ||
          (p.email || "").toLowerCase().includes(q),
      );
    }
    return items.sort((a, b) => a.nome.localeCompare(b.nome));
  }, [data.pacientes, gestaoSearch]);
  const stats = useMemo(() => {
    const hojeDate = new Date();
    const mesAtual = hojeDate.getMonth();
    const anoAtual = hojeDate.getFullYear();
    const faturasMes = data.faturas.filter((f) => {
      const p = f.data.split("/");
      if (p.length !== 3) return false;
      const d = new Date(`${p[2]}-${p[1]}-${p[0]}`);
      return d.getMonth() === mesAtual && d.getFullYear() === anoAtual;
    });
    const totalMes = faturasMes.reduce((s, f) => s + f.total, 0);
    const totalPago = faturasMes
      .filter((f) => f.estado === "paga")
      .reduce((s, f) => s + f.total, 0);
    const totalPendente = faturasMes
      .filter((f) => f.estado === "emitida")
      .reduce((s, f) => s + f.total, 0);
    const totalAnulado = faturasMes
      .filter((f) => f.estado === "anulada")
      .reduce((s, f) => s + f.total, 0);
    const clientesMap: Record<
      string,
      { nome: string; total: number; count: number }
    > = {};
    for (const f of data.faturas) {
      if (!clientesMap[f.clienteNome])
        clientesMap[f.clienteNome] = {
          nome: f.clienteNome,
          total: 0,
          count: 0,
        };
      clientesMap[f.clienteNome].total += f.total;
      clientesMap[f.clienteNome].count += 1;
    }
    const topClientes = Object.values(clientesMap)
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
    const produtosMap: Record<
      string,
      { nome: string; qtd: number; total: number }
    > = {};
    for (const f of data.faturas) {
      for (const l of f.linhas) {
        if (!produtosMap[l.descricao])
          produtosMap[l.descricao] = { nome: l.descricao, qtd: 0, total: 0 };
        produtosMap[l.descricao].qtd += l.quantidade;
        produtosMap[l.descricao].total += l.quantidade * l.precoUnitario;
      }
    }
    const topProdutos = Object.values(produtosMap)
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
    const stockBaixo = produtos.filter((p) => p.stock <= (p.stockMinimo || 0));
    return {
      totalMes,
      totalPago,
      totalPendente,
      totalAnulado,
      totalDocs: data.faturas.length,
      docsMes: faturasMes.length,
      topClientes,
      topProdutos,
      stockBaixo,
    };
  }, [data.faturas, produtos]);
  const dadosRelatorio = useMemo(() => {
    const faturasFiltradas = data.faturas.filter((f) => {
      const { mes, ano } = getMesAno(f.data);
      const hojeDate = new Date();
      const mesAtual = hojeDate.getMonth() + 1;
      const anoAtual = hojeDate.getFullYear();
      if (relatorioPeriodo === "dia") return f.data === hoje;
      if (relatorioPeriodo === "semana") {
        const diasAtras = addDays(hoje, -7);
        return f.data >= diasAtras && f.data <= hoje;
      }
      if (relatorioPeriodo === "mes")
        return mes === mesAtual && ano === anoAtual;
      if (relatorioPeriodo === "trimestre") {
        const tresMesesAtras = mesAtual - 3;
        return mes >= tresMesesAtras && mes <= mesAtual && ano === anoAtual;
      }
      if (relatorioPeriodo === "ano") return ano === anoAtual;
      return true;
    });
    const total = faturasFiltradas.reduce((s, f) => s + f.total, 0);
    const totalIva = faturasFiltradas.reduce((s, f) => s + f.totalIva, 0);
    const totalSemIva = faturasFiltradas.reduce(
      (s, f) => s + f.subtotalSemIva,
      0,
    );
    const totalPaga = faturasFiltradas
      .filter((f) => f.estado === "paga")
      .reduce((s, f) => s + f.total, 0);
    const totalEmitida = faturasFiltradas
      .filter((f) => f.estado === "emitida")
      .reduce((s, f) => s + f.total, 0);
    const porTipo: Record<string, { count: number; total: number }> = {};
    faturasFiltradas.forEach((f) => {
      const tipo = f.tipoDocumento || "factura";
      if (!porTipo[tipo]) porTipo[tipo] = { count: 0, total: 0 };
      porTipo[tipo].count += 1;
      porTipo[tipo].total += f.total;
    });
    const porEstado: Record<string, { count: number; total: number }> = {};
    faturasFiltradas.forEach((f) => {
      if (!porEstado[f.estado]) porEstado[f.estado] = { count: 0, total: 0 };
      porEstado[f.estado].count += 1;
      porEstado[f.estado].total += f.total;
    });
    const porFormaPag: Record<string, number> = {};
    faturasFiltradas
      .filter((f) => f.estado === "paga")
      .forEach((f) => {
        const forma = f.formaPagamento || "Não especificado";
        porFormaPag[forma] = (porFormaPag[forma] || 0) + f.total;
      });
    return {
      faturas: faturasFiltradas,
      total,
      totalIva,
      totalSemIva,
      totalPaga,
      totalEmitida,
      porTipo,
      porEstado,
      porFormaPag,
      count: faturasFiltradas.length,
    };
  }, [data.faturas, relatorioPeriodo, relatorioDataInicio, relatorioDataFim]);
  function addChatMessage(
    role: "user" | "assistant" | "system",
    content: string,
    attachments?: { type: string; url: string; name: string }[],
  ) {
    const msg: ChatMessage = {
      id: gerarId(),
      role,
      content,
      timestamp: nowTimeStr(),
      attachments,
    };
    setChatMessages((prev) => [...prev, msg]);
  }
  function processarComandoChat(texto: string): string {
    const textoLower = texto.toLowerCase().trim();
    if (
      textoLower.includes("faturar") ||
      textoLower.includes("facturar") ||
      textoLower.includes("criar factura")
    ) {
      setTimeout(() => {
        handleNovo();
        setShowChat(false);
      }, 500);
      return "Vou abrir o formulário de faturação para você!";
    }
    if (
      textoLower.includes("onde está") ||
      textoLower.includes("localizar") ||
      textoLower.includes("encontrar")
    ) {
      if (textoLower.includes("cliente")) {
        setTimeout(() => {
          setShowGestaoClientes(true);
          setShowChat(false);
        }, 500);
        return `Temos ${data.pacientes.length} clientes cadastrados.`;
      }
      if (textoLower.includes("produto")) {
        setTimeout(() => {
          setShowGestaoProdutos(true);
          setShowChat(false);
        }, 500);
        return `Temos ${produtos.length} produtos no catálogo.`;
      }
    }
    if (
      textoLower.includes("criar cliente") ||
      textoLower.includes("novo cliente")
    ) {
      setTimeout(() => {
        openNovoClienteModal();
        setShowChat(false);
      }, 500);
      return "Vou abrir o formulário de cadastro de cliente!";
    }
    if (
      textoLower.includes("criar produto") ||
      textoLower.includes("novo produto")
    ) {
      setTimeout(() => {
        openNovoProdutoModal();
        setShowChat(false);
      }, 500);
      return "Vou abrir o formulário de cadastro de produto!";
    }
    if (textoLower.includes("dashboard") || textoLower.includes("resumo")) {
      setTimeout(() => {
        setShowDashboard(true);
        setShowChat(false);
      }, 500);
      return `Este mês: ${formatCurrency(stats.totalMes, moeda)} faturado.`;
    }
    if (textoLower.includes("pos") || textoLower.includes("ponto de venda")) {
      setTimeout(() => {
        setShowProdutosPanel(true);
        setShowChat(false);
        setPosModoCaixa(true);
      }, 500);
      return "Abrindo o POS (Ponto de Venda) no modo caixa!";
    }
    if (textoLower.includes("ajuda")) {
      return "Posso ajudar com:\n• 📄 Faturar\n• 🔍 Localizar cliente/produto\n• 👤 Criar cliente\n• 📦 Criar produto\n• 📊 Dashboard\n• 💰 POS (Ponto de Venda)";
    }
    if (textoLower.includes("upload") || textoLower.includes("bi")) {
      setTimeout(() => {
        setShowUploadModal(true);
        setShowChat(false);
      }, 500);
      return "Abrindo upload de documento!";
    }
    return "Não entendi. Tente: 'faturar', 'dashboard', 'pos', 'ajuda'";
  }
  function handleChatSubmit() {
    if (!chatInput.trim()) return;
    const texto = chatInput.trim();
    addChatMessage("user", texto);
    setChatInput("");
    setIsProcessing(true);
    setTimeout(() => {
      const resposta = processarComandoChat(texto);
      addChatMessage("assistant", resposta);
      setIsProcessing(false);
    }, 800);
  }
  function toggleVoiceRecognition() {
    if (isListening) {
      if (recognitionRef.current) recognitionRef.current.stop();
      setIsListening(false);
      return;
    }
    if (
      !("webkitSpeechRecognition" in window) &&
      !("SpeechRecognition" in window)
    ) {
      setToast({
        message: "Reconhecimento de voz não suportado",
        type: "error",
      });
      return;
    }
    const SpeechRecognition =
      (window as any).webkitSpeechRecognition ||
      (window as any).SpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = "pt-PT";
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onstart = () => {
      setIsListening(true);
      setToast({ message: "🎤 Ouvindo...", type: "info" });
    };
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setChatInput(transcript);
      setToast({ message: `✓ ${transcript}`, type: "success" });
    };
    recognition.onerror = () => {
      setIsListening(false);
      setToast({ message: "Erro no reconhecimento", type: "error" });
    };
    recognition.onend = () => {
      setIsListening(false);
    };
    recognitionRef.current = recognition;
    recognition.start();
  }
  function handleUploadClick(tipo: "cliente" | "produto") {
    setUploadTipo(tipo);
    setUploadArquivo(null);
    setUploadPreview("");
    setUploadDadosExtraidos(null);
    setShowUploadModal(true);
  }
  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadArquivo(file);
    setUploadExtraindo(true);
    setUploadPreview("");
    setTimeout(() => {
      if (uploadTipo === "cliente") {
        const dadosSimulados: DadosExtraidosBI = {
          nome: "João Silva Santos",
          bi: "000000000LA000",
          dataNascimento: "15/03/1990",
          sexo: "M",
          naturalidade: "Luanda",
          filiacao: "Manuel Santos e Maria Silva",
          endereco: "Rua da Maianga, 123, Luanda",
          foto: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSI1MCIgY3k9IjUwIiByPSI1MCIgZmlsbD0iIzAwQUVFRiIvPjx0ZXh0IHg9IjUwIiB5PSI1NSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjQwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSI+SlM8L3RleHQ+PC9zdmc+",
        };
        setUploadDadosExtraidos(dadosSimulados);
        setUploadPreview(dadosSimulados.foto || "");
      } else {
        const dadosSimulados = {
          nome: "Produto Exemplo",
          codigo: "PRD" + Math.floor(Math.random() * 10000),
          preco: Math.floor(Math.random() * 10000) + 1000,
          categoria: catalogCats[0] || "Geral",
          descricao: "Descrição extraída automaticamente",
          stock: Math.floor(Math.random() * 100),
          stockMinimo: 10,
          ivaIsento: false,
        };
        setUploadDadosExtraidos(dadosSimulados);
      }
      setUploadExtraindo(false);
      setToast({ message: "✓ Dados extraídos!", type: "success" });
    }, 2000);
  }
  function aplicarDadosExtraidos() {
    if (!uploadDadosExtraidos) return;
    if (uploadTipo === "cliente") {
      const dados = uploadDadosExtraidos as DadosExtraidosBI;
      setNovoCliente({
        nome: dados.nome || "",
        bi: dados.bi || "",
        passaporte: "",
        nif: "",
        telefone: "",
        email: "",
        endereco: dados.endereco || "",
        observacoes: `Naturalidade: ${dados.naturalidade || ""} | Filiação: ${dados.filiacao || ""}`,
        tipoDocumento: "bi",
      });
      setShowUploadModal(false);
      setToast({ message: "Dados do cliente preenchidos!", type: "success" });
      setShowNovoCliente(true);
    } else {
      const dados = uploadDadosExtraidos;
      setNovoProduto({
        nome: dados.nome,
        codigo: dados.codigo,
        preco: dados.preco,
        categoria: dados.categoria,
        descricao: dados.descricao,
        stock: dados.stock,
        stockMinimo: dados.stockMinimo,
        ivaIsento: dados.ivaIsento,
      });
      setShowUploadModal(false);
      setToast({ message: "Dados do produto preenchidos!", type: "success" });
      setShowNovoProduto(true);
    }
  }
  function handleTipoDocumentoChange(novoTipo: string) {
    setTipoDocumento(novoTipo);
    const opt = TIPO_DOC_OPTS.find((t) => t.value === novoTipo);
    if (opt && editId === null)
      setEstado(opt.estadoDefault as Fatura["estado"]);
  }
  if (view === "form") {
    const tipoLabel =
      TIPO_DOC_OPTS.find((t) => t.value === tipoDocumento)?.label ??
      (tipoDocumento === "nota-credito" ? "Nota de Crédito" : "Factura");
    return (
      <div className="min-h-full bg-gray-100 relative">
        {toast && (
          <Toast
            message={toast.message}
            type={toast.type}
            onClose={() => setToast(null)}
          />
        )}
        <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm">
            <button
              onClick={() => {
                resetForm();
                setView("lista");
              }}
              className="text-[#00AEEF] hover:underline font-medium"
            >
              Documentos
            </button>
            <span className="text-gray-400">/</span>
            <span className="text-gray-600">
              {editId !== null ? `Editar ${tipoLabel}` : `Novo ${tipoLabel}`}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => openNovoProdutoModal()}
              className="text-xs px-3 py-1.5 rounded-lg font-semibold border border-violet-300 text-violet-600 hover:bg-violet-50 transition flex items-center gap-1.5"
            >
              📦 Criar Produto
            </button>
            <button
              onClick={() => openNovoClienteModal()}
              className="text-xs px-3 py-1.5 rounded-lg font-semibold border border-teal-300 text-teal-600 hover:bg-teal-50 transition flex items-center gap-1.5"
            >
              👤 Criar Cliente
            </button>
            <button
              onClick={() => setShowChat(true)}
              className="text-xs px-3 py-1.5 rounded-lg font-semibold border border-blue-300 text-blue-600 hover:bg-blue-50 transition flex items-center gap-1.5"
            >
              💬 Assistente
            </button>
          </div>
        </div>
        <div className="px-6 py-5 max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-4">
              <FTAvatar tipo={tipoDocumento} />
              <div>
                <h1 className="text-xl font-bold text-gray-800">{tipoLabel}</h1>
                <p className="text-xs text-gray-400">
                  {editId !== null
                    ? "Editar documento existente"
                    : "Estado inicial: " + ESTADO_LABEL[estado]}
                </p>
              </div>
            </div>
          </div>
          <div className="flex gap-5 items-start">
            <div className="flex-1 space-y-4 min-w-0">
              <div className="bg-white border border-gray-200 rounded-lg p-5">
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-semibold text-gray-700">
                    Seleccione o Cliente
                  </label>
                  <button
                    type="button"
                    onClick={() => openNovoClienteModal()}
                    className="text-xs text-teal-600 hover:underline font-semibold flex items-center gap-1"
                  >
                    + Novo Cliente
                  </button>
                </div>
                <select
                  value={pacienteId}
                  onChange={(e) => {
                    const p = data.pacientes.find(
                      (x) => x.id === parseInt(e.target.value),
                    );
                    setPacienteId(e.target.value);
                    if (p) {
                      setClienteNome(p.nome);
                      setClienteNif(p.nif || "");
                      setClienteEndereco(p.endereco || "");
                    } else {
                      setClienteNome("Consumidor Final");
                      setClienteNif("");
                      setClienteEndereco("");
                    }
                    setNifError("");
                  }}
                  className="w-full border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none focus:border-[#00AEEF] bg-white text-gray-600"
                >
                  <option value="">Consumidor Final</option>
                  {data.pacientes.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.nome}
                    </option>
                  ))}
                </select>
                <div className="mt-3 space-y-2">
                  <div>
                    <p className="text-xs font-bold text-gray-500 uppercase tracking-wide flex items-center gap-1">
                      NIF / BI / Passaporte
                      {clienteNome && clienteNome !== "Consumidor Final" && (
                        <span className="text-red-500">*</span>
                      )}
                    </p>
                    <input
                      value={clienteNif}
                      onChange={(e) => {
                        setClienteNif(e.target.value);
                        setNifError("");
                      }}
                      className={`mt-0.5 w-full border-0 border-b py-1 text-sm text-gray-700 focus:outline-none bg-transparent transition-colors ${nifError ? "border-red-400 focus:border-red-500" : "border-gray-200 focus:border-[#00AEEF]"}`}
                      placeholder="NIF (9/14 dígitos) · BI (14 caracteres) · Passaporte"
                    />
                    {nifError && (
                      <p className="text-xs text-red-500 mt-1">{nifError}</p>
                    )}
                    <p className="text-xs text-gray-400 mt-1">
                      💡 Aceita NIF, BI angolano (14 caracteres) ou Passaporte
                    </p>
                  </div>
                  {clienteNome && clienteNome !== "Consumidor Final" && (
                    <div>
                      <p className="text-xs font-bold text-gray-500 uppercase tracking-wide">
                        Nome
                      </p>
                      <input
                        value={clienteNome}
                        onChange={(e) => setClienteNome(e.target.value)}
                        className="mt-0.5 w-full border-0 border-b border-gray-200 py-1 text-sm text-gray-700 focus:outline-none focus:border-[#00AEEF] bg-transparent"
                      />
                    </div>
                  )}
                  {clienteEndereco && (
                    <div>
                      <p className="text-xs font-bold text-gray-500 uppercase tracking-wide">
                        Morada
                      </p>
                      <input
                        value={clienteEndereco}
                        onChange={(e) => setClienteEndereco(e.target.value)}
                        className="mt-0.5 w-full border-0 border-b border-gray-200 py-1 text-sm text-gray-700 focus:outline-none focus:border-[#00AEEF] bg-transparent"
                      />
                    </div>
                  )}
                </div>
                <div className="flex gap-5 mt-3">
                  <button
                    onClick={() => {
                      setClienteNome("Consumidor Final");
                      setClienteNif("");
                      setClienteEndereco("");
                      setPacienteId("");
                      setNifError("");
                    }}
                    className="text-xs text-[#00AEEF] hover:underline flex items-center gap-1"
                  >
                    👤 Consumidor Final
                  </button>
                </div>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg shadow-sm">
                <div className="flex items-center justify-between px-5 py-3 border-b border-gray-100">
                  <div>
                    <h3 className="text-sm font-bold text-gray-800">Itens</h3>
                    <p className="text-xs text-gray-400">Produtos e Serviços</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded font-medium">
                      {linhas.length} item{linhas.length !== 1 ? "s" : ""}
                    </span>
                    <button
                      onClick={() => openNovoProdutoModal(produtoSearch.trim())}
                      className="text-xs px-3 py-1.5 rounded-lg font-semibold border border-violet-300 text-violet-600 hover:bg-violet-50 transition flex items-center gap-1.5"
                    >
                      + Produto
                    </button>
                    <button
                      onClick={() => setShowProdutosPanel((v) => !v)}
                      className={`text-xs px-3 py-1.5 rounded-lg font-semibold border transition flex items-center gap-1.5 ${showProdutosPanel ? "bg-[#00AEEF] text-white border-[#00AEEF]" : "border-[#00AEEF] text-[#00AEEF] hover:bg-[#00AEEF]/10"}`}
                    >
                      📦 {showProdutosPanel ? "Ocultar" : "Ver"} Produtos
                    </button>
                  </div>
                </div>
                {linhas.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b border-gray-100">
                        <tr>
                          <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">
                            Produto / Serviço
                          </th>
                          <th className="text-center px-2 py-2 text-xs font-semibold text-gray-500 w-20">
                            Unid.
                          </th>
                          <th className="text-center px-2 py-2 text-xs font-semibold text-gray-500">
                            IVA
                          </th>
                          <th className="text-right px-2 py-2 text-xs font-semibold text-gray-500">
                            P.Unit.
                          </th>
                          <th className="text-center px-2 py-2 text-xs font-semibold text-gray-500">
                            Qtd.
                          </th>
                          <th className="text-right px-4 py-2 text-xs font-semibold text-gray-500">
                            Total
                          </th>
                          <th className="w-8 px-2 py-2"></th>
                        </tr>
                      </thead>
                      <tbody>
                        {linhas.map((l, i) => {
                          const sub = l.quantidade * l.precoUnitario;
                          return (
                            <tr
                              key={i}
                              className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors"
                            >
                              <td className="px-4 py-2.5">
                                <input
                                  value={l.descricao}
                                  onChange={(e) =>
                                    handleUpdateLinha(
                                      i,
                                      "descricao",
                                      e.target.value,
                                    )
                                  }
                                  className="text-sm font-medium text-gray-800 w-full border-0 border-b border-transparent hover:border-gray-200 focus:border-[#00AEEF] focus:outline-none bg-transparent py-0.5 transition-colors"
                                />
                              </td>
                              <td className="px-2 py-2.5 text-center">
                                <input
                                  value={l.unidade ?? ""}
                                  onChange={(e) =>
                                    handleUpdateLinha(
                                      i,
                                      "unidade",
                                      e.target.value,
                                    )
                                  }
                                  placeholder="un"
                                  className="w-16 text-xs text-center border border-gray-200 rounded px-1 py-1 focus:outline-none focus:border-[#00AEEF]"
                                />
                              </td>
                              <td className="px-2 py-2.5 text-center">
                                <button
                                  onClick={() =>
                                    handleUpdateLinha(
                                      i,
                                      "ivaIsento",
                                      !l.ivaIsento,
                                    )
                                  }
                                  className={`text-xs px-2 py-0.5 rounded-full font-semibold transition-colors ${l.ivaIsento ? "bg-gray-100 text-gray-500" : "bg-blue-50 text-blue-600"}`}
                                >
                                  {l.ivaIsento ? "Isento" : `${ivaTaxa}%`}
                                </button>
                              </td>
                              <td className="px-2 py-2.5 text-right">
                                <input
                                  type="number"
                                  value={l.precoUnitario}
                                  min={0}
                                  step={0.01}
                                  onChange={(e) =>
                                    handleUpdateLinha(
                                      i,
                                      "precoUnitario",
                                      Number(e.target.value),
                                    )
                                  }
                                  className="w-24 border border-gray-200 rounded px-2 py-1 text-xs text-right focus:outline-none focus:border-[#00AEEF]"
                                />
                              </td>
                              <td className="px-2 py-2.5 text-center">
                                <div className="flex items-center justify-center gap-1">
                                  <button
                                    onClick={() =>
                                      handleUpdateLinha(
                                        i,
                                        "quantidade",
                                        Math.max(-999, l.quantidade - 1),
                                      )
                                    }
                                    className="w-5 h-5 rounded border border-gray-200 text-gray-400 hover:border-[#00AEEF] hover:text-[#00AEEF] flex items-center justify-center text-xs transition-colors"
                                  >
                                    −
                                  </button>
                                  <input
                                    type="number"
                                    value={l.quantidade}
                                    onChange={(e) =>
                                      handleUpdateLinha(
                                        i,
                                        "quantidade",
                                        Number(e.target.value),
                                      )
                                    }
                                    className="w-12 border border-gray-200 rounded px-1 py-1 text-xs text-center focus:outline-none focus:border-[#00AEEF]"
                                  />
                                  <button
                                    onClick={() =>
                                      handleUpdateLinha(
                                        i,
                                        "quantidade",
                                        l.quantidade + 1,
                                      )
                                    }
                                    className="w-5 h-5 rounded border border-gray-200 text-gray-400 hover:border-[#00AEEF] hover:text-[#00AEEF] flex items-center justify-center text-xs transition-colors"
                                  >
                                    +
                                  </button>
                                </div>
                              </td>
                              <td className="px-4 py-2.5 text-right">
                                <span className="text-sm font-bold text-gray-800">
                                  {formatCurrency(sub, moeda)}
                                </span>
                              </td>
                              <td className="px-2 py-2.5 text-center">
                                <button
                                  onClick={() => handleRemoverLinha(i)}
                                  className="w-6 h-6 rounded-full border border-red-200 text-red-400 hover:bg-red-50 hover:border-red-400 flex items-center justify-center text-xs font-bold transition-all"
                                >
                                  ×
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                    <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-end gap-6 bg-gray-50/50">
                      <div className="flex flex-col items-end gap-1 text-xs text-gray-500">
                        <div className="flex gap-4">
                          <span>Subtotal s/IVA</span>
                          <span className="font-semibold w-32 text-right">
                            {formatCurrency(totals.subtotalSemIva, moeda)}
                          </span>
                        </div>
                        <div className="flex gap-4">
                          <span>IVA ({ivaTaxa}%)</span>
                          <span className="font-semibold w-32 text-right">
                            {formatCurrency(totals.totalIva, moeda)}
                          </span>
                        </div>
                        <div className="flex gap-4 pt-1 border-t border-gray-200 mt-1">
                          <span className="text-sm font-bold text-gray-700">
                            Total
                          </span>
                          <span className="text-sm font-black text-[#00AEEF] w-32 text-right">
                            {formatCurrency(totals.total, moeda)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="py-10 flex flex-col items-center text-gray-300">
                    <div className="text-4xl mb-2">📦</div>
                    <p className="text-sm text-gray-400">
                      Nenhum item adicionado.
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      Pesquise abaixo ou clique em "Ver Produtos".
                    </p>
                  </div>
                )}
                <div className="px-5 py-4 border-t border-gray-100">
                  <div className="relative">
                    <div
                      className={`flex items-center gap-2 border rounded-lg bg-white px-3 py-2.5 transition-all ${showDropdown ? "border-[#00AEEF] ring-2 ring-[#00AEEF]/20" : "border-gray-200 hover:border-gray-300"}`}
                    >
                      <div className="flex items-center gap-1 border-r border-gray-200 pr-2 mr-1">
                        <button
                          type="button"
                          onClick={() =>
                            setProdutoQtd((q) => Math.max(1, q - 1))
                          }
                          className="w-6 h-6 rounded-full border border-[#00AEEF] text-[#00AEEF] flex items-center justify-center text-sm font-bold hover:bg-[#00AEEF] hover:text-white transition-all flex-shrink-0"
                        >
                          −
                        </button>
                        <input
                          type="number"
                          value={produtoQtd}
                          min={1}
                          onChange={(e) =>
                            setProdutoQtd(Math.max(1, Number(e.target.value)))
                          }
                          className="w-8 text-center text-sm border-0 focus:outline-none font-semibold text-gray-700"
                        />
                        <button
                          type="button"
                          onClick={() => setProdutoQtd((q) => q + 1)}
                          className="w-6 h-6 rounded-full border border-[#00AEEF] text-[#00AEEF] flex items-center justify-center text-sm font-bold hover:bg-[#00AEEF] hover:text-white transition-all flex-shrink-0"
                        >
                          +
                        </button>
                      </div>
                      <span className="text-gray-400 text-sm">🔍</span>
                      <input
                        ref={searchInputRef}
                        value={produtoSearch}
                        onChange={(e) => setProdutoSearch(e.target.value)}
                        onKeyDown={handleSearchKeyDown}
                        onFocus={() => {
                          if (produtosFiltrados.length > 0)
                            setShowDropdown(true);
                        }}
                        placeholder="Pesquisar produto por nome ou código..."
                        className="flex-1 text-sm focus:outline-none text-gray-700 placeholder-gray-400 bg-transparent"
                      />
                      {produtoSearch && (
                        <button
                          type="button"
                          onClick={() => {
                            setProdutoSearch("");
                            setShowDropdown(false);
                            searchInputRef.current?.focus();
                          }}
                          className="text-gray-300 hover:text-gray-500 text-lg leading-none transition-colors flex-shrink-0"
                        >
                          ×
                        </button>
                      )}
                    </div>
                    {showDropdown && produtosFiltrados.length > 0 && (
                      <div
                        ref={dropdownRef}
                        className="absolute left-0 right-0 top-full mt-1 bg-white border border-gray-200 rounded-xl shadow-2xl z-50 overflow-hidden"
                      >
                        <div className="px-3 py-2 border-b border-gray-50 bg-gray-50/50">
                          <span className="text-xs text-gray-400 font-medium">
                            {produtosFiltrados.length} produto
                            {produtosFiltrados.length !== 1 ? "s" : ""}
                          </span>
                        </div>
                        {produtosFiltrados.map((p, idx) => (
                          <button
                            key={p.id}
                            type="button"
                            onMouseDown={(e) => e.preventDefault()}
                            onClick={() => handleAddProduto(p)}
                            className={`w-full flex items-center justify-between px-4 py-3 transition-colors text-left border-b border-gray-50 last:border-0 ${dropdownIndex === idx ? "bg-[#00AEEF]/10" : "hover:bg-gray-50"}`}
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="w-8 h-8 rounded-lg bg-[#00AEEF]/10 flex items-center justify-center flex-shrink-0">
                                <span className="text-[#00AEEF] text-xs font-bold">
                                  {p.nome.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <div className="min-w-0">
                                <div className="text-sm font-semibold text-gray-800 truncate">
                                  {p.nome}
                                </div>
                                <div className="text-xs text-gray-400">
                                  {p.codigo}
                                </div>
                              </div>
                            </div>
                            <div className="text-right flex-shrink-0 ml-4">
                              <div className="text-sm font-bold text-[#00AEEF]">
                                {formatCurrency(p.preco, moeda)}
                              </div>
                              {p.ivaIsento && (
                                <div className="text-xs text-gray-400">
                                  IVA isento
                                </div>
                              )}
                            </div>
                          </button>
                        ))}
                        <button
                          type="button"
                          onMouseDown={(e) => e.preventDefault()}
                          onClick={() =>
                            openNovoProdutoModal(produtoSearch.trim())
                          }
                          className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 transition-colors border-t border-gray-100 text-left"
                        >
                          <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center flex-shrink-0">
                            <span className="text-emerald-500 text-sm font-bold">
                              +
                            </span>
                          </div>
                          <span className="text-sm text-gray-500">
                            Criar produto{" "}
                            <span className="font-semibold text-gray-700">
                              "{produtoSearch}"
                            </span>
                          </span>
                        </button>
                      </div>
                    )}
                    {produtoSearch.trim() &&
                      !showDropdown &&
                      produtosFiltrados.length === 0 && (
                        <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-gray-200 rounded-xl shadow-xl z-50 overflow-hidden">
                          <div className="px-4 py-3 flex items-center justify-between">
                            <span className="text-sm text-gray-400">
                              Nenhum produto para{" "}
                              <span className="font-semibold text-gray-600">
                                "{produtoSearch}"
                              </span>
                            </span>
                            <button
                              type="button"
                              onMouseDown={(e) => e.preventDefault()}
                              onClick={() =>
                                openNovoProdutoModal(produtoSearch.trim())
                              }
                              className="text-xs text-violet-600 hover:underline font-semibold ml-3 flex-shrink-0"
                            >
                              + Criar produto
                            </button>
                          </div>
                        </div>
                      )}
                  </div>
                  <p className="text-xs text-gray-400 mt-2">
                    ↑↓ navegar · Enter seleccionar · Esc fechar
                  </p>
                </div>
              </div>
              {showProdutosPanel && (
                <div
                  className={`bg-white border border-[#00AEEF]/30 rounded-xl overflow-hidden shadow-lg ${posModoCaixa ? "ring-2 ring-emerald-400" : ""}`}
                >
                  <div className="px-5 py-3 bg-gradient-to-r from-[#00AEEF]/10 via-[#00AEEF]/5 to-emerald-50 border-b border-gray-100 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div>
                        <h3 className="text-sm font-bold text-gray-800 flex items-center gap-2">
                          💰 POS - Ponto de Venda
                          {posModoCaixa && (
                            <span className="text-[10px] bg-emerald-500 text-white px-2 py-0.5 rounded-full font-bold animate-pulse">
                              MODO CAIXA
                            </span>
                          )}
                          <span className="text-xs bg-[#00AEEF] text-white px-2 py-0.5 rounded-full font-bold">
                            {produtos.length}
                          </span>
                        </h3>
                        <p className="text-xs text-gray-500 mt-0.5">
                          {posFiltroRapido === "todos" &&
                          catalogCat === null &&
                          !catalogSearch
                            ? `${catalogCats.length} categorias · ${produtos.length} produtos`
                            : `${produtosPOSFiltrados.length} de ${produtos.length} produtos`}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex bg-gray-100 rounded-lg p-0.5">
                        {(["pequeno", "medio", "grande"] as const).map((t) => (
                          <button
                            key={t}
                            onClick={() => setPosTamanhoCard(t)}
                            className={`px-2 py-1 rounded text-[10px] font-semibold transition ${posTamanhoCard === t ? "bg-white text-[#00AEEF] shadow-sm" : "text-gray-500"}`}
                            title={`Tamanho ${t}`}
                          >
                            {t === "pequeno" ? "▪" : t === "medio" ? "▫" : "◻"}
                          </button>
                        ))}
                      </div>
                      <div className="flex bg-gray-100 rounded-lg p-0.5">
                        <button
                          onClick={() => setCatalogViewMode("grid")}
                          className={`px-2 py-1 rounded text-xs font-semibold transition ${catalogViewMode === "grid" ? "bg-white text-[#00AEEF] shadow-sm" : "text-gray-500"}`}
                        >
                          ▦
                        </button>
                        <button
                          onClick={() => setCatalogViewMode("list")}
                          className={`px-2 py-1 rounded text-xs font-semibold transition ${catalogViewMode === "list" ? "bg-white text-[#00AEEF] shadow-sm" : "text-gray-500"}`}
                        >
                          ☰
                        </button>
                      </div>
                      <button
                        onClick={() => setPosShowCarrinho((v) => !v)}
                        className={`relative px-2 py-1 rounded-lg text-xs font-semibold transition ${posShowCarrinho ? "bg-emerald-500 text-white" : "bg-gray-100 text-gray-600"}`}
                        title="Mostrar/ocultar carrinho"
                      >
                        🛒
                        {posCarrinho.length > 0 && (
                          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                            {posCarrinho.length}
                          </span>
                        )}
                      </button>
                      <button
                        onClick={() => setPosModoCaixa((v) => !v)}
                        className={`px-2 py-1 rounded-lg text-xs font-semibold transition ${posModoCaixa ? "bg-emerald-500 text-white" : "bg-gray-100 text-gray-600"}`}
                        title="Modo Caixa (F11)"
                      >
                        🏪
                      </button>
                      <button
                        onClick={() => {
                          setShowProdutosPanel(false);
                          setCatalogSearch("");
                          setCatalogCat(null);
                        }}
                        className="text-gray-400 hover:text-gray-600 w-7 h-7 flex items-center justify-center rounded hover:bg-gray-100"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                  <div className="px-5 py-2 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white flex items-center gap-2 overflow-x-auto">
                    {POS_ATALHOS_TECLADO.map((at) => (
                      <button
                        key={at.tecla}
                        onClick={() =>
                          setPosFiltroRapido(at.acao as POSFiltroRapido)
                        }
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap ${
                          posFiltroRapido === at.acao
                            ? "bg-[#00AEEF] text-white shadow-sm"
                            : "bg-white text-gray-600 border border-gray-200 hover:border-[#00AEEF] hover:text-[#00AEEF]"
                        }`}
                      >
                        <span>{at.icon}</span>
                        <span>{at.label}</span>
                        <kbd className="text-[9px] opacity-60 ml-1">
                          {at.tecla}
                        </kbd>
                      </button>
                    ))}
                  </div>
                  <div className="px-5 py-2 border-b border-gray-100 bg-gradient-to-r from-violet-50/50 to-white flex items-center gap-2">
                    <span className="text-sm">📱</span>
                    <input
                      ref={posBarcodeRef}
                      type="text"
                      value={posBarcodeInput}
                      onChange={(e) => setPosBarcodeInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && posBarcodeInput.trim()) {
                          e.preventDefault();
                          processarBarcode(posBarcodeInput.trim());
                        }
                      }}
                      placeholder="Leia ou digite o código de barras e pressione Enter (F7)"
                      className="flex-1 text-sm border border-gray-200 rounded-lg px-3 py-1.5 focus:outline-none focus:border-violet-400 bg-white"
                    />
                    <kbd className="text-[9px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded">
                      F7
                    </kbd>
                  </div>
                  <div className="px-5 py-3 border-b border-gray-100 bg-gray-50/50 space-y-2">
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                          🔍
                        </span>
                        <input
                          type="text"
                          value={catalogSearch}
                          onChange={(e) => setCatalogSearch(e.target.value)}
                          placeholder="Pesquisar por nome ou código..."
                          className="w-full pl-9 pr-8 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#00AEEF] bg-white"
                        />
                        {catalogSearch && (
                          <button
                            type="button"
                            onClick={() => setCatalogSearch("")}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          >
                            ×
                          </button>
                        )}
                      </div>
                      <select
                        value={posOrdenacao}
                        onChange={(e) =>
                          setPosOrdenacao(e.target.value as POSOrdenacao)
                        }
                        className="border border-gray-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-[#00AEEF] bg-white"
                      >
                        <option value="nome">🔤 Nome (A-Z)</option>
                        <option value="preco_asc">💰 Preço ↑</option>
                        <option value="preco_desc">💰 Preço ↓</option>
                        <option value="popularidade">🔥 Popularidade</option>
                        <option value="recentes">🕐 Recentes</option>
                      </select>
                    </div>
                    {catalogCats.length > 0 && (
                      <div className="flex gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => setCatalogCat(null)}
                          className={`px-3 py-1 rounded-full text-xs font-semibold transition ${catalogCat === null ? "bg-[#00AEEF] text-white shadow-sm" : "bg-white text-gray-600 border border-gray-200 hover:border-[#00AEEF] hover:text-[#00AEEF]"}`}
                        >
                          📋 Todas ({produtos.length})
                        </button>
                        {catalogCats.map((cat) => {
                          const count = produtos.filter(
                            (p) => (p.categoria || "Sem Categoria") === cat,
                          ).length;
                          const icon = POS_CATEGORIA_ICONS[cat] || "📁";
                          return (
                            <button
                              key={cat}
                              type="button"
                              onClick={() =>
                                setCatalogCat(catalogCat === cat ? null : cat)
                              }
                              className={`px-3 py-1 rounded-full text-xs font-semibold transition ${catalogCat === cat ? "bg-[#00AEEF] text-white shadow-sm" : "bg-white text-gray-600 border border-gray-200 hover:border-[#00AEEF] hover:text-[#00AEEF]"}`}
                            >
                              {icon} {cat} ({count})
                            </button>
                          );
                        })}
                      </div>
                    )}
                    <div className="flex items-center gap-3 text-xs">
                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={posMostrarSemStock}
                          onChange={(e) =>
                            setPosMostrarSemStock(e.target.checked)
                          }
                          className="w-3.5 h-3.5 accent-[#00AEEF]"
                        />
                        <span className="text-gray-600">Mostrar sem stock</span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        <span className="text-gray-500">Preço:</span>
                        <input
                          type="number"
                          value={posPrecoIntervalo[0]}
                          min={0}
                          onChange={(e) =>
                            setPosPrecoIntervalo([
                              Number(e.target.value),
                              posPrecoIntervalo[1],
                            ])
                          }
                          className="w-20 border border-gray-200 rounded px-2 py-0.5 text-xs"
                          placeholder="Min"
                        />
                        <span className="text-gray-400">até</span>
                        <input
                          type="number"
                          value={posPrecoIntervalo[1]}
                          min={0}
                          onChange={(e) =>
                            setPosPrecoIntervalo([
                              posPrecoIntervalo[0],
                              Number(e.target.value),
                            ])
                          }
                          className="w-20 border border-gray-200 rounded px-2 py-0.5 text-xs"
                          placeholder="Max"
                        />
                        <span className="text-gray-400">{moeda}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex">
                    <div
                      className={`max-h-[600px] overflow-y-auto ${posShowCarrinho ? "flex-1" : "w-full"}`}
                    >
                      {produtosPOSFiltrados.length === 0 ? (
                        <div className="py-12 text-center text-gray-400">
                          <div className="text-5xl mb-3 opacity-30">📦</div>
                          <p className="text-sm font-medium">
                            {produtos.length === 0
                              ? "Sem produtos cadastrados."
                              : "Nenhum produto corresponde aos filtros."}
                          </p>
                          {produtos.length === 0 && (
                            <button
                              onClick={() => openNovoProdutoModal()}
                              className="mt-3 text-xs text-[#00AEEF] hover:underline font-semibold"
                            >
                              + Criar primeiro produto
                            </button>
                          )}
                        </div>
                      ) : catalogViewMode === "grid" ? (
                        <div className="p-4">
                          {Object.entries(
                            produtosPOSFiltrados.reduce(
                              (acc, p) => {
                                const cat = p.categoria || "Sem Categoria";
                                if (!acc[cat]) acc[cat] = [];
                                acc[cat].push(p);
                                return acc;
                              },
                              {} as Record<string, typeof produtos>,
                            ),
                          ).map(([cat, prods]) => (
                            <div key={cat} className="mb-4">
                              <div className="flex items-center gap-2 mb-2 sticky top-0 bg-white py-1 z-10">
                                <span className="text-base">
                                  {POS_CATEGORIA_ICONS[cat] || "📁"}
                                </span>
                                <div className="w-1 h-4 bg-[#00AEEF] rounded-full"></div>
                                <span className="text-xs font-bold text-gray-700 uppercase tracking-wide">
                                  {cat}
                                </span>
                                <span className="text-xs text-gray-400">
                                  ({prods.length})
                                </span>
                              </div>
                              <div
                                className={`grid gap-2 ${
                                  posTamanhoCard === "pequeno"
                                    ? "grid-cols-4 sm:grid-cols-5 lg:grid-cols-6"
                                    : posTamanhoCard === "medio"
                                      ? "grid-cols-3 sm:grid-cols-4 lg:grid-cols-5"
                                      : "grid-cols-2 sm:grid-cols-3 lg:grid-cols-4"
                                }`}
                              >
                                {prods.map((p, idx) => (
                                  <POSProdutoCard
                                    key={p.id}
                                    produto={p}
                                    moeda={moeda}
                                    ivaTaxaDefault={ivaTaxaDefault}
                                    onAdd={() => {
                                      const qtd = prompt(
                                        `Quantidade de "${p.nome}":`,
                                        "1",
                                      );
                                      if (qtd !== null) {
                                        const q = Math.max(1, Number(qtd) || 1);
                                        adicionarAoCarrinhoPOS(p, q);
                                      }
                                    }}
                                    onQuickAdd={() => adicionarAoCarrinhoPOS(p)}
                                    onFavoritar={() => toggleFavorito(p.id)}
                                    isFavorito={posFavoritos.some(
                                      (f) => f.produtoId === p.id,
                                    )}
                                    promocao={getPromocaoAtiva(p.id)}
                                    tamanho={posTamanhoCard}
                                    atalhoNumero={idx < 9 ? idx + 1 : undefined}
                                  />
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div>
                          {Object.entries(
                            produtosPOSFiltrados.reduce(
                              (acc, p) => {
                                const cat = p.categoria || "Sem Categoria";
                                if (!acc[cat]) acc[cat] = [];
                                acc[cat].push(p);
                                return acc;
                              },
                              {} as Record<string, typeof produtos>,
                            ),
                          ).map(([cat, prods]) => (
                            <div key={cat}>
                              <div className="px-5 py-2 bg-gray-50 border-b border-gray-100 sticky top-0 flex items-center gap-2 z-10">
                                <span className="text-base">
                                  {POS_CATEGORIA_ICONS[cat] || "📁"}
                                </span>
                                <div className="w-1 h-4 bg-[#00AEEF] rounded-full"></div>
                                <span className="text-xs font-bold text-gray-700 uppercase tracking-wide">
                                  {cat}
                                </span>
                                <span className="text-xs text-gray-400">
                                  ({prods.length})
                                </span>
                              </div>
                              {prods.map((p, idx) => {
                                const promocao = getPromocaoAtiva(p.id);
                                const precoComDesconto =
                                  promocao && promocao.ativa
                                    ? p.preco * (1 - promocao.desconto / 100)
                                    : p.preco;
                                return (
                                  <div
                                    key={p.id}
                                    className="flex items-center gap-3 px-5 py-2 hover:bg-[#00AEEF]/5 transition-colors border-b border-gray-50 group"
                                  >
                                    {idx < 9 && (
                                      <span className="w-5 h-5 rounded-full bg-gray-800 text-white text-[10px] font-bold flex items-center justify-center flex-shrink-0">
                                        {idx + 1}
                                      </span>
                                    )}
                                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#00AEEF]/20 to-[#00AEEF]/5 flex items-center justify-center flex-shrink-0">
                                      <span className="text-sm">
                                        {POS_CATEGORIA_ICONS[
                                          p.categoria || "Sem Categoria"
                                        ] || "📦"}
                                      </span>
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <div className="text-sm font-semibold text-gray-800 truncate group-hover:text-[#00AEEF] transition-colors">
                                        {p.nome}
                                      </div>
                                      <div className="flex items-center gap-2 mt-0.5">
                                        {p.codigo && (
                                          <span className="text-[10px] text-gray-400 font-mono">
                                            {p.codigo}
                                          </span>
                                        )}
                                        {p.ivaIsento ? (
                                          <span className="text-[10px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded">
                                            s/IVA
                                          </span>
                                        ) : (
                                          <span className="text-[10px] bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded">
                                            {ivaTaxaDefault}%
                                          </span>
                                        )}
                                        {promocao && promocao.ativa && (
                                          <span className="text-[10px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded font-bold">
                                            -{promocao.desconto}%
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                    <div className="text-right flex-shrink-0">
                                      {promocao && promocao.ativa ? (
                                        <div>
                                          <div className="text-sm font-black text-red-600">
                                            {formatCurrency(
                                              precoComDesconto,
                                              moeda,
                                            )}
                                          </div>
                                          <div className="text-[10px] text-gray-400 line-through">
                                            {formatCurrency(p.preco, moeda)}
                                          </div>
                                        </div>
                                      ) : (
                                        <div className="text-sm font-black text-[#00AEEF]">
                                          {formatCurrency(p.preco, moeda)}
                                        </div>
                                      )}
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => toggleFavorito(p.id)}
                                      className={`w-6 h-6 rounded-full flex items-center justify-center transition ${
                                        posFavoritos.some(
                                          (f) => f.produtoId === p.id,
                                        )
                                          ? "bg-amber-400 text-white"
                                          : "bg-gray-100 text-gray-300 hover:text-amber-400 opacity-0 group-hover:opacity-100"
                                      }`}
                                    >
                                      ★
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => adicionarAoCarrinhoPOS(p)}
                                      className="bg-[#00AEEF] text-white text-[10px] font-bold px-3 py-1.5 rounded hover:bg-[#0099d4] transition flex-shrink-0"
                                    >
                                      + Adicionar
                                    </button>
                                  </div>
                                );
                              })}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    {posShowCarrinho && (
                      <div className="w-80 border-l border-gray-200 bg-gradient-to-b from-emerald-50/30 to-white flex flex-col max-h-[600px]">
                        <div className="px-4 py-3 border-b border-gray-200 bg-gradient-to-r from-emerald-500 to-teal-500 text-white">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="text-xl">🛒</span>
                              <div>
                                <div className="text-sm font-bold">
                                  Carrinho POS
                                </div>
                                <div className="text-[10px] opacity-90">
                                  {totaisCarrinhoPOS.itens} item(s)
                                </div>
                              </div>
                            </div>
                            {posCarrinho.length > 0 && (
                              <button
                                onClick={limparCarrinhoPOS}
                                className="text-[10px] bg-white/20 hover:bg-white/30 px-2 py-1 rounded transition"
                                title="Limpar carrinho"
                              >
                                🗑 Limpar
                              </button>
                            )}
                          </div>
                        </div>
                        <div className="flex-1 overflow-y-auto p-3 space-y-2">
                          {posCarrinho.length === 0 ? (
                            <div className="py-8 text-center text-gray-400">
                              <div className="text-4xl mb-2 opacity-30">🛒</div>
                              <p className="text-xs">Carrinho vazio</p>
                              <p className="text-[10px] mt-1">
                                Clique nos produtos para adicionar
                              </p>
                            </div>
                          ) : (
                            posCarrinho.map((item) => (
                              <POSCarrinhoItem
                                key={item.produtoId}
                                item={item}
                                moeda={moeda}
                                onUpdateQtd={(q) =>
                                  atualizarQtdCarrinho(item.produtoId, q)
                                }
                                onRemove={() =>
                                  removerDoCarrinho(item.produtoId)
                                }
                                onDesconto={(d) =>
                                  aplicarDescontoCarrinho(item.produtoId, d)
                                }
                              />
                            ))
                          )}
                        </div>
                        {posCarrinho.length > 0 && (
                          <div className="border-t border-gray-200 bg-white p-3 space-y-2">
                            <div className="space-y-1 text-xs">
                              <div className="flex justify-between text-gray-600">
                                <span>Subtotal</span>
                                <span className="font-semibold">
                                  {formatCurrency(
                                    totaisCarrinhoPOS.subtotal,
                                    moeda,
                                  )}
                                </span>
                              </div>
                              {totaisCarrinhoPOS.totalDescontos > 0 && (
                                <div className="flex justify-between text-red-500">
                                  <span>Descontos</span>
                                  <span className="font-semibold">
                                    -
                                    {formatCurrency(
                                      totaisCarrinhoPOS.totalDescontos,
                                      moeda,
                                    )}
                                  </span>
                                </div>
                              )}
                              <div className="flex justify-between text-gray-600">
                                <span>IVA ({ivaTaxaDefault}%)</span>
                                <span className="font-semibold">
                                  {formatCurrency(
                                    totaisCarrinhoPOS.totalIva,
                                    moeda,
                                  )}
                                </span>
                              </div>
                              <div className="flex justify-between text-sm font-black text-gray-900 pt-1 border-t border-gray-200">
                                <span>TOTAL</span>
                                <span className="text-emerald-600">
                                  {formatCurrency(
                                    totaisCarrinhoPOS.total,
                                    moeda,
                                  )}
                                </span>
                              </div>
                            </div>
                            <div className="flex gap-2 pt-2">
                              <button
                                onClick={transferirCarrinhoParaFatura}
                                className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold py-2 rounded-lg transition flex items-center justify-center gap-1"
                                title="Transferir para a fatura (F8)"
                              >
                                📄 Transferir (F8)
                              </button>
                              <button
                                onClick={() => {
                                  if (posCarrinho.length === 0) return;
                                  const novasLinhas: LinhaFatura[] =
                                    posCarrinho.map((item) => {
                                      const precoComDesconto =
                                        item.preco * (1 - item.desconto / 100);
                                      return {
                                        descricao: item.nome,
                                        quantidade: item.quantidade,
                                        precoUnitario: precoComDesconto,
                                        ivaIsento: item.ivaIsento,
                                        unidade: "",
                                      };
                                    });
                                  setLinhas((prev) => [
                                    ...prev,
                                    ...novasLinhas,
                                  ]);
                                  setPosCarrinho([]);
                                  setEstado("paga");
                                  setToast({
                                    message: `Venda rápida: ${novasLinhas.length} item(s) adicionado(s)`,
                                    type: "success",
                                  });
                                }}
                                className="flex-1 bg-[#00AEEF] hover:bg-[#0099d4] text-white text-xs font-bold py-2 rounded-lg transition flex items-center justify-center gap-1"
                                title="Venda rápida (adiciona e marca como paga)"
                              >
                                💰 Venda Rápida
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="px-5 py-2 border-t border-gray-100 bg-gray-50/50 flex items-center justify-between text-[10px] text-gray-500">
                    <div className="flex gap-3 flex-wrap">
                      <span>
                        <kbd className="bg-gray-200 px-1 rounded">1-9</kbd>{" "}
                        Adicionar rápido
                      </span>
                      <span>
                        <kbd className="bg-gray-200 px-1 rounded">F1-F6</kbd>{" "}
                        Filtros
                      </span>
                      <span>
                        <kbd className="bg-gray-200 px-1 rounded">F7</kbd>{" "}
                        Código barras
                      </span>
                      <span>
                        <kbd className="bg-gray-200 px-1 rounded">F8</kbd>{" "}
                        Transferir
                      </span>
                      <span>
                        <kbd className="bg-gray-200 px-1 rounded">F9</kbd>{" "}
                        Limpar
                      </span>
                      <span>
                        <kbd className="bg-gray-200 px-1 rounded">F10</kbd>{" "}
                        Carrinho
                      </span>
                      <span>
                        <kbd className="bg-gray-200 px-1 rounded">F11</kbd> Modo
                        caixa
                      </span>
                      <span>
                        <kbd className="bg-gray-200 px-1 rounded">Ctrl +/-</kbd>{" "}
                        Tamanho
                      </span>
                    </div>
                    <button
                      onClick={() => openNovoProdutoModal()}
                      className="text-violet-600 hover:underline font-semibold"
                    >
                      + Criar novo produto
                    </button>
                  </div>
                </div>
              )}
              <div className="bg-white border border-gray-200 rounded-lg p-5">
                <h3 className="text-sm font-bold text-gray-800">Observações</h3>
                <p className="text-xs text-gray-400 mb-4">Referência Externa</p>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Observações
                    </label>
                    <textarea
                      value={observacoes}
                      onChange={(e) => setObservacoes(e.target.value)}
                      rows={3}
                      placeholder="Observações, notas ou comentários"
                      className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-[#00AEEF] resize-none placeholder-gray-400"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Referência Externa
                    </label>
                    <input
                      value={refExterna}
                      onChange={(e) => setRefExterna(e.target.value)}
                      className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-[#00AEEF] placeholder-gray-400"
                      placeholder="Referência Externa"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="w-80 flex-shrink-0 space-y-3">
              <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                <div className="px-4 py-3 border-b border-gray-100 bg-gray-50">
                  <h3 className="text-sm font-bold text-gray-700">
                    Definições do Documento
                  </h3>
                </div>
                <div className="flex items-center justify-between px-4 py-3.5 border-b border-gray-50">
                  <div className="flex items-center gap-3 flex-1">
                    <span className="text-gray-400 text-base">📋</span>
                    <div className="flex-1">
                      <div className="text-sm text-gray-700">
                        Tipo de Documento
                      </div>
                      <select
                        value={tipoDocumento}
                        onChange={(e) =>
                          handleTipoDocumentoChange(e.target.value)
                        }
                        className="text-xs text-gray-600 border-0 focus:outline-none bg-transparent w-full mt-0.5 cursor-pointer font-medium"
                      >
                        {TIPO_DOC_OPTS.map((t) => (
                          <option key={t.value} value={t.value}>
                            {t.label} ({t.code})
                          </option>
                        ))}
                      </select>
                      <p className="text-[10px] text-gray-400 mt-0.5">
                        Estado inicial:{" "}
                        <span className="font-semibold">
                          {
                            ESTADO_LABEL[
                              TIPO_DOC_OPTS.find(
                                (t) => t.value === tipoDocumento,
                              )?.estadoDefault || "emitida"
                            ]
                          }
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
                <div className="px-4 py-3.5 border-b border-gray-50">
                  <div className="flex items-center gap-3 mb-1">
                    <span className="text-gray-400 text-base">☰</span>
                    <div className="flex-1">
                      <div className="text-sm text-gray-700 font-medium">
                        {data.config.nomeClinica || "Clínica"}
                      </div>
                      {data.config.nif && (
                        <div className="text-xs text-gray-400">
                          NIF: {data.config.nif}
                        </div>
                      )}
                      {data.config.endereco && (
                        <div className="text-xs text-gray-400 mt-0.5">
                          {data.config.endereco}
                        </div>
                      )}
                      {data.config.telefone && (
                        <div className="text-xs text-gray-400">
                          {data.config.telefone}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center px-4 py-3.5 border-b border-gray-50">
                  <div className="flex items-center gap-3 flex-1">
                    <span className="text-gray-400 text-base">📅</span>
                    <div className="flex-1">
                      <div className="text-sm text-gray-700">
                        Data de Emissão
                      </div>
                      <input
                        value={dataEmissao}
                        onChange={(e) => setDataEmissao(e.target.value)}
                        className="text-xs text-gray-500 border-0 border-b border-gray-200 focus:outline-none focus:border-[#00AEEF] bg-transparent w-full mt-0.5"
                        placeholder="DD/MM/AAAA"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex items-center px-4 py-3.5 border-b border-gray-50">
                  <div className="flex items-center gap-3 flex-1">
                    <span className="text-gray-400 text-base">⏰</span>
                    <div className="flex-1">
                      <div className="text-sm text-gray-700">Vencimento</div>
                      <input
                        value={dataVenc}
                        onChange={(e) => setDataVenc(e.target.value)}
                        className="text-xs text-gray-500 border-0 border-b border-gray-200 focus:outline-none focus:border-[#00AEEF] bg-transparent w-full mt-0.5"
                        placeholder="DD/MM/AAAA"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex items-center px-4 py-3.5 border-b border-gray-50">
                  <div className="flex items-center gap-3 flex-1">
                    <span className="text-gray-400 text-base">💶</span>
                    <div className="flex-1">
                      <div className="text-sm text-gray-700">Estado</div>
                      <select
                        value={estado}
                        onChange={(e) =>
                          setEstado(e.target.value as Fatura["estado"])
                        }
                        className="text-xs text-gray-500 border-0 focus:outline-none bg-transparent w-full mt-0.5 cursor-pointer"
                      >
                        <option value="emitida">Emitida</option>
                        <option value="paga">Paga</option>
                        <option value="rascunho">Rascunho</option>
                        <option value="anulada">Anulada</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="px-4 py-3.5 border-b border-gray-50">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-gray-400 text-base">💳</span>
                    <div className="flex-1">
                      <div className="text-sm text-gray-700 font-semibold">
                        Forma de Pagamento
                      </div>
                    </div>
                  </div>
                  <div className="flex bg-gray-100 rounded-lg p-0.5 mb-3">
                    <button
                      type="button"
                      onClick={() => {
                        setUsarMultiplasFormas(false);
                        setFormasPagamento([]);
                      }}
                      className={`flex-1 py-1.5 rounded text-xs font-semibold transition ${!usarMultiplasFormas ? "bg-white text-[#00AEEF] shadow-sm" : "text-gray-500"}`}
                    >
                      Forma Única
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setUsarMultiplasFormas(true);
                        setFormaPagamento("");
                        setValorRecebido(0);
                      }}
                      className={`flex-1 py-1.5 rounded text-xs font-semibold transition ${usarMultiplasFormas ? "bg-white text-[#00AEEF] shadow-sm" : "text-gray-500"}`}
                    >
                      Múltiplas Formas
                    </button>
                  </div>
                  {!usarMultiplasFormas ? (
                    <>
                      <select
                        value={formaPagamento}
                        onChange={(e) => {
                          setFormaPagamento(e.target.value);
                          setValorRecebido(0);
                        }}
                        className="w-full border border-gray-200 rounded px-3 py-2 text-xs focus:outline-none focus:border-[#00AEEF] bg-white cursor-pointer"
                      >
                        <option value="">— Seleccionar —</option>
                        {FORMA_PAG_OPTS.map((f) => (
                          <option key={f} value={f}>
                            {f}
                          </option>
                        ))}
                      </select>
                      {formaPagamento === "Numerário" && (
                        <div className="mt-3 rounded-xl bg-emerald-50 border border-emerald-200 overflow-hidden">
                          <div className="flex items-center gap-2 px-3 py-2 bg-emerald-100 border-b border-emerald-200">
                            <span className="text-base">💵</span>
                            <span className="text-xs font-bold text-emerald-800">
                              Pagamento em Numerário
                            </span>
                          </div>
                          <div className="px-3 py-3 space-y-3">
                            <div>
                              <label className="text-xs font-semibold text-emerald-700 mb-1 block">
                                Total a Cobrar
                              </label>
                              <div className="text-base font-black text-emerald-700">
                                {formatCurrency(totals.total, moeda)}
                              </div>
                            </div>
                            <div>
                              <label className="text-xs font-semibold text-emerald-700 mb-1 block">
                                Valor Recebido
                              </label>
                              <input
                                type="number"
                                min={0}
                                step={0.01}
                                value={valorRecebido}
                                onChange={(e) =>
                                  setValorRecebido(
                                    e.target.value === ""
                                      ? ""
                                      : Number(e.target.value),
                                  )
                                }
                                onFocus={(e) => e.target.select()}
                                placeholder="0.00"
                                className={`w-full border rounded-lg px-3 py-2 text-sm font-bold text-right focus:outline-none transition ${trocoNegativo ? "border-red-300 bg-red-50 focus:border-red-400 text-red-700" : "border-emerald-300 bg-white focus:border-emerald-500 text-gray-800"}`}
                              />
                              {trocoNegativo && (
                                <p className="text-xs text-red-500 mt-1">
                                  ⚠ Falta{" "}
                                  {formatCurrency(
                                    totals.total - (valorRecebido as number),
                                    moeda,
                                  )}
                                </p>
                              )}
                            </div>
                            <div
                              className={`rounded-lg p-3 border ${troco > 0 ? "bg-white border-emerald-300" : "bg-emerald-100/50 border-emerald-200"}`}
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-semibold text-emerald-700">
                                  Troco
                                </span>
                                <span
                                  className={`text-lg font-black ${troco > 0 ? "text-emerald-600" : "text-emerald-400"}`}
                                >
                                  {formatCurrency(troco, moeda)}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </>
                  ) : (
                    <>
                      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-3 mb-3">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">💳</span>
                            <span className="text-xs font-bold text-blue-800">
                              Pagamento Dividido
                            </span>
                          </div>
                          <span className="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-semibold">
                            {formasPagamento.length} forma
                            {formasPagamento.length !== 1 ? "s" : ""}
                          </span>
                        </div>
                        <p className="text-[10px] text-blue-600">
                          Combine diferentes métodos de pagamento
                        </p>
                      </div>
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {formasPagamento.length === 0 ? (
                          <div className="py-6 text-center text-gray-400 bg-gray-50 rounded-lg border border-dashed border-gray-200">
                            <div className="text-3xl mb-2 opacity-40">💳</div>
                            <p className="text-xs">Nenhuma forma adicionada</p>
                          </div>
                        ) : (
                          formasPagamento.map((forma, idx) => {
                            const trocoForma = calcularTrocoForma(forma);
                            return (
                              <div
                                key={forma.id}
                                className="bg-white border border-gray-200 rounded-lg p-3 hover:border-[#00AEEF]/50 transition"
                              >
                                <div className="flex items-center justify-between mb-2">
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs font-bold text-gray-400 w-5">
                                      #{idx + 1}
                                    </span>
                                    <span className="text-sm">
                                      {FORMA_PAG_ICONS[forma.forma] || "💰"}
                                    </span>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      removerFormaPagamento(forma.id)
                                    }
                                    className="text-red-400 hover:text-red-600 text-sm hover:bg-red-50 w-6 h-6 rounded flex items-center justify-center transition"
                                  >
                                    ×
                                  </button>
                                </div>
                                <div className="space-y-2">
                                  <select
                                    value={forma.forma}
                                    onChange={(e) =>
                                      atualizarFormaPagamento(
                                        forma.id,
                                        "forma",
                                        e.target.value,
                                      )
                                    }
                                    className="w-full border border-gray-200 rounded px-2 py-1.5 text-xs focus:outline-none focus:border-[#00AEEF] bg-white"
                                  >
                                    <option value="">— Tipo —</option>
                                    {FORMA_PAG_OPTS.filter(
                                      (f) =>
                                        !formasPagamento.some(
                                          (fp) =>
                                            fp.forma === f &&
                                            fp.id !== forma.id,
                                        ),
                                    ).map((f) => (
                                      <option key={f} value={f}>
                                        {FORMA_PAG_ICONS[f]} {f}
                                      </option>
                                    ))}
                                  </select>
                                  <div className="flex gap-2">
                                    <div className="flex-1">
                                      <label className="text-[10px] font-semibold text-gray-500 mb-0.5 block">
                                        Valor
                                      </label>
                                      <input
                                        type="number"
                                        min={0}
                                        step={0.01}
                                        value={forma.valor || ""}
                                        onChange={(e) =>
                                          atualizarFormaPagamento(
                                            forma.id,
                                            "valor",
                                            e.target.value === ""
                                              ? 0
                                              : Number(e.target.value),
                                          )
                                        }
                                        placeholder="0.00"
                                        className="w-full border border-gray-200 rounded px-2 py-1.5 text-xs font-bold text-right focus:outline-none focus:border-[#00AEEF]"
                                      />
                                    </div>
                                    {forma.forma === "Numerário" && (
                                      <div className="flex-1">
                                        <label className="text-[10px] font-semibold text-gray-500 mb-0.5 block">
                                          Recebido
                                        </label>
                                        <input
                                          type="number"
                                          min={0}
                                          step={0.01}
                                          value={forma.valorRecebido || ""}
                                          onChange={(e) =>
                                            atualizarFormaPagamento(
                                              forma.id,
                                              "valorRecebido",
                                              e.target.value === ""
                                                ? undefined
                                                : Number(e.target.value),
                                            )
                                          }
                                          placeholder="0.00"
                                          className="w-full border border-gray-200 rounded px-2 py-1.5 text-xs text-right focus:outline-none focus:border-[#00AEEF]"
                                        />
                                      </div>
                                    )}
                                  </div>
                                  {forma.forma &&
                                    forma.forma !== "Numerário" && (
                                      <input
                                        type="text"
                                        value={forma.referencia || ""}
                                        onChange={(e) =>
                                          atualizarFormaPagamento(
                                            forma.id,
                                            "referencia",
                                            e.target.value,
                                          )
                                        }
                                        placeholder="Referência"
                                        className="w-full border border-gray-200 rounded px-2 py-1.5 text-[11px] focus:outline-none focus:border-[#00AEEF]"
                                      />
                                    )}
                                  {forma.forma === "Numerário" &&
                                    trocoForma > 0 && (
                                      <div className="text-[10px] text-emerald-600 font-semibold bg-emerald-50 rounded px-2 py-1">
                                        💵 Troco:{" "}
                                        {formatCurrency(trocoForma, moeda)}
                                      </div>
                                    )}
                                  <button
                                    type="button"
                                    onClick={() =>
                                      preencherRestante(forma.id, totals.total)
                                    }
                                    className="w-full text-[10px] text-blue-600 hover:text-blue-800 hover:bg-blue-50 py-1 rounded transition font-semibold"
                                  >
                                    ⚡ Preencher restante
                                  </button>
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                      <div className="flex gap-2 mt-2">
                        <button
                          type="button"
                          onClick={adicionarFormaPagamento}
                          disabled={
                            formasPagamento.length >= FORMA_PAG_OPTS.length
                          }
                          className="flex-1 py-2 rounded-lg bg-[#00AEEF] text-white text-xs font-semibold hover:bg-[#0099d4] transition disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-1"
                        >
                          + Adicionar
                        </button>
                        {formasPagamento.length > 0 && totals.total > 0 && (
                          <button
                            type="button"
                            onClick={() =>
                              distribuirTotalAutomaticamente(totals.total)
                            }
                            className="px-3 py-2 rounded-lg bg-violet-100 text-violet-700 text-xs font-semibold hover:bg-violet-200 transition"
                          >
                            ÷ Dividir
                          </button>
                        )}
                      </div>
                      {formasPagamento.length > 0 && (
                        <div
                          className={`mt-3 rounded-lg p-3 border ${Math.abs(diferencaPagamento) < 0.01 ? "bg-emerald-50 border-emerald-200" : diferencaPagamento > 0 ? "bg-amber-50 border-amber-200" : "bg-red-50 border-red-200"}`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[10px] font-bold text-gray-600 uppercase">
                              Total Fatura
                            </span>
                            <span className="text-xs font-bold text-gray-800">
                              {formatCurrency(totals.total, moeda)}
                            </span>
                          </div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[10px] font-bold text-gray-600 uppercase">
                              Total Pago
                            </span>
                            <span className="text-xs font-bold text-gray-800">
                              {formatCurrency(totalFormasPagamento, moeda)}
                            </span>
                          </div>
                          <div className="flex items-center justify-between pt-1 border-t border-gray-200">
                            <span className="text-[10px] font-bold text-gray-600 uppercase">
                              {Math.abs(diferencaPagamento) < 0.01
                                ? "✓ Completo"
                                : diferencaPagamento > 0
                                  ? "⚠ Falta"
                                  : "⚠ Excesso"}
                            </span>
                            <span
                              className={`text-sm font-black ${Math.abs(diferencaPagamento) < 0.01 ? "text-emerald-600" : "text-amber-600"}`}
                            >
                              {formatCurrency(
                                Math.abs(diferencaPagamento),
                                moeda,
                              )}
                            </span>
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </div>
                <div className="flex items-center px-4 py-3.5 border-b border-gray-50">
                  <div className="flex items-center gap-3 flex-1">
                    <span className="text-gray-400 text-base">🏷️</span>
                    <div className="flex-1">
                      <div className="text-sm text-gray-700">Desconto (%)</div>
                      <input
                        type="number"
                        value={desconto}
                        min={0}
                        max={100}
                        onChange={(e) => setDesconto(Number(e.target.value))}
                        className="text-xs text-gray-500 border-0 border-b border-gray-200 focus:outline-none focus:border-[#00AEEF] bg-transparent w-full mt-0.5"
                        placeholder="0%"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex items-center px-4 py-3.5 border-b border-gray-50">
                  <div className="flex items-center gap-3 flex-1">
                    <span className="text-gray-400 text-base">💰</span>
                    <div className="flex-1">
                      <div className="text-sm text-gray-700">IVA (%)</div>
                      <input
                        type="number"
                        value={ivaTaxa}
                        min={0}
                        max={100}
                        onChange={(e) => setIvaTaxa(Number(e.target.value))}
                        className="text-xs text-gray-500 border-0 border-b border-gray-200 focus:outline-none focus:border-[#00AEEF] bg-transparent w-full mt-0.5"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex items-center px-4 py-3.5 border-b border-gray-50">
                  <label className="flex items-center gap-3 cursor-pointer flex-1">
                    <span className="text-base">🏆</span>
                    <div className="flex-1">
                      <div className="text-sm text-gray-700">
                        Factura Premiada
                      </div>
                      <div className="text-xs text-gray-400">
                        NIF participa no sorteio AGT
                      </div>
                    </div>
                    <div
                      onClick={() => setFacturaPremiada((v) => !v)}
                      className={`relative w-10 h-5 rounded-full transition-colors cursor-pointer ${facturaPremiada ? "bg-amber-400" : "bg-gray-200"}`}
                    >
                      <span
                        className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${facturaPremiada ? "left-5" : "left-0.5"}`}
                      />
                    </div>
                  </label>
                </div>
                <div className="p-4 space-y-3">
                  <button
                    onClick={handleSave}
                    className="w-full bg-[#00AEEF] hover:bg-[#0099d4] active:bg-[#0088bb] text-white py-3 rounded-lg text-sm font-bold transition shadow flex items-center justify-center gap-2"
                  >
                    ✅{" "}
                    {editId !== null
                      ? "Guardar Alterações"
                      : `Criar ${tipoLabel}`}
                  </button>
                  {nifError && (
                    <p className="text-xs text-red-500 text-center">
                      {nifError}
                    </p>
                  )}
                  <button
                    onClick={() => {
                      resetForm();
                      setView("lista");
                    }}
                    className="w-full flex items-center justify-center gap-1 text-xs text-red-400 hover:text-red-600 hover:underline transition"
                  >
                    🗑 {editId !== null ? "Cancelar Edição" : "Descartar"}
                  </button>
                </div>
              </div>
              {totals.total !== 0 && (
                <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm space-y-2">
                  <p className="text-xs font-bold text-gray-500 uppercase tracking-wide">
                    Resumo de Totais
                  </p>
                  <div className="flex justify-between text-xs text-gray-500 py-1">
                    <span>Subtotal s/IVA</span>
                    <span className="font-semibold">
                      {formatCurrency(totals.subtotalSemIva, moeda)}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs text-gray-500 py-1 border-b border-gray-100">
                    <span>IVA ({ivaTaxa}%)</span>
                    <span className="font-semibold">
                      {formatCurrency(totals.totalIva, moeda)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-black text-gray-900 pt-1">
                    <span>Total</span>
                    <span className="text-[#00AEEF]">
                      {formatCurrency(totals.total, moeda)}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        {showNovoProduto && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
                <div>
                  <h3 className="font-bold text-base text-violet-700">
                    📦 {editandoProdutoId ? "Editar" : "Criar"} Produto
                  </h3>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {editandoProdutoId
                      ? "Atualize os dados"
                      : "Adicione um produto"}
                  </p>
                </div>
                <button
                  onClick={handleCloseProdutoModal}
                  className="text-gray-400 hover:text-gray-600 w-7 h-7 flex items-center justify-center rounded hover:bg-gray-100"
                >
                  ✕
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Nome do Produto <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={novoProduto.nome}
                    onChange={(e) =>
                      setNovoProduto((p) => ({ ...p, nome: e.target.value }))
                    }
                    placeholder="Ex: Consulta Médica..."
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
                    autoFocus
                    disabled={salvandoProduto}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Código
                    </label>
                    <input
                      type="text"
                      value={novoProduto.codigo}
                      onChange={(e) =>
                        setNovoProduto((p) => ({
                          ...p,
                          codigo: e.target.value,
                        }))
                      }
                      placeholder="Ex: PRD001"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
                      disabled={salvandoProduto}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Preço ({moeda}) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      min={0}
                      step={0.01}
                      value={novoProduto.preco}
                      onChange={(e) =>
                        setNovoProduto((p) => ({
                          ...p,
                          preco: Number(e.target.value),
                        }))
                      }
                      placeholder="0.00"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
                      disabled={salvandoProduto}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Stock Atual
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={novoProduto.stock}
                      onChange={(e) =>
                        setNovoProduto((p) => ({
                          ...p,
                          stock: Number(e.target.value),
                        }))
                      }
                      placeholder="0"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
                      disabled={salvandoProduto}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Stock Mínimo
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={novoProduto.stockMinimo}
                      onChange={(e) =>
                        setNovoProduto((p) => ({
                          ...p,
                          stockMinimo: Number(e.target.value),
                        }))
                      }
                      placeholder="0"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
                      disabled={salvandoProduto}
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Categoria
                  </label>
                  <input
                    type="text"
                    value={novoProduto.categoria}
                    onChange={(e) =>
                      setNovoProduto((p) => ({
                        ...p,
                        categoria: e.target.value,
                      }))
                    }
                    placeholder="Ex: Serviços, Medicamentos..."
                    list="categorias-produtos"
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
                    disabled={salvandoProduto}
                  />
                  <datalist id="categorias-produtos">
                    {catalogCats.map((c) => (
                      <option key={c} value={c} />
                    ))}
                  </datalist>
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Descrição
                  </label>
                  <textarea
                    value={novoProduto.descricao}
                    onChange={(e) =>
                      setNovoProduto((p) => ({
                        ...p,
                        descricao: e.target.value,
                      }))
                    }
                    rows={2}
                    placeholder="Descrição opcional..."
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-400 resize-none"
                    disabled={salvandoProduto}
                  />
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={novoProduto.ivaIsento}
                    onChange={(e) =>
                      setNovoProduto((p) => ({
                        ...p,
                        ivaIsento: e.target.checked,
                      }))
                    }
                    className="w-4 h-4 accent-violet-500"
                    disabled={salvandoProduto}
                  />
                  <span className="text-sm text-gray-700">Isento de IVA</span>
                </label>
                {novoProdutoError && (
                  <p className="text-xs text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                    {novoProdutoError}
                  </p>
                )}
              </div>
              <div className="px-6 py-4 border-t border-gray-100 flex gap-3 sticky bottom-0 bg-white">
                <button
                  onClick={handleCloseProdutoModal}
                  className="flex-1 py-2 rounded-lg bg-gray-600 text-white text-sm font-semibold hover:bg-gray-700 transition"
                  disabled={salvandoProduto}
                >
                  Cancelar
                </button>
                <button
                  onClick={handleSaveProduto}
                  className="flex-1 py-2 rounded-lg text-white text-sm font-semibold transition bg-violet-600 hover:bg-violet-700 disabled:bg-violet-300 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  disabled={salvandoProduto}
                >
                  {salvandoProduto ? (
                    <>
                      <span className="animate-spin">⏳</span>A guardar...
                    </>
                  ) : (
                    <>✓ {editandoProdutoId ? "Guardar" : "Criar"}</>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
        {showNovoCliente && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
                <div>
                  <h3 className="font-bold text-base text-teal-700">
                    👤 {editandoClienteId ? "Editar" : "Criar"} Cliente
                  </h3>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {editandoClienteId
                      ? "Atualize os dados"
                      : "Adicione um cliente"}
                  </p>
                </div>
                <button
                  onClick={handleCloseClienteModal}
                  className="text-gray-400 hover:text-gray-600 w-7 h-7 flex items-center justify-center rounded hover:bg-gray-100"
                >
                  ✕
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Nome Completo <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={novoCliente.nome}
                    onChange={(e) =>
                      setNovoCliente((c) => ({ ...c, nome: e.target.value }))
                    }
                    placeholder="Nome do cliente"
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400"
                    autoFocus
                    disabled={salvandoCliente}
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Tipo de Documento
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        setNovoCliente((c) => ({ ...c, tipoDocumento: "nif" }))
                      }
                      className={`px-3 py-2 rounded-lg text-xs font-semibold border transition ${novoCliente.tipoDocumento === "nif" ? "bg-teal-50 border-teal-500 text-teal-700" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}
                    >
                      📄 NIF
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setNovoCliente((c) => ({ ...c, tipoDocumento: "bi" }))
                      }
                      className={`px-3 py-2 rounded-lg text-xs font-semibold border transition ${novoCliente.tipoDocumento === "bi" ? "bg-teal-50 border-teal-500 text-teal-700" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}
                    >
                      🪪 BI
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setNovoCliente((c) => ({
                          ...c,
                          tipoDocumento: "passaporte",
                        }))
                      }
                      className={`px-3 py-2 rounded-lg text-xs font-semibold border transition ${novoCliente.tipoDocumento === "passaporte" ? "bg-teal-50 border-teal-500 text-teal-700" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}
                    >
                      🛂 Passaporte
                    </button>
                  </div>
                </div>
                {novoCliente.tipoDocumento === "nif" && (
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      NIF
                    </label>
                    <input
                      type="text"
                      value={novoCliente.nif}
                      onChange={(e) =>
                        setNovoCliente((c) => ({ ...c, nif: e.target.value }))
                      }
                      placeholder="9 ou 14 dígitos"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400"
                      disabled={salvandoCliente}
                    />
                    {novoCliente.nif && !validarNIF(novoCliente.nif) && (
                      <p className="text-xs text-red-500 mt-1">NIF inválido</p>
                    )}
                  </div>
                )}
                {novoCliente.tipoDocumento === "bi" && (
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      BI
                    </label>
                    <input
                      type="text"
                      value={novoCliente.bi}
                      onChange={(e) =>
                        setNovoCliente((c) => ({
                          ...c,
                          bi: e.target.value.toUpperCase(),
                        }))
                      }
                      placeholder="Ex: 000000000LA000"
                      maxLength={14}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400 font-mono uppercase"
                      disabled={salvandoCliente}
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      {novoCliente.bi.length}/14 caracteres
                    </p>
                    {novoCliente.bi &&
                      !validarBI(novoCliente.bi) &&
                      novoCliente.bi.length === 14 && (
                        <p className="text-xs text-red-500 mt-1">BI inválido</p>
                      )}
                  </div>
                )}
                {novoCliente.tipoDocumento === "passaporte" && (
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Passaporte
                    </label>
                    <input
                      type="text"
                      value={novoCliente.passaporte}
                      onChange={(e) =>
                        setNovoCliente((c) => ({
                          ...c,
                          passaporte: e.target.value.toUpperCase(),
                        }))
                      }
                      placeholder="Ex: AB123456"
                      maxLength={12}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400 font-mono uppercase"
                      disabled={salvandoCliente}
                    />
                    {novoCliente.passaporte &&
                      !validarPassaporte(novoCliente.passaporte) && (
                        <p className="text-xs text-red-500 mt-1">
                          Passaporte inválido
                        </p>
                      )}
                  </div>
                )}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Telefone
                    </label>
                    <input
                      type="text"
                      value={novoCliente.telefone}
                      onChange={(e) =>
                        setNovoCliente((c) => ({
                          ...c,
                          telefone: e.target.value,
                        }))
                      }
                      placeholder="+244 9XX XXX XXX"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400"
                      disabled={salvandoCliente}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Email
                    </label>
                    <input
                      type="email"
                      value={novoCliente.email}
                      onChange={(e) =>
                        setNovoCliente((c) => ({ ...c, email: e.target.value }))
                      }
                      placeholder="email@exemplo.com"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400"
                      disabled={salvandoCliente}
                    />
                    {novoCliente.email && !validarEmail(novoCliente.email) && (
                      <p className="text-xs text-red-500 mt-1">
                        Email inválido
                      </p>
                    )}
                  </div>
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Endereço
                  </label>
                  <input
                    type="text"
                    value={novoCliente.endereco}
                    onChange={(e) =>
                      setNovoCliente((c) => ({
                        ...c,
                        endereco: e.target.value,
                      }))
                    }
                    placeholder="Morada completa"
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400"
                    disabled={salvandoCliente}
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Observações
                  </label>
                  <textarea
                    value={novoCliente.observacoes}
                    onChange={(e) =>
                      setNovoCliente((c) => ({
                        ...c,
                        observacoes: e.target.value,
                      }))
                    }
                    rows={2}
                    placeholder="Notas adicionais..."
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400 resize-none"
                    disabled={salvandoCliente}
                  />
                </div>
                {novoClienteError && (
                  <p className="text-xs text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                    {novoClienteError}
                  </p>
                )}
              </div>
              <div className="px-6 py-4 border-t border-gray-100 flex gap-3 sticky bottom-0 bg-white">
                <button
                  onClick={handleCloseClienteModal}
                  className="flex-1 py-2 rounded-lg bg-gray-600 text-white text-sm font-semibold hover:bg-gray-700 transition"
                  disabled={salvandoCliente}
                >
                  Cancelar
                </button>
                <button
                  onClick={handleSaveCliente}
                  className="flex-1 py-2 rounded-lg text-white text-sm font-semibold transition bg-teal-600 hover:bg-teal-700 disabled:bg-teal-300 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  disabled={salvandoCliente}
                >
                  {salvandoCliente ? (
                    <>
                      <span className="animate-spin"></span>A guardar...
                    </>
                  ) : (
                    <>✓ {editandoClienteId ? "Guardar" : "Criar"}</>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
        {showCancelConfirm && (
          <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
              <div className="px-6 py-4 border-b border-gray-100">
                <h3 className="font-bold text-base text-gray-800">
                  Descartar alterações?
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  Tem dados não salvos.
                </p>
              </div>
              <div className="px-6 py-4 flex gap-3">
                <button
                  onClick={() => setShowCancelConfirm(false)}
                  className="flex-1 py-2 rounded-lg bg-gray-200 text-gray-700 text-sm font-semibold hover:bg-gray-300 transition"
                >
                  Continuar
                </button>
                <button
                  onClick={() => {
                    cancelAction();
                    setShowCancelConfirm(false);
                  }}
                  className="flex-1 py-2 rounded-lg bg-red-500 text-white text-sm font-semibold hover:bg-red-600 transition"
                >
                  Descartar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
  const notificacoesNaoLidas = notificacoes.filter((n) => !n.lida).length;
  return (
    <div className="min-h-full bg-gray-100">
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
      <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm">
          <span className="text-[#00AEEF] font-semibold">Documentos</span>
          <span className="text-gray-400">/</span>
          <span className="text-gray-600">Listagem</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowChat(true)}
            className="text-xs px-3 py-2 rounded font-semibold border border-blue-300 text-blue-600 hover:bg-blue-50 transition flex items-center gap-1.5"
          >
            💬 Assistente
          </button>
          <button
            onClick={() => setShowDashboard(true)}
            className="text-xs px-3 py-2 rounded font-semibold border border-amber-300 text-amber-600 hover:bg-amber-50 transition flex items-center gap-1.5"
          >
            📊 Dashboard
          </button>
          <button
            onClick={() => setShowRelatorios(true)}
            className="text-xs px-3 py-2 rounded font-semibold border border-blue-300 text-blue-600 hover:bg-blue-50 transition flex items-center gap-1.5"
          >
            📈 Relatórios
          </button>
          <button
            onClick={() => setShowTemplates(true)}
            className="text-xs px-3 py-2 rounded font-semibold border border-purple-300 text-purple-600 hover:bg-purple-50 transition flex items-center gap-1.5"
          >
            📋 Templates
          </button>
          <button
            onClick={() => {
              setGestaoSearch("");
              setGestaoCat(null);
              setShowGestaoProdutos(true);
            }}
            className="text-xs px-3 py-2 rounded font-semibold border border-violet-300 text-violet-600 hover:bg-violet-50 transition flex items-center gap-1.5"
          >
            📦 Gestão Produtos
          </button>
          <button
            onClick={() => {
              setGestaoSearch("");
              setShowGestaoClientes(true);
            }}
            className="text-xs px-3 py-2 rounded font-semibold border border-teal-300 text-teal-600 hover:bg-teal-50 transition flex items-center gap-1.5"
          >
            👤 Gestão Clientes
          </button>
          <button
            onClick={() => setShowLogs(true)}
            className="text-xs px-3 py-2 rounded font-semibold border border-gray-300 text-gray-600 hover:bg-gray-50 transition flex items-center gap-1.5"
          >
            📋 Logs
          </button>
          <button
            onClick={() => setShowNotificacoes(true)}
            className="text-xs px-3 py-2 rounded font-semibold border border-orange-300 text-orange-600 hover:bg-orange-50 transition flex items-center gap-1.5 relative"
          >
            🔔 Notificações
            {notificacoesNaoLidas > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {notificacoesNaoLidas}
              </span>
            )}
          </button>
          <button
            onClick={() => {
              setShowProdutosPanel(true);
              setPosModoCaixa(true);
              setPosShowCarrinho(true);
            }}
            className="text-xs px-3 py-2 rounded font-bold border border-emerald-300 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 transition flex items-center gap-1.5"
            title="Abrir o Ponto de Venda"
          >
            🛒 Abrir POS
          </button>
          <button
            onClick={() => setShowConfig(true)}
            className="text-xs px-3 py-2 rounded font-semibold border border-gray-300 text-gray-600 hover:bg-gray-50 transition flex items-center gap-1.5"
          >
            ⚙️ Config
          </button>
          <button
            onClick={() => setShowNotasCreditoPage(true)}
            className="text-xs px-3 py-2 rounded font-semibold border border-orange-300 text-orange-600 hover:bg-orange-50 transition flex items-center gap-1.5"
          >
            🧾 Notas de Crédito
          </button>
          <button
            onClick={handleNovo}
            className="bg-[#00AEEF] hover:bg-[#0099d4] text-white px-4 py-2 rounded text-sm font-bold transition flex items-center gap-2 shadow-sm"
          >
            📄 Criar Documento
          </button>
        </div>
      </div>
      <div className="px-6 py-5 max-w-7xl mx-auto flex gap-5 items-start">
        <div className="flex-1 min-w-0 space-y-3">
          <div className="bg-white border border-gray-200 rounded-lg p-3 flex gap-2">
            <div className="flex-1 flex items-center gap-2 border border-gray-200 rounded px-3 py-2 bg-white">
              <span className="text-gray-400">🔍</span>
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Pesquisar por Número, Referência ou Cliente"
                className="flex-1 text-sm focus:outline-none text-gray-700 placeholder-gray-400 bg-transparent"
              />
            </div>
            <button className="bg-[#00AEEF] text-white px-5 py-2 rounded text-sm font-semibold hover:opacity-90 transition">
              Pesquisar
            </button>
          </div>
          {rascunhos.length > 0 && (
            <div className="border border-amber-200 rounded-lg overflow-hidden bg-amber-50">
              <button
                className="w-full flex items-center justify-between px-4 py-3"
                onClick={() => setShowRascunhos((s) => !s)}
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-amber-400 flex items-center justify-center shadow-sm">
                    <span className="text-white text-sm">📄</span>
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-bold text-amber-800">
                      Rascunho
                    </div>
                    <div className="text-xs text-amber-600">
                      {rascunhos.length} documento
                      {rascunhos.length > 1 ? "s" : ""} em rascunho
                    </div>
                  </div>
                </div>
                <span className="text-amber-500 font-bold text-lg">
                  {showRascunhos ? "∧" : "∨"}
                </span>
              </button>
              {showRascunhos &&
                rascunhos.map((f) => (
                  <div
                    key={f.id}
                    onClick={() => handleEdit(f)}
                    className="flex items-center gap-4 px-4 py-3 border-t border-amber-100 hover:bg-amber-100/60 transition cursor-pointer"
                  >
                    <FTAvatar tipo={f.tipoDocumento} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold text-gray-800">
                        {f.numero}
                      </div>
                      <div className="text-xs text-gray-500 truncate">
                        {f.clienteNome}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-gray-800">
                        {formatCurrency(f.total, moeda)}
                      </div>
                      <div className="text-xs text-gray-400">{f.data}</div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemover(f);
                      }}
                      className="text-xs text-red-400 border border-red-200 px-2 py-1 rounded hover:bg-red-50 transition font-semibold ml-2"
                    >
                      🗑
                    </button>
                  </div>
                ))}
            </div>
          )}
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
            {outros.length === 0 && (
              <div className="py-16 text-center">
                <div className="text-4xl mb-3 opacity-20">📄</div>
                <p className="text-sm text-gray-400">
                  Nenhum documento encontrado.
                </p>
                <button
                  onClick={handleNovo}
                  className="mt-3 text-xs text-[#00AEEF] hover:underline font-semibold"
                >
                  Criar primeiro documento
                </button>
              </div>
            )}
            {outros.map((f) => {
              const cores = ESTADO_CORES[f.estado];
              const vencida = isVencida(f.dataVencimento, f.estado);
              const podeDeletar =
                f.estado === "rascunho" || f.estado === "anulada";
              const rowBg =
                f.estado === "paga"
                  ? "hover:bg-emerald-50/60 border-l-4 border-l-emerald-400"
                  : f.estado === "anulada"
                    ? "hover:bg-red-50/40 border-l-4 border-l-red-300 opacity-60"
                    : f.estado === "rascunho"
                      ? "hover:bg-amber-50/60 border-l-4 border-l-amber-400"
                      : vencida
                        ? "hover:bg-orange-50/40 border-l-4 border-l-orange-400"
                        : "hover:bg-blue-50/40 border-l-4 border-l-[#00AEEF]";
              return (
                <div
                  key={f.id}
                  className={`flex items-center gap-4 px-4 py-4 border-b border-gray-50 last:border-0 transition cursor-pointer group ${rowBg}`}
                  onClick={() => handleEdit(f)}
                >
                  <FTAvatar tipo={f.tipoDocumento} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-gray-900">
                        {f.numero}
                      </span>
                      {f.tipoDocumento && f.tipoDocumento !== "factura" && (
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full font-semibold ${f.tipoDocumento === "factura-global" ? "bg-violet-100 text-violet-700" : f.tipoDocumento === "pro-forma" ? "bg-amber-100 text-amber-700" : f.tipoDocumento === "nota-credito" ? "bg-orange-100 text-orange-700" : "bg-purple-50 text-purple-600"}`}
                        >
                          {TIPO_LABEL[f.tipoDocumento] ?? f.tipoDocumento}
                        </span>
                      )}
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-semibold inline-flex items-center gap-1 ${cores.bg} ${cores.text}`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${cores.dot}`}
                        />
                        {ESTADO_LABEL[f.estado]}
                      </span>
                      {vencida && (
                        <span className="text-xs bg-orange-100 text-orange-600 px-2 py-0.5 rounded-full font-semibold">
                          ⚠️ Vencida
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-500 truncate mt-0.5">
                      {f.clienteNome}
                    </div>
                    {f.formaPagamento && (
                      <div className="text-xs text-gray-400 mt-0.5">
                        💳 {f.formaPagamento}
                      </div>
                    )}
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div
                      className={`text-sm font-bold ${f.estado === "paga" ? "text-emerald-600" : f.estado === "anulada" ? "text-gray-400" : "text-gray-900"}`}
                    >
                      {formatCurrency(f.total, moeda)}
                    </div>
                    <div className="text-xs text-gray-400">{f.data}</div>
                  </div>
                  <div
                    className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition ml-2"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      onClick={() =>
                        downloadFatura(
                          generateFaturaHTML(f, data.config),
                          f.numero,
                        )
                      }
                      className="text-xs text-[#00AEEF] border border-[#00AEEF]/30 px-2.5 py-1 rounded hover:bg-blue-50 transition font-semibold"
                    >
                      PDF
                    </button>
                    {f.estado === "emitida" && (
                      <button
                        onClick={() => handleMarcarPaga(f)}
                        className="text-xs text-emerald-600 border border-emerald-200 px-2.5 py-1 rounded hover:bg-emerald-50 transition font-semibold"
                      >
                        Pagar
                      </button>
                    )}
                    {f.estado === "paga" && (
                      <button
                        onClick={() => handleEmitirRecibo(f)}
                        className="text-xs text-teal-600 border border-teal-200 px-2.5 py-1 rounded hover:bg-teal-50 transition font-semibold"
                      >
                        Recibo
                      </button>
                    )}
                    {(f.estado === "emitida" || f.estado === "paga") && (
                      <button
                        onClick={() => handleNotaCredito(f)}
                        className="text-xs text-orange-600 border border-orange-200 px-2.5 py-1 rounded hover:bg-orange-50 transition font-semibold"
                      >
                        NC
                      </button>
                    )}
                    {f.estado !== "paga" && f.estado !== "anulada" && (
                      <button
                        onClick={() =>
                          setConfirmModal({
                            title: "Anular Documento",
                            message: `Deseja anular ${f.numero}?`,
                            confirmText: "Anular",
                            type: "warning",
                            onConfirm: () => {
                              updateFatura(f.id, { estado: "anulada" });
                              setToast({
                                message: `${f.numero} anulada`,
                                type: "success",
                              });
                              setConfirmModal(null);
                              addLog("Anular", "Faturas", f.numero);
                            },
                          })
                        }
                        className="text-xs text-gray-500 border border-gray-200 px-2.5 py-1 rounded hover:bg-gray-100 transition font-semibold"
                      >
                        Anular
                      </button>
                    )}
                    <button
                      onClick={() => handleRemover(f)}
                      disabled={!podeDeletar}
                      title={
                        !podeDeletar ? "Não é possível eliminar" : "Eliminar"
                      }
                      className={`text-xs border px-2.5 py-1 rounded transition font-semibold ${podeDeletar ? "text-red-400 border-red-200 hover:bg-red-50" : "text-gray-300 border-gray-100 cursor-not-allowed"}`}
                    >
                      🗑
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        {ncModal && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-base text-orange-700">
                    Nota de Crédito
                  </h3>
                  <p className="text-xs text-gray-400 mt-0.5">
                    Referente a: <strong>{ncModal.fatura.numero}</strong>
                  </p>
                </div>
                <button
                  onClick={() => setNcModal(null)}
                  className="text-gray-400 hover:text-gray-600 w-7 h-7 flex items-center justify-center rounded hover:bg-gray-100"
                >
                  ✕
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Motivo <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    value={ncMotivo}
                    onChange={(e) => setNcMotivo(e.target.value)}
                    rows={3}
                    placeholder="Ex: Anulação parcial..."
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-orange-400 resize-none"
                    autoFocus
                  />
                  <p className="text-xs text-gray-400 mt-1">
                    Obrigatório nos termos da Lei n.º 2/22 (AGT).
                  </p>
                </div>
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 text-xs text-orange-700">
                  <strong>Cliente:</strong> {ncModal.fatura.clienteNome} ·{" "}
                  <strong>Total:</strong>{" "}
                  {formatCurrency(ncModal.fatura.total, moeda)}
                </div>
              </div>
              <div className="px-6 py-4 border-t border-gray-100 flex gap-3">
                <button
                  onClick={() => setNcModal(null)}
                  className="flex-1 py-2 rounded-lg bg-gray-600 text-white text-sm font-semibold hover:bg-gray-700 transition"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => {
                    if (!ncMotivo.trim()) {
                      setToast({
                        message: "Motivo é obrigatório",
                        type: "error",
                      });
                      return;
                    }
                    confirmarNotaCredito(ncModal.fatura, ncMotivo.trim());
                  }}
                  className="flex-1 py-2 rounded-lg text-white text-sm font-semibold transition bg-orange-600 hover:bg-orange-700"
                >
                  ✓ Emitir NC
                </button>
              </div>
            </div>
          </div>
        )}
        {reciboModal && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-base text-teal-700">
                    Emitir Recibo
                  </h3>
                  <p className="text-xs text-gray-400 mt-0.5">
                    Pagamento de: <strong>{reciboModal.fatura.numero}</strong>
                  </p>
                </div>
                <button
                  onClick={() => setReciboModal(null)}
                  className="text-gray-400 hover:text-gray-600 w-7 h-7 flex items-center justify-center rounded hover:bg-gray-100"
                >
                  ✕
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="bg-teal-50 border border-teal-200 rounded-lg p-3 text-xs text-teal-700">
                  <strong>Cliente:</strong> {reciboModal.fatura.clienteNome}
                  <br />
                  <strong>Total pago:</strong>{" "}
                  {formatCurrency(reciboModal.fatura.total, moeda)}
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Forma de Pagamento
                  </label>
                  <select
                    value={reciboFormaPag}
                    onChange={(e) => setReciboFormaPag(e.target.value)}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400 bg-white"
                  >
                    <option value="">— Seleccionar —</option>
                    {FORMA_PAG_OPTS.map((f) => (
                      <option key={f} value={f}>
                        {f}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="px-6 py-4 border-t border-gray-100 flex gap-3">
                <button
                  onClick={() => setReciboModal(null)}
                  className="flex-1 py-2 rounded-lg bg-gray-600 text-white text-sm font-semibold hover:bg-gray-700 transition"
                >
                  Agora Não
                </button>
                <button
                  onClick={() =>
                    confirmarRecibo(reciboModal.fatura, reciboFormaPag)
                  }
                  className="flex-1 py-2 rounded-lg text-white text-sm font-semibold transition bg-teal-600 hover:bg-teal-700"
                >
                  🧾 Emitir Recibo
                </button>
              </div>
            </div>
          </div>
        )}
        {showGestaoProdutos && (
          <ModalWrapper
            title="📦 Gestão de Produtos"
            subtitle={`${todosProdutos.length} produtos · ${produtos.length} ativos`}
            onClose={() => {
              setShowGestaoProdutos(false);
              setGestaoSearch("");
              setGestaoCat(null);
            }}
            size="xl"
          >
            <div className="px-6 py-3 border-b border-gray-100 flex gap-3">
              <div className="flex-1 relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                  🔍
                </span>
                <input
                  type="text"
                  value={gestaoSearch}
                  onChange={(e) => setGestaoSearch(e.target.value)}
                  placeholder="Pesquisar por nome ou código..."
                  className="w-full pl-10 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-violet-400"
                />
              </div>
              <select
                value={gestaoCat || ""}
                onChange={(e) => setGestaoCat(e.target.value || null)}
                className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
              >
                <option value="">Todas categorias</option>
                {catalogCats.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              <button
                onClick={() => openNovoProdutoModal()}
                className="bg-violet-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-violet-700 transition flex items-center gap-2"
              >
                + Novo Produto
              </button>
            </div>
            <div className="overflow-y-auto max-h-[60vh]">
              {produtosGestao.length === 0 ? (
                <div className="py-16 text-center text-gray-400">
                  <div className="text-4xl mb-3">📦</div>
                  <p>Nenhum produto encontrado</p>
                </div>
              ) : (
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200 sticky top-0">
                    <tr>
                      <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">
                        Produto
                      </th>
                      <th className="text-left px-2 py-2 text-xs font-semibold text-gray-500">
                        Código
                      </th>
                      <th className="text-left px-2 py-2 text-xs font-semibold text-gray-500">
                        Categoria
                      </th>
                      <th className="text-right px-2 py-2 text-xs font-semibold text-gray-500">
                        Preço
                      </th>
                      <th className="text-center px-2 py-2 text-xs font-semibold text-gray-500">
                        Stock
                      </th>
                      <th className="text-center px-2 py-2 text-xs font-semibold text-gray-500">
                        IVA
                      </th>
                      <th className="text-center px-2 py-2 text-xs font-semibold text-gray-500">
                        Estado
                      </th>
                      <th className="text-right px-4 py-2 text-xs font-semibold text-gray-500">
                        Ações
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {produtosGestao.map((p) => {
                      const stockBaixo =
                        p.ativo && p.stock <= (p.stockMinimo || 0);
                      return (
                        <tr
                          key={p.id}
                          className={`border-b border-gray-50 hover:bg-gray-50/50 ${!p.ativo ? "opacity-50" : ""}`}
                        >
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-violet-100 flex items-center justify-center flex-shrink-0">
                                <span className="text-violet-600 text-xs font-bold">
                                  {p.nome.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <div>
                                <div className="text-sm font-semibold text-gray-800">
                                  {p.nome}
                                </div>
                                {p.descricao && (
                                  <div className="text-xs text-gray-400 truncate max-w-xs">
                                    {p.descricao}
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="px-2 py-3 text-xs text-gray-500 font-mono">
                            {p.codigo || "—"}
                          </td>
                          <td className="px-2 py-3 text-xs text-gray-500">
                            {p.categoria || "—"}
                          </td>
                          <td className="px-2 py-3 text-sm font-bold text-gray-800 text-right">
                            {formatCurrency(p.preco, moeda)}
                          </td>
                          <td className="px-2 py-3 text-center">
                            <span
                              className={`text-xs font-semibold px-2 py-1 rounded-full ${stockBaixo ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-700"}`}
                            >
                              {p.stock || 0}
                              {stockBaixo && " ⚠️"}
                            </span>
                          </td>
                          <td className="px-2 py-3 text-center">
                            <span
                              className={`text-xs px-2 py-0.5 rounded-full ${p.ivaIsento ? "bg-gray-100 text-gray-500" : "bg-blue-50 text-blue-600"}`}
                            >
                              {p.ivaIsento ? "Isento" : `${ivaTaxaDefault}%`}
                            </span>
                          </td>
                          <td className="px-2 py-3 text-center">
                            <span
                              className={`text-xs px-2 py-0.5 rounded-full font-semibold ${p.ativo ? "bg-emerald-100 text-emerald-700" : "bg-gray-100 text-gray-500"}`}
                            >
                              {p.ativo ? "Ativo" : "Inativo"}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="flex gap-1 justify-end">
                              <button
                                onClick={() => handleEditarProduto(p.id)}
                                className="text-xs text-blue-600 border border-blue-200 px-2 py-1 rounded hover:bg-blue-50 transition font-semibold"
                              >
                                ✏️ Editar
                              </button>
                              <button
                                onClick={() => handleDesativarProduto(p.id)}
                                className={`text-xs border px-2 py-1 rounded transition font-semibold ${p.ativo ? "text-amber-600 border-amber-200 hover:bg-amber-50" : "text-emerald-600 border-emerald-200 hover:bg-emerald-50"}`}
                              >
                                {p.ativo ? "⏸️" : "▶️"}
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </ModalWrapper>
        )}
        {showGestaoClientes && (
          <ModalWrapper
            title="👤 Gestão de Clientes"
            subtitle={`${data.pacientes.length} clientes`}
            onClose={() => {
              setShowGestaoClientes(false);
              setGestaoSearch("");
            }}
            size="xl"
          >
            <div className="px-6 py-3 border-b border-gray-100 flex gap-3">
              <div className="flex-1 relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                  🔍
                </span>
                <input
                  type="text"
                  value={gestaoSearch}
                  onChange={(e) => setGestaoSearch(e.target.value)}
                  placeholder="Pesquisar..."
                  className="w-full pl-10 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-teal-400"
                />
              </div>
              <button
                onClick={() => openNovoClienteModal()}
                className="bg-teal-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-teal-700 transition flex items-center gap-2"
              >
                + Novo Cliente
              </button>
            </div>
            <div className="overflow-y-auto max-h-[60vh]">
              {clientesGestao.length === 0 ? (
                <div className="py-16 text-center text-gray-400">
                  <div className="text-4xl mb-3">👤</div>
                  <p>Nenhum cliente encontrado</p>
                </div>
              ) : (
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200 sticky top-0">
                    <tr>
                      <th className="text-left px-4 py-2 text-xs font-semibold text-gray-500">
                        Cliente
                      </th>
                      <th className="text-left px-2 py-2 text-xs font-semibold text-gray-500">
                        Documento
                      </th>
                      <th className="text-left px-2 py-2 text-xs font-semibold text-gray-500">
                        Contacto
                      </th>
                      <th className="text-left px-2 py-2 text-xs font-semibold text-gray-500">
                        Morada
                      </th>
                      <th className="text-center px-2 py-2 text-xs font-semibold text-gray-500">
                        Faturas
                      </th>
                      <th className="text-right px-4 py-2 text-xs font-semibold text-gray-500">
                        Ações
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {clientesGestao.map((c) => {
                      const faturasCliente = data.faturas.filter(
                        (f) => f.pacienteId === c.id,
                      );
                      const totalGasto = faturasCliente.reduce(
                        (s, f) => s + f.total,
                        0,
                      );
                      const doc = c.nif
                        ? { tipo: "NIF", valor: c.nif }
                        : c.bi
                          ? { tipo: "BI", valor: c.bi }
                          : c.passaporte
                            ? { tipo: "PASS", valor: c.passaporte }
                            : null;
                      return (
                        <tr
                          key={c.id}
                          className="border-b border-gray-50 hover:bg-gray-50/50"
                        >
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-full bg-teal-100 flex items-center justify-center flex-shrink-0">
                                <span className="text-teal-600 text-xs font-bold">
                                  {c.nome.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <div>
                                <div className="text-sm font-semibold text-gray-800">
                                  {c.nome}
                                </div>
                                {c.email && (
                                  <div className="text-xs text-gray-400">
                                    {c.email}
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="px-2 py-3">
                            {doc ? (
                              <div>
                                <div className="text-xs font-semibold text-teal-600">
                                  {doc.tipo}
                                </div>
                                <div className="text-xs text-gray-600 font-mono">
                                  {doc.valor}
                                </div>
                              </div>
                            ) : (
                              <span className="text-xs text-gray-400">—</span>
                            )}
                          </td>
                          <td className="px-2 py-3 text-xs text-gray-600">
                            {c.telefone || (
                              <span className="text-gray-400">—</span>
                            )}
                          </td>
                          <td className="px-2 py-3 text-xs text-gray-600 max-w-xs truncate">
                            {c.endereco || (
                              <span className="text-gray-400">—</span>
                            )}
                          </td>
                          <td className="px-2 py-3 text-center">
                            <div className="text-xs font-bold text-gray-700">
                              {faturasCliente.length}
                            </div>
                            <div className="text-[10px] text-gray-400">
                              {formatCurrency(totalGasto, moeda)}
                            </div>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="flex gap-1 justify-end">
                              <button
                                onClick={() => handleEditarCliente(c.id)}
                                className="text-xs text-blue-600 border border-blue-200 px-2 py-1 rounded hover:bg-blue-50 transition font-semibold"
                              >
                                ✏️ Editar
                              </button>
                              <button
                                onClick={() => {
                                  setShowGestaoClientes(false);
                                  setPacienteId(String(c.id));
                                  setClienteNome(c.nome);
                                  setClienteNif(c.nif || "");
                                  setClienteEndereco(c.endereco || "");
                                  handleNovo();
                                }}
                                className="text-xs text-teal-600 border border-teal-200 px-2 py-1 rounded hover:bg-teal-50 transition font-semibold"
                              >
                                📄 Faturar
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </ModalWrapper>
        )}
        {showDashboard && (
          <ModalWrapper
            title="📊 Dashboard"
            subtitle="Resumo do negócio"
            onClose={() => setShowDashboard(false)}
            size="xl"
          >
            <div className="p-6 space-y-5">
              <div className="grid grid-cols-4 gap-4">
                <StatCard
                  icon="💰"
                  label="Total do Mês"
                  value={formatCurrency(stats.totalMes, moeda)}
                  sublabel={`${stats.docsMes} docs`}
                  color="from-blue-500 to-blue-600"
                />
                <StatCard
                  icon="✅"
                  label="Recebido"
                  value={formatCurrency(stats.totalPago, moeda)}
                  sublabel="Pagas"
                  color="from-emerald-500 to-emerald-600"
                />
                <StatCard
                  icon="⏳"
                  label="Pendente"
                  value={formatCurrency(stats.totalPendente, moeda)}
                  sublabel="A receber"
                  color="from-amber-500 to-amber-600"
                />
                <StatCard
                  icon="🚫"
                  label="Anulado"
                  value={formatCurrency(stats.totalAnulado, moeda)}
                  sublabel="Anuladas"
                  color="from-red-500 to-red-600"
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-white border border-gray-200 rounded-xl p-4">
                  <div className="text-xs font-bold text-gray-500 uppercase mb-2">
                    Documentos
                  </div>
                  <div className="text-3xl font-black text-gray-800">
                    {stats.totalDocs}
                  </div>
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-4">
                  <div className="text-xs font-bold text-gray-500 uppercase mb-2">
                    Produtos Ativos
                  </div>
                  <div className="text-3xl font-black text-violet-600">
                    {produtos.length}
                  </div>
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-4">
                  <div className="text-xs font-bold text-gray-500 uppercase mb-2">
                    Clientes
                  </div>
                  <div className="text-3xl font-black text-teal-600">
                    {data.pacientes.length}
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white border border-gray-200 rounded-xl p-4">
                  <h4 className="text-sm font-bold text-gray-700 mb-3">
                    🏆 Top 5 Clientes
                  </h4>
                  {stats.topClientes.length === 0 ? (
                    <p className="text-xs text-gray-400">Sem dados</p>
                  ) : (
                    <div className="space-y-2">
                      {stats.topClientes.map((c, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-gray-400 w-4">
                              {i + 1}.
                            </span>
                            <span className="text-sm text-gray-700">
                              {c.nome}
                            </span>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-bold text-emerald-600">
                              {formatCurrency(c.total, moeda)}
                            </div>
                            <div className="text-[10px] text-gray-400">
                              {c.count} faturas
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-4">
                  <h4 className="text-sm font-bold text-gray-700 mb-3">
                    📦 Top 5 Produtos
                  </h4>
                  {stats.topProdutos.length === 0 ? (
                    <p className="text-xs text-gray-400">Sem dados</p>
                  ) : (
                    <div className="space-y-2">
                      {stats.topProdutos.map((p, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between"
                        >
                          <div className="flex items-center gap-2 min-w-0 flex-1">
                            <span className="text-xs font-bold text-gray-400 w-4">
                              {i + 1}.
                            </span>
                            <span className="text-sm text-gray-700 truncate">
                              {p.nome}
                            </span>
                          </div>
                          <div className="text-right flex-shrink-0 ml-2">
                            <div className="text-sm font-bold text-violet-600">
                              {formatCurrency(p.total, moeda)}
                            </div>
                            <div className="text-[10px] text-gray-400">
                              {p.qtd} unid.
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              {stats.stockBaixo.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                  <h4 className="text-sm font-bold text-red-700 mb-3">
                    ⚠️ Stock Baixo ({stats.stockBaixo.length})
                  </h4>
                  <div className="space-y-2">
                    {stats.stockBaixo.map((p) => (
                      <div
                        key={p.id}
                        className="flex items-center justify-between bg-white rounded-lg px-3 py-2"
                      >
                        <span className="text-sm text-gray-700">{p.nome}</span>
                        <div className="text-right">
                          <span className="text-sm font-bold text-red-600">
                            {p.stock || 0}
                          </span>
                          <span className="text-xs text-gray-400 ml-2">
                            / mín. {p.stockMinimo || 0}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </ModalWrapper>
        )}
        {showRelatorios && (
          <ModalWrapper
            title="📈 Relatórios"
            subtitle="Análise detalhada"
            onClose={() => setShowRelatorios(false)}
            size="xl"
          >
            <div className="p-6 space-y-5">
              <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Tipo de Relatório
                  </label>
                  <div className="grid grid-cols-6 gap-2">
                    {[
                      { v: "resumo", l: "📊 Resumo" },
                      { v: "iva", l: "💰 IVA" },
                      { v: "clientes", l: "👥 Clientes" },
                      { v: "produtos", l: "📦 Produtos" },
                      { v: "pagamentos", l: "💳 Pagamentos" },
                      { v: "vencidos", l: "⚠️ Vencidos" },
                    ].map((t) => (
                      <button
                        key={t.v}
                        onClick={() => setRelatorioTipo(t.v as any)}
                        className={`px-3 py-2 rounded-lg text-xs font-semibold border transition ${relatorioTipo === t.v ? "bg-[#00AEEF] text-white border-[#00AEEF]" : "bg-white border-gray-200 text-gray-600 hover:bg-gray-100"}`}
                      >
                        {t.l}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Período
                  </label>
                  <div className="flex gap-2 flex-wrap">
                    {[
                      { v: "dia", l: "Hoje" },
                      { v: "semana", l: "Semana" },
                      { v: "mes", l: "Mês" },
                      { v: "trimestre", l: "Trimestre" },
                      { v: "ano", l: "Ano" },
                    ].map((p) => (
                      <button
                        key={p.v}
                        onClick={() => setRelatorioPeriodo(p.v as any)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition ${relatorioPeriodo === p.v ? "bg-blue-500 text-white border-blue-500" : "bg-white border-gray-200 text-gray-600 hover:bg-gray-100"}`}
                      >
                        {p.l}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-4 gap-4">
                <StatCard
                  icon="📄"
                  label="Documentos"
                  value={String(dadosRelatorio.count)}
                  color="from-blue-500 to-blue-600"
                />
                <StatCard
                  icon="💰"
                  label="Total Faturado"
                  value={formatCurrency(dadosRelatorio.total, moeda)}
                  color="from-emerald-500 to-emerald-600"
                />
                <StatCard
                  icon="✅"
                  label="Recebido"
                  value={formatCurrency(dadosRelatorio.totalPaga, moeda)}
                  color="from-teal-500 to-teal-600"
                />
                <StatCard
                  icon="⏳"
                  label="Por Receber"
                  value={formatCurrency(dadosRelatorio.totalEmitida, moeda)}
                  color="from-amber-500 to-amber-600"
                />
              </div>
              {relatorioTipo === "resumo" && (
                <div className="space-y-4">
                  <div className="bg-white border border-gray-200 rounded-xl p-4">
                    <h4 className="text-sm font-bold text-gray-700 mb-3">
                      📋 Por Tipo
                    </h4>
                    {Object.keys(dadosRelatorio.porTipo).length === 0 ? (
                      <p className="text-xs text-gray-400">Sem dados</p>
                    ) : (
                      <div className="space-y-2">
                        {Object.entries(dadosRelatorio.porTipo).map(
                          ([tipo, d]) => (
                            <div
                              key={tipo}
                              className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0"
                            >
                              <div className="flex items-center gap-2">
                                <FTAvatar tipo={tipo} />
                                <span className="text-sm font-medium text-gray-700">
                                  {TIPO_LABEL[tipo] ?? tipo}
                                </span>
                              </div>
                              <div className="text-right">
                                <div className="text-sm font-bold text-gray-800">
                                  {formatCurrency(d.total, moeda)}
                                </div>
                                <div className="text-xs text-gray-400">
                                  {d.count} docs
                                </div>
                              </div>
                            </div>
                          ),
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
              {relatorioTipo === "iva" && (
                <div className="bg-white border border-gray-200 rounded-xl p-4">
                  <h4 className="text-sm font-bold text-gray-700 mb-3">
                    💰 Relatório de IVA
                  </h4>
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="bg-blue-50 rounded-lg p-3">
                      <div className="text-xs text-blue-600 font-semibold">
                        Base
                      </div>
                      <div className="text-xl font-black text-blue-700">
                        {formatCurrency(dadosRelatorio.totalSemIva, moeda)}
                      </div>
                    </div>
                    <div className="bg-emerald-50 rounded-lg p-3">
                      <div className="text-xs text-emerald-600 font-semibold">
                        IVA
                      </div>
                      <div className="text-xl font-black text-emerald-700">
                        {formatCurrency(dadosRelatorio.totalIva, moeda)}
                      </div>
                    </div>
                    <div className="bg-violet-50 rounded-lg p-3">
                      <div className="text-xs text-violet-600 font-semibold">
                        Total
                      </div>
                      <div className="text-xl font-black text-violet-700">
                        {formatCurrency(dadosRelatorio.total, moeda)}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ModalWrapper>
        )}
        {showTemplates && (
          <ModalWrapper
            title="📋 Templates"
            subtitle="Pacotes pré-configurados"
            onClose={() => setShowTemplates(false)}
            size="xl"
          >
            <div className="p-6 space-y-4">
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setTemplateForm({
                      id: "",
                      nome: "",
                      descricao: "",
                      tipoDocumento: "pro-forma",
                      linhas: [],
                      observacoes: "",
                      criadoEm: hoje,
                      usadoCount: 0,
                      categoria: "Geral",
                    });
                    setTemplateEditando(null);
                    setShowNovoTemplate(true);
                  }}
                  className="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-purple-700 transition"
                >
                  ➕ Criar Template
                </button>
                <button
                  onClick={handleCriarTemplateDaFaturaAtual}
                  disabled={linhas.length === 0}
                  className="bg-violet-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-violet-700 transition disabled:opacity-50"
                >
                  💾 Salvar Fatura Atual
                </button>
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-700 mb-2">
                  🧪 Pacotes Pré-definidos
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  {templatesLaboratorio.map((t) => (
                    <div
                      key={t.id}
                      className="border border-purple-200 rounded-lg p-3 hover:bg-purple-50 transition"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="text-sm font-bold text-gray-800">
                            {t.nome}
                          </div>
                          <Badge color="purple">{t.categoria}</Badge>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500 mb-2">
                        {t.descricao}
                      </p>
                      <div className="text-xs font-bold text-purple-600 mb-2">
                        {formatCurrency(
                          t.linhas.reduce(
                            (s, l) => s + l.precoUnitario * l.quantidade,
                            0,
                          ),
                          moeda,
                        )}
                      </div>
                      <button
                        onClick={() => handleUsarTemplate(t)}
                        className="w-full py-1.5 rounded bg-purple-100 text-purple-700 text-xs font-semibold hover:bg-purple-200 transition"
                      >
                        ✅ Usar
                      </button>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-700 mb-2">
                  ⭐ Meus Templates ({templates.length})
                </h4>
                {templates.length === 0 ? (
                  <div className="py-8 text-center text-gray-400">
                    <div className="text-4xl mb-2">📋</div>
                    <p className="text-sm">Nenhum template personalizado</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {templates.map((t) => (
                      <div
                        key={t.id}
                        className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 transition"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="text-sm font-bold text-gray-800">
                              {t.nome}
                            </div>
                            <div className="text-xs text-gray-500">
                              {t.linhas.length} item(s) · Usado {t.usadoCount}x
                            </div>
                          </div>
                          <div className="flex gap-1">
                            <button
                              onClick={() => handleUsarTemplate(t)}
                              className="text-xs bg-emerald-100 text-emerald-700 px-3 py-1 rounded font-semibold hover:bg-emerald-200"
                            >
                              Usar
                            </button>
                            <button
                              onClick={() => handleEditarTemplate(t)}
                              className="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded font-semibold hover:bg-blue-200"
                            >
                              Editar
                            </button>
                            <button
                              onClick={() => handleRemoverTemplate(t.id)}
                              className="text-xs bg-red-100 text-red-700 px-3 py-1 rounded font-semibold hover:bg-red-200"
                            >
                              🗑
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </ModalWrapper>
        )}
        {showNovoTemplate && (
          <ModalWrapper
            title={templateEditando ? "Editar Template" : "Novo Template"}
            onClose={() => {
              setShowNovoTemplate(false);
              setTemplateEditando(null);
            }}
            size="lg"
          >
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Nome <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={templateForm.nome}
                    onChange={(e) =>
                      setTemplateForm((t) => ({ ...t, nome: e.target.value }))
                    }
                    placeholder="Ex: Check-up"
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-purple-400"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                    Categoria
                  </label>
                  <input
                    type="text"
                    value={templateForm.categoria || ""}
                    onChange={(e) =>
                      setTemplateForm((t) => ({
                        ...t,
                        categoria: e.target.value,
                      }))
                    }
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-purple-400"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                  Descrição
                </label>
                <input
                  type="text"
                  value={templateForm.descricao || ""}
                  onChange={(e) =>
                    setTemplateForm((t) => ({
                      ...t,
                      descricao: e.target.value,
                    }))
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-purple-400"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                  Itens
                </label>
                <div className="space-y-2">
                  {templateForm.linhas.map((l, i) => (
                    <div
                      key={i}
                      className="flex gap-2 items-center bg-gray-50 rounded-lg p-2"
                    >
                      <input
                        type="text"
                        value={l.descricao}
                        onChange={(e) => {
                          const novas = [...templateForm.linhas];
                          novas[i] = { ...novas[i], descricao: e.target.value };
                          setTemplateForm((t) => ({ ...t, linhas: novas }));
                        }}
                        placeholder="Nome"
                        className="flex-1 border border-gray-200 rounded px-2 py-1 text-sm"
                      />
                      <input
                        type="number"
                        value={l.quantidade}
                        onChange={(e) => {
                          const novas = [...templateForm.linhas];
                          novas[i] = {
                            ...novas[i],
                            quantidade: Number(e.target.value),
                          };
                          setTemplateForm((t) => ({ ...t, linhas: novas }));
                        }}
                        className="w-16 border border-gray-200 rounded px-2 py-1 text-sm text-center"
                      />
                      <input
                        type="number"
                        value={l.precoUnitario}
                        onChange={(e) => {
                          const novas = [...templateForm.linhas];
                          novas[i] = {
                            ...novas[i],
                            precoUnitario: Number(e.target.value),
                          };
                          setTemplateForm((t) => ({ ...t, linhas: novas }));
                        }}
                        className="w-24 border border-gray-200 rounded px-2 py-1 text-sm text-right"
                      />
                      <button
                        onClick={() =>
                          setTemplateForm((t) => ({
                            ...t,
                            linhas: t.linhas.filter((_, idx) => idx !== i),
                          }))
                        }
                        className="text-red-400 hover:text-red-600 px-2"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() =>
                      setTemplateForm((t) => ({
                        ...t,
                        linhas: [
                          ...t.linhas,
                          {
                            descricao: "",
                            quantidade: 1,
                            precoUnitario: 0,
                            ivaIsento: false,
                            unidade: "exame",
                          },
                        ],
                      }))
                    }
                    className="w-full py-2 rounded-lg border-2 border-dashed border-gray-300 text-gray-500 text-sm hover:border-purple-400 hover:text-purple-600 transition"
                  >
                    + Adicionar
                  </button>
                </div>
              </div>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                <div className="text-xs font-semibold text-purple-700 mb-1">
                  Total
                </div>
                <div className="text-xl font-black text-purple-700">
                  {formatCurrency(
                    templateForm.linhas.reduce(
                      (s, l) => s + l.precoUnitario * l.quantidade,
                      0,
                    ),
                    moeda,
                  )}
                </div>
              </div>
              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => {
                    setShowNovoTemplate(false);
                    setTemplateEditando(null);
                  }}
                  className="flex-1 py-2 rounded-lg bg-gray-200 text-gray-700 text-sm font-semibold hover:bg-gray-300 transition"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleSalvarTemplate}
                  className="flex-1 py-2 rounded-lg bg-purple-600 text-white text-sm font-semibold hover:bg-purple-700 transition"
                >
                  💾 Salvar
                </button>
              </div>
            </div>
          </ModalWrapper>
        )}
        {showLogs && (
          <ModalWrapper
            title="📋 Logs de Auditoria"
            subtitle={`${logs.length} registros`}
            onClose={() => setShowLogs(false)}
            size="xl"
          >
            <div className="p-6 space-y-4">
              <div className="flex gap-2 items-center justify-between">
                <div className="flex gap-2">
                  {["todos", "faturas", "produtos", "clientes", "sistema"].map(
                    (m) => (
                      <button
                        key={m}
                        onClick={() => setLogFiltro(m as any)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition ${logFiltro === m ? "bg-gray-800 text-white border-gray-800" : "bg-white border-gray-200 text-gray-600 hover:bg-gray-100"}`}
                      >
                        {m === "todos"
                          ? "Todos"
                          : m.charAt(0).toUpperCase() + m.slice(1)}
                      </button>
                    ),
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleExportarLogs}
                    className="text-xs bg-emerald-100 text-emerald-700 px-3 py-1.5 rounded font-semibold hover:bg-emerald-200"
                  >
                    📥 CSV
                  </button>
                  <button
                    onClick={handleLimparLogs}
                    className="text-xs bg-red-100 text-red-700 px-3 py-1.5 rounded font-semibold hover:bg-red-200"
                  >
                    🗑 Limpar
                  </button>
                </div>
              </div>
              {logs.length === 0 ? (
                <div className="py-16 text-center text-gray-400">
                  <div className="text-4xl mb-3">📋</div>
                  <p>Nenhum log</p>
                </div>
              ) : (
                <div className="space-y-1 max-h-[60vh] overflow-y-auto">
                  {logs
                    .filter(
                      (l) =>
                        logFiltro === "todos" ||
                        l.modulo.toLowerCase() === logFiltro,
                    )
                    .map((l) => {
                      const data = new Date(l.timestamp);
                      const dataStr = `${String(data.getDate()).padStart(2, "0")}/${String(data.getMonth() + 1).padStart(2, "0")}/${data.getFullYear()} ${String(data.getHours()).padStart(2, "0")}:${String(data.getMinutes()).padStart(2, "0")}`;
                      const corModulo =
                        l.modulo === "Faturas"
                          ? "blue"
                          : l.modulo === "Produtos"
                            ? "violet"
                            : l.modulo === "Clientes"
                              ? "teal"
                              : "gray";
                      return (
                        <div
                          key={l.id}
                          className="flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-50 border-b border-gray-100"
                        >
                          <div className="text-xs text-gray-400 w-32 flex-shrink-0 font-mono">
                            {dataStr}
                          </div>
                          <Badge color={corModulo}>{l.modulo}</Badge>
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-semibold text-gray-800">
                              {l.acao}
                            </div>
                            <div className="text-xs text-gray-500 truncate">
                              {l.detalhes}
                            </div>
                          </div>
                          <div className="text-xs text-gray-400 flex-shrink-0">
                            👤 {l.usuario}
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          </ModalWrapper>
        )}
        {showNotificacoes && (
          <ModalWrapper
            title="🔔 Notificações"
            subtitle={`${notificacoesNaoLidas} não lida(s)`}
            onClose={() => setShowNotificacoes(false)}
            size="lg"
          >
            <div className="p-6 space-y-4">
              <div className="flex gap-2">
                <button
                  onClick={handleMarcarTodasLidas}
                  disabled={notificacoesNaoLidas === 0}
                  className="flex-1 py-2 rounded-lg bg-blue-100 text-blue-700 text-sm font-semibold hover:bg-blue-200 transition disabled:opacity-50"
                >
                  ✓ Marcar Todas
                </button>
                <button
                  onClick={handleLimparNotificacoes}
                  disabled={notificacoes.length === 0}
                  className="flex-1 py-2 rounded-lg bg-red-100 text-red-700 text-sm font-semibold hover:bg-red-200 transition disabled:opacity-50"
                >
                  🗑 Limpar
                </button>
              </div>
              {notificacoes.length === 0 ? (
                <div className="py-16 text-center text-gray-400">
                  <div className="text-4xl mb-3">🔔</div>
                  <p>Nenhuma notificação 🎉</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                  {notificacoes.map((n) => {
                    const icon =
                      n.tipo === "vencimento"
                        ? "⏰"
                        : n.tipo === "stock"
                          ? "📦"
                          : n.tipo === "pagamento"
                            ? "💰"
                            : "ℹ️";
                    return (
                      <div
                        key={n.id}
                        onClick={() => handleAcaoNotificacao(n)}
                        className={`p-3 rounded-lg border cursor-pointer transition ${n.lida ? "bg-white border-gray-200 opacity-60" : "bg-blue-50 border-blue-200"} hover:shadow-md`}
                      >
                        <div className="flex items-start gap-3">
                          <div className="text-2xl">{icon}</div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <div className="text-sm font-bold text-gray-800">
                                {n.titulo}
                              </div>
                              {!n.lida && (
                                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                              )}
                            </div>
                            <div className="text-xs text-gray-600 mt-1">
                              {n.mensagem}
                            </div>
                            <div className="text-[10px] text-gray-400 mt-1">
                              {n.data} às {n.hora}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </ModalWrapper>
        )}
        {showConfig && (
          <ModalWrapper
            title="⚙️ Configurações"
            onClose={() => setShowConfig(false)}
            size="lg"
          >
            <div className="p-6 space-y-5">
              <div>
                <h4 className="text-sm font-bold text-gray-700 mb-3">
                  🏢 Dados da Empresa
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Nome
                    </label>
                    <input
                      type="text"
                      value={configForm.nomeClinica}
                      onChange={(e) =>
                        setConfigForm((c) => ({
                          ...c,
                          nomeClinica: e.target.value,
                        }))
                      }
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-400"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      NIF
                    </label>
                    <input
                      type="text"
                      value={configForm.nif}
                      onChange={(e) =>
                        setConfigForm((c) => ({ ...c, nif: e.target.value }))
                      }
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-400"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Telefone
                    </label>
                    <input
                      type="text"
                      value={configForm.telefone}
                      onChange={(e) =>
                        setConfigForm((c) => ({
                          ...c,
                          telefone: e.target.value,
                        }))
                      }
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-400"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Email
                    </label>
                    <input
                      type="email"
                      value={configForm.email}
                      onChange={(e) =>
                        setConfigForm((c) => ({ ...c, email: e.target.value }))
                      }
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-400"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Endereço
                    </label>
                    <input
                      type="text"
                      value={configForm.endereco}
                      onChange={(e) =>
                        setConfigForm((c) => ({
                          ...c,
                          endereco: e.target.value,
                        }))
                      }
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-400"
                    />
                  </div>
                </div>
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-700 mb-3">
                  📄 Faturação
                </h4>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Série
                    </label>
                    <input
                      type="text"
                      value={configForm.serie}
                      onChange={(e) =>
                        setConfigForm((c) => ({ ...c, serie: e.target.value }))
                      }
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-400"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      Moeda
                    </label>
                    <select
                      value={configForm.moeda}
                      onChange={(e) =>
                        setConfigForm((c) => ({ ...c, moeda: e.target.value }))
                      }
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-400"
                    >
                      <option value="AOA">Kwanza (AOA)</option>
                      <option value="USD">Dólar (USD)</option>
                      <option value="EUR">Euro (EUR)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-600 mb-1.5 block">
                      IVA (%)
                    </label>
                    <input
                      type="number"
                      value={configForm.ivaTaxa}
                      onChange={(e) =>
                        setConfigForm((c) => ({
                          ...c,
                          ivaTaxa: Number(e.target.value),
                        }))
                      }
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-400"
                    />
                  </div>
                </div>
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-700 mb-3">
                  💾 Backup
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={handleExportarBackup}
                    className="py-3 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700 transition"
                  >
                    📥 Exportar Backup
                  </button>
                  <button
                    onClick={() =>
                      setToast({
                        message: "Funcionalidade em desenvolvimento",
                        type: "info",
                      })
                    }
                    className="py-3 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 transition"
                  >
                    📤 Importar Backup
                  </button>
                </div>
              </div>
              <div className="flex gap-2 pt-4 border-t border-gray-200">
                <button
                  onClick={() => setShowConfig(false)}
                  className="flex-1 py-2.5 rounded-lg bg-gray-200 text-gray-700 text-sm font-semibold hover:bg-gray-300 transition"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleSalvarConfig}
                  className="flex-1 py-2.5 rounded-lg bg-[#00AEEF] text-white text-sm font-semibold hover:bg-[#0099d4] transition"
                >
                  ✓ Salvar
                </button>
              </div>
            </div>
          </ModalWrapper>
        )}
        {showUploadModal && (
          <ModalWrapper
            title="📤 Upload"
            onClose={() => setShowUploadModal(false)}
            size="md"
          >
            <div className="p-6 space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition">
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png,.gif,.webp,.doc,.docx"
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <div className="text-4xl mb-2">📄</div>
                  <p className="text-sm font-semibold text-gray-700 mb-1">
                    Clique para carregar
                  </p>
                  <p className="text-xs text-gray-500">
                    PDF, JPG, PNG, DOC até 10MB
                  </p>
                </label>
              </div>
              {uploadArquivo && (
                <div className="bg-gray-50 rounded-lg p-3">
                  <span className="text-sm font-semibold text-gray-700">
                    📎 {uploadArquivo.name}
                  </span>
                  <span className="text-xs text-gray-500 ml-2">
                    ({(uploadArquivo.size / 1024).toFixed(1)} KB)
                  </span>
                </div>
              )}
              {uploadExtraindo && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                    <div>
                      <p className="text-sm font-semibold text-blue-700">
                        Extraindo dados...
                      </p>
                    </div>
                  </div>
                </div>
              )}
              {uploadDadosExtraidos && !uploadExtraindo && (
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-emerald-600 text-xl">✓</span>
                    <span className="text-sm font-semibold text-emerald-700">
                      Dados extraídos!
                    </span>
                  </div>
                  {uploadTipo === "cliente" && uploadPreview && (
                    <img
                      src={uploadPreview}
                      alt="Foto"
                      className="w-20 h-20 rounded-full mx-auto border-2 border-emerald-300 mb-3"
                    />
                  )}
                  <div className="space-y-1 text-xs">
                    {Object.entries(uploadDadosExtraidos)
                      .filter(([key]) => key !== "foto")
                      .map(([key, value]) => (
                        <div key={key} className="flex justify-between">
                          <span className="text-gray-600 font-medium">
                            {key}:
                          </span>
                          <span className="text-gray-800">{String(value)}</span>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
            <div className="px-6 py-4 border-t border-gray-100 flex gap-3">
              <button
                onClick={() => setShowUploadModal(false)}
                className="flex-1 py-2 rounded-lg bg-gray-600 text-white text-sm font-semibold hover:bg-gray-700 transition"
              >
                Cancelar
              </button>
              <button
                onClick={aplicarDadosExtraidos}
                disabled={!uploadDadosExtraidos}
                className="flex-1 py-2 rounded-lg text-white text-sm font-semibold transition bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300"
              >
                ✓ Aplicar
              </button>
            </div>
          </ModalWrapper>
        )}
        {showChat && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between flex-shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center">
                    <span className="text-white text-lg">🤖</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-gray-800">
                      Assistente
                    </h3>
                    <p className="text-xs text-gray-400">Ctrl+H</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowChat(false)}
                  className="text-gray-400 hover:text-gray-600 w-7 h-7 flex items-center justify-center rounded hover:bg-gray-100"
                >
                  ✕
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg px-4 py-2 ${msg.role === "user" ? "bg-blue-500 text-white" : "bg-gray-100 text-gray-800"}`}
                    >
                      <p className="text-sm whitespace-pre-wrap">
                        {msg.content}
                      </p>
                      <p
                        className={`text-[10px] mt-1 ${msg.role === "user" ? "text-blue-100" : "text-gray-400"}`}
                      >
                        {msg.timestamp}
                      </p>
                    </div>
                  </div>
                ))}
                {isProcessing && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 rounded-lg px-4 py-2">
                      <div className="flex gap-1">
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0ms" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "150ms" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "300ms" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>
              <div className="px-6 py-4 border-t border-gray-100 flex-shrink-0">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleChatSubmit();
                      }
                    }}
                    placeholder="Digite sua mensagem..."
                    className="flex-1 border border-gray-200 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-blue-400"
                    disabled={isProcessing}
                  />
                  <button
                    onClick={toggleVoiceRecognition}
                    className={`px-4 py-2 rounded-lg text-white text-sm font-semibold transition ${isListening ? "bg-red-500 animate-pulse" : "bg-blue-500 hover:bg-blue-600"}`}
                  >
                    {isListening ? "🔴" : "🎤"}
                  </button>
                  <button
                    onClick={handleChatSubmit}
                    disabled={!chatInput.trim() || isProcessing}
                    className="px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 transition disabled:bg-gray-300"
                  >
                    Enviar
                  </button>
                </div>
                <div className="flex gap-2 mt-2 flex-wrap">
                  <button
                    onClick={() => {
                      setChatInput("faturar");
                      handleChatSubmit();
                    }}
                    className="text-xs px-3 py-1 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition"
                  >
                    📄 Faturar
                  </button>
                  <button
                    onClick={() => {
                      setChatInput("pos");
                      handleChatSubmit();
                    }}
                    className="text-xs px-3 py-1 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition"
                  >
                    💰 POS
                  </button>
                  <button
                    onClick={() => {
                      setChatInput("dashboard");
                      handleChatSubmit();
                    }}
                    className="text-xs px-3 py-1 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition"
                  >
                    📊 Dashboard
                  </button>
                  <button
                    onClick={() => {
                      setChatInput("ajuda");
                      handleChatSubmit();
                    }}
                    className="text-xs px-3 py-1 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition"
                  >
                    ❓ Ajuda
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        {confirmModal && (
          <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
              <div className="px-6 py-4 border-b border-gray-100">
                <h3 className="font-bold text-base text-gray-800">
                  {confirmModal.title}
                </h3>
                <p className="text-sm text-gray-600 mt-2">
                  {confirmModal.message}
                </p>
              </div>
              <div className="px-6 py-4 flex gap-3">
                <button
                  onClick={() => setConfirmModal(null)}
                  className="flex-1 py-2 rounded-lg bg-gray-200 text-gray-700 text-sm font-semibold hover:bg-gray-300 transition"
                >
                  {confirmModal.cancelText || "Cancelar"}
                </button>
                <button
                  onClick={confirmModal.onConfirm}
                  className={`flex-1 py-2 rounded-lg text-white text-sm font-semibold hover:opacity-90 transition ${confirmModal.type === "danger" ? "bg-red-500" : confirmModal.type === "info" ? "bg-blue-500" : "bg-amber-500"}`}
                >
                  {confirmModal.confirmText || "Confirmar"}
                </button>
              </div>
            </div>
          </div>
        )}
        {showNotasCreditoPage && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl max-h-[95vh] flex flex-col overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between flex-shrink-0 bg-gradient-to-r from-orange-50 to-white">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-orange-500 flex items-center justify-center shadow-sm">
                    <span className="text-white text-lg">🧾</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-gray-800">
                      Notas de Crédito
                    </h3>
                    <p className="text-xs text-gray-400">
                      Gestão de Notas de Crédito
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowNotasCreditoPage(false)}
                  className="text-gray-400 hover:text-gray-600 w-9 h-9 flex items-center justify-center rounded-lg hover:bg-gray-100 text-xl transition"
                  title="Fechar (Esc)"
                >
                  ×
                </button>
              </div>
              <div className="flex-1 overflow-y-auto bg-gray-50">
                <NotasCreditoPage />
              </div>
            </div>
          </div>
        )}
        <div className="w-72 flex-shrink-0 space-y-3">
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
            <div className="px-4 py-3 border-b border-gray-100 bg-gray-50">
              <h3 className="text-sm font-bold text-gray-700">Filtro</h3>
            </div>
            <div className="px-4 py-3.5 border-b border-gray-50">
              <div className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-3">
                Estado
              </div>
              <div className="space-y-1.5">
                {[
                  {
                    val: "todos",
                    label: "Todos",
                    dot: "bg-gray-400",
                    count: data.faturas.filter((f) => f.estado !== "rascunho")
                      .length,
                  },
                  {
                    val: "emitida",
                    label: "Emitida",
                    dot: "bg-blue-500",
                    count: data.faturas.filter((f) => f.estado === "emitida")
                      .length,
                  },
                  {
                    val: "paga",
                    label: "Paga",
                    dot: "bg-emerald-500",
                    count: data.faturas.filter((f) => f.estado === "paga")
                      .length,
                  },
                  {
                    val: "rascunho",
                    label: "Rascunho",
                    dot: "bg-amber-400",
                    count: data.faturas.filter((f) => f.estado === "rascunho")
                      .length,
                  },
                  {
                    val: "anulada",
                    label: "Anulada",
                    dot: "bg-red-400",
                    count: data.faturas.filter((f) => f.estado === "anulada")
                      .length,
                  },
                ].map((o) => (
                  <label
                    key={o.val}
                    className={`flex items-center gap-2.5 cursor-pointer text-xs rounded-lg px-2 py-1.5 transition ${filtroEstado === o.val ? "bg-gray-100 font-semibold text-gray-800" : "text-gray-500 hover:bg-gray-50"}`}
                  >
                    <input
                      type="radio"
                      name="filtroEstado"
                      value={o.val}
                      checked={filtroEstado === o.val}
                      onChange={() => setFiltroEstado(o.val)}
                      className="sr-only"
                    />
                    <span
                      className={`w-2.5 h-2.5 rounded-full shrink-0 ${o.dot}`}
                    />
                    <span className="flex-1">{o.label}</span>
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${filtroEstado === o.val ? "bg-gray-200 text-gray-700" : "bg-gray-100 text-gray-400"}`}
                    >
                      {o.count}
                    </span>
                  </label>
                ))}
              </div>
            </div>
            <div className="p-4">
              <button
                onClick={() => {
                  setSearch("");
                  setFiltroEstado("todos");
                  setFiltroTipo("todos");
                }}
                className="w-full text-center text-xs font-semibold py-1.5 rounded-lg bg-red-50 text-red-500 hover:bg-red-100 transition border border-red-100"
              >
                🗑 Limpar Filtro
              </button>
            </div>
          </div>
          <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
            <p className="text-xs text-gray-500 font-bold mb-3 uppercase tracking-wide">
              Tipos
            </p>
            <div className="space-y-1.5 text-xs">
              {[
                { tipo: "todos", label: "Todos" },
                { tipo: "factura", label: "Factura" },
                { tipo: "factura-global", label: "Factura Global" },
                { tipo: "pro-forma", label: "Pró-Forma" },
                { tipo: "nota-credito", label: "Nota de Crédito" },
              ].map(({ tipo, label }) => {
                const cfg = TIPO_AVATAR[tipo] ?? {
                  bg: "bg-gray-400",
                  code: "·",
                };
                const isActive = filtroTipo === tipo;
                return (
                  <button
                    key={tipo}
                    onClick={() => setFiltroTipo(tipo)}
                    className={`w-full flex items-center gap-2.5 rounded-lg px-2 py-1.5 transition text-left ${isActive ? "bg-[#00AEEF]/10 font-semibold text-[#0077a8]" : "text-gray-600 hover:bg-gray-50"}`}
                  >
                    {tipo === "todos" ? (
                      <div className="w-7 h-7 rounded-full bg-gray-300 flex items-center justify-center flex-shrink-0">
                        <span className="text-white text-[10px] font-black">
                          ·
                        </span>
                      </div>
                    ) : (
                      <div
                        className={`w-7 h-7 rounded-full ${cfg.bg} flex items-center justify-center flex-shrink-0`}
                      >
                        <span className="text-white text-[10px] font-black">
                          {cfg.code}
                        </span>
                      </div>
                    )}
                    <span className="flex-1">{label}</span>
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${isActive ? "bg-[#00AEEF]/20 text-[#0077a8]" : "bg-gray-100 text-gray-400"}`}
                    >
                      {tipo === "todos"
                        ? data.faturas.length
                        : data.faturas.filter(
                            (f) => (f.tipoDocumento || "factura") === tipo,
                          ).length}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
          <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-3">
              Resumo
            </p>
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-gray-400">Documentos</span>
                <span className="font-bold text-gray-700">
                  {data.faturas.length}
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-gray-400">Recebido</span>
                <span className="font-bold text-emerald-600">
                  {formatCurrency(
                    data.faturas
                      .filter((f) => f.estado === "paga")
                      .reduce((s, f) => s + f.total, 0),
                    moeda,
                  )}
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-gray-400">Pendente</span>
                <span className="font-bold text-blue-500">
                  {formatCurrency(
                    data.faturas
                      .filter((f) => f.estado === "emitida")
                      .reduce((s, f) => s + f.total, 0),
                    moeda,
                  )}
                </span>
              </div>
              <div className="flex justify-between text-xs pt-2 border-t border-gray-100">
                <span className="text-gray-400">Produtos</span>
                <span className="font-bold text-violet-600">
                  {produtos.length}
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-gray-400">Clientes</span>
                <span className="font-bold text-teal-600">
                  {data.pacientes.length}
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-gray-400">Templates</span>
                <span className="font-bold text-purple-600">
                  {templates.length}
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-gray-400">⭐ Favoritos</span>
                <span className="font-bold text-amber-600">
                  {posFavoritos.length}
                </span>
              </div>
            </div>
          </div>
          <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-3">
              ⌨️ Atalhos
            </p>
            <div className="space-y-1.5 text-xs text-gray-500">
              {[
                { label: "Novo documento", key: "Ctrl+N" },
                { label: "Novo produto", key: "Ctrl+P" },
                { label: "Novo cliente", key: "Ctrl+C" },
                { label: "Dashboard", key: "Ctrl+D" },
                { label: "Assistente", key: "Ctrl+H" },
                { label: "POS Favoritos", key: "F1" },
                { label: "POS Recentes", key: "F2" },
                { label: "POS Código barras", key: "F7" },
                { label: "POS Transferir", key: "F8" },
                { label: "POS Modo caixa", key: "F11" },
              ].map(({ label, key }) => (
                <div key={key} className="flex justify-between">
                  <span>{label}</span>
                  <kbd className="px-1.5 py-0.5 bg-gray-100 rounded text-[10px] font-mono">
                    {key}
                  </kbd>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
