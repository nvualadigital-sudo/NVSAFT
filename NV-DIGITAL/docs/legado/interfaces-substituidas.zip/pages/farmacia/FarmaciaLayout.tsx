import { useFarmaciaContext } from "./FarmaciaContext";
import FarmaciaRouter from "./FarmaciaRouter";
import FarmaciaClienteModal from "./components/FarmaciaClienteModal";
import FarmaciaHeader from "./components/FarmaciaHeader";
import FarmaciaNotificacoes from "./components/FarmaciaNotificacoes";
import FarmaciaProdutoModal from "./components/FarmaciaProdutoModal";
import FarmaciaSidebar from "./components/FarmaciaSidebar";
import { Ico } from "./shared";
export default function FarmaciaLayout(){
const {lightMode,setShowNotifs,toast,toastOn,nav}=useFarmaciaContext();
return (
    <div id="farm-wrapper" className={lightMode ? "light" : ""} onClick={()=>setShowNotifs(false)}>

      <FarmaciaHeader />
{/* BODY */}
      <div className="farm-body">
        {/* SIDEBAR */}
        <FarmaciaSidebar />

        {/* CONTENT */}
        <div className="farm-content">
          <FarmaciaRouter />
        </div>
      </div>

      <FarmaciaNotificacoes />
<FarmaciaProdutoModal />
<FarmaciaClienteModal />
{/* TOAST */}
      <div className={`farm-toast${toastOn?" show":""}`}>{toast}</div>

      {/* FAB */}
      <div className="farm-floating">
        <button className="farm-fab" title="Nova Venda" onClick={()=>nav("pos")}><Ico name="cash-register" /></button>
      </div>
    </div>
  );
}
