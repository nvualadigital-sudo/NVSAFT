import type { Client,Notification,Product } from "./types";
export const INITIAL_PRODUCTS: Product[] = [
  { id:1, codigo:"MED001", nome:"Paracetamol 500mg", categoria:"Medicamentos", preco:2.50, stock:520, armazem:"Armazém Principal", validade:"2026-07-20" },
  { id:2, codigo:"MED002", nome:"Amoxicilina 500mg", categoria:"Medicamentos", preco:8.90, stock:180, armazem:"Armazém 2", validade:"2027-03-15" },
  { id:3, codigo:"MED003", nome:"Ibuprofeno 400mg", categoria:"Medicamentos", preco:4.20, stock:350, armazem:"Armazém 3", validade:"2026-07-29" },
  { id:4, codigo:"MED004", nome:"Azitromicina 500mg", categoria:"Medicamentos", preco:12.50, stock:45, armazem:"Armazém Principal", validade:"2027-01-10" },
  { id:5, codigo:"SUP001", nome:"Vitamina C 1000mg", categoria:"Suplementos", preco:6.90, stock:200, armazem:"Armazém Principal", validade:"2027-06-30" },
  { id:6, codigo:"SUP002", nome:"Ómega 3", categoria:"Suplementos", preco:14.50, stock:80, armazem:"Armazém 2", validade:"2027-08-15" },
  { id:7, codigo:"HIG001", nome:"Sabão Líquido 500ml", categoria:"Higiene", preco:3.50, stock:300, armazem:"Armazém Principal", validade:"2028-01-01" },
  { id:8, codigo:"COS001", nome:"Creme Hidratante 200ml", categoria:"Cosméticos", preco:9.90, stock:150, armazem:"Armazém 2", validade:"2027-12-31" },
];

export const INITIAL_CLIENTS: Client[] = [
  { id:1, nome:"João Silva", nif:"123456789", email:"joao@email.com", telefone:"+244 923 456 789", saldo:0 },
  { id:2, nome:"Maria Santos", nif:"987654321", email:"maria@email.com", telefone:"+244 912 345 678", saldo:25.50 },
  { id:3, nome:"Pedro Costa", nif:"456789123", email:"pedro@email.com", telefone:"+244 931 234 567", saldo:0 },
  { id:4, nome:"Ana Rodrigues", nif:"789123456", email:"ana@email.com", telefone:"+244 942 345 678", saldo:12.00 },
];

export const INITIAL_NOTIFS: Notification[] = [
  { id:1, title:"Stock Baixo", desc:"Azitromicina 500mg: 45 unidades restantes", time:"10 min", read:false },
  { id:2, title:"Validade Próxima", desc:"Paracetamol 500mg vence em 9 dias", time:"30 min", read:false },
  { id:3, title:"Nova Encomenda", desc:"Encomenda #ENK-012 aprovada", time:"1h", read:true },
];

export const CATEGORIES = ["Todos", "Medicamentos", "Suplementos", "Higiene", "Cosméticos"];
