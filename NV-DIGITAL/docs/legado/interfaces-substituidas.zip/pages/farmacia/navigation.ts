import type { FPage } from "./types";
export const navSections: {label: string | null; items: {id:FPage;label:string;ico:string;badge?:string}[]}[] = [
    { label: null, items: [
      { id:"dashboard" as FPage, label:"Dashboard", ico:"chart-line" },
      { id:"prescricoes_medicas" as FPage, label:"Prescrições Médicas", ico:"prescription" },
      { id:"pos" as FPage, label:"Ponto de Venda", ico:"cash-register", badge:"Novo" },
    ]},
    { label: "Gestão", items: [
      { id:"produtos" as FPage, label:"Produtos", ico:"pills" },
      { id:"clientes" as FPage, label:"Clientes", ico:"users" },
      { id:"fornecedores" as FPage, label:"Fornecedores", ico:"industry" },
    ]},
    { label: "Logística", items: [
      { id:"armazens" as FPage, label:"Armazéns", ico:"warehouse" },
      { id:"transferencias" as FPage, label:"Transferências", ico:"exchange-alt" },
    ]},
    { label: "Financeiro", items: [
      { id:"caixa" as FPage, label:"Caixa", ico:"coins" },
      { id:"encomendas" as FPage, label:"Encomendas", ico:"box" },
      { id:"faturacao" as FPage, label:"Faturação", ico:"file-invoice" },
      { id:"relatorios" as FPage, label:"Relatórios", ico:"chart-pie" },
      { id:"comissoes" as FPage, label:"Comissões", ico:"percentage" },
    ]},
    { label: "RH", items: [
      { id:"funcionarios" as FPage, label:"Funcionários", ico:"user-tie" },
      { id:"ferias" as FPage, label:"Férias & Licenças", ico:"umbrella-beach" },
      { id:"performance" as FPage, label:"Performance", ico:"star" },
    ]},
    { label: "Vendas", items: [
      { id:"multiloja" as FPage, label:"Multi-Loja", ico:"store" },
      { id:"validade" as FPage, label:"Controlo Validade", ico:"clock" },
      { id:"avaliacoes" as FPage, label:"Avaliações", ico:"star-half-alt" },
      { id:"promocoes" as FPage, label:"Promoções", ico:"tag" },
    ]},
    { label: "CRM & Marketing", items: [
      { id:"suporte" as FPage, label:"Suporte", ico:"headset" },
      { id:"atividades" as FPage, label:"Atividades", ico:"history" },
      { id:"calendario" as FPage, label:"Calendário", ico:"calendar-alt" },
      { id:"tarefas" as FPage, label:"Tarefas", ico:"tasks" },
      { id:"marketing" as FPage, label:"Marketing", ico:"bullhorn" },
    ]},
    { label: "Documentos & Comunicação", items: [
      { id:"documentos" as FPage, label:"Documentos", ico:"folder" },
      { id:"chat" as FPage, label:"Chat Interno", ico:"comments" },
    ]},
    { label: "Sistema", items: [
      { id:"usuarios" as FPage, label:"Usuários", ico:"user-shield" },
      { id:"permissoes" as FPage, label:"Permissões", ico:"key" },
      { id:"integracoes" as FPage, label:"Integrações", ico:"plug" },
      { id:"api" as FPage, label:"API & Webhooks", ico:"code" },
      { id:"cache" as FPage, label:"Cache & Performance", ico:"bolt" },
      { id:"backup" as FPage, label:"Backup", ico:"database" },
      { id:"logs" as FPage, label:"Logs do Sistema", ico:"terminal" },
      { id:"auditoria" as FPage, label:"Auditoria", ico:"shield-alt" },
      { id:"configuracoes" as FPage, label:"Configurações", ico:"cog" },
    ]},
    { label: "Conta", items: [
      { id:"perfil" as FPage, label:"Meu Perfil", ico:"user-edit" },
    ]},
  ];
