export type FPage =
  | "prescricoes_medicas" | "dashboard" | "pos" | "multiloja" | "produtos" | "clientes" | "fornecedores"
  | "armazens" | "transferencias" | "caixa" | "encomendas" | "faturacao"
  | "relatorios" | "comissoes" | "funcionarios" | "calendario" | "ferias"
  | "performance" | "tarefas" | "marketing" | "documentos" | "chat"
  | "usuarios" | "permissoes" | "integracoes" | "api" | "cache" | "backup"
  | "logs" | "auditoria" | "suporte" | "atividades" | "configuracoes"
  | "perfil" | "validade" | "promocoes" | "avaliacoes";

export interface Product {
  id: number; codigo: string; nome: string; categoria: string;
  preco: number; stock: number; armazem: string; validade: string;
}

export interface CartItem { produto: Product; qty: number; }

export interface Client {
  id: number; nome: string; nif: string; email: string; telefone: string; saldo: number;
}

export interface Notification { id: number; title: string; desc: string; time: string; read: boolean; }
