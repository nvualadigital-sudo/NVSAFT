export type DocType='FT'|'FR'|'PF';
export interface BillingProduct {id:string;code:string;name:string;lot:string;expiry:string;price:number;tax:number;stock:number;minimum:number;warehouse:string;}
export interface BillLine {id:string;productId?:string;description:string;quantity:number;price:number;discount:number;tax:number;exemption:string;}
export interface Bill {id:string;number:string;type:DocType;status:'draft'|'issued';date:string;due:string;client:string;nif:string;address:string;phone:string;lines:BillLine[];notes:string;actor:string;created:string;sourceDeliveryId?:string;issuer?:{name:string;nif:string;address:string;currency:string};}
export interface Payment {id:string;number:string;billId:string;amount:number;method:'Dinheiro'|'Cartão'|'Transferência';kind:'receipt'|'refund';reference:string;when:string;actor:string;cashId?:string;}
export interface Credit {id:string;number:string;billId:string;reason:string;lines:BillLine[];when:string;actor:string;}
export interface CashSession {id:string;opened:string;actor:string;float:number;closed?:string;counted?:number;reason?:string;expected?:number;}
export interface StockMove {id:string;productId:string;quantity:number;reason:string;when:string;actor:string;billId?:string;}
export interface CashMove {id:string;cashId:string;amount:number;reason:string;when:string;actor:string;}
export interface BillingState {version:1;revision:number;sequence:number;products:BillingProduct[];bills:Bill[];payments:Payment[];credits:Credit[];cash:CashSession[];stockMoves:StockMove[];cashMoves:CashMove[];config:{name:string;nif:string;address:string;currency:string};audit:{id:string;when:string;actor:string;action:string;ref:string}[];}
export const units=(v:number)=>Math.round((v+Number.EPSILON)*1000)/1000;
export const money=(v:number)=>Math.round((v+Number.EPSILON)*100)/100;
export function lineTotals(l:BillLine){const base=money(l.quantity*l.price*(1-l.discount/100));const tax=money(base*l.tax/100);return {base,tax,total:money(base+tax)};}
export function totals(lines:BillLine[]){return lines.reduce((s,l)=>{const t=lineTotals(l);return {base:money(s.base+t.base),tax:money(s.tax+t.tax),total:money(s.total+t.total)};},{base:0,tax:0,total:0});}
export function creditsTotal(s:BillingState,id:string){return money(s.credits.filter(c=>c.billId===id).reduce((n,c)=>n+totals(c.lines).total,0));}
export function paid(s:BillingState,id:string){return money(s.payments.filter(p=>p.billId===id).reduce((n,p)=>n+(p.kind==='refund'?-p.amount:p.amount),0));}
export function balance(s:BillingState,b:Bill){return money(totals(b.lines).total-creditsTotal(s,b.id)-paid(s,b.id));}
export function cashExpected(s:BillingState,c:CashSession){return money(c.float+s.payments.filter(p=>p.cashId===c.id).reduce((n,p)=>n+(p.kind==='refund'?-p.amount:p.amount),0)+s.cashMoves.filter(m=>m.cashId===c.id).reduce((n,m)=>n+m.amount,0));}
export function dateLocal(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
export function validDate(v:string){if(!/^\d{4}-\d{2}-\d{2}$/.test(v))return false;const [y,m,d]=v.split('-').map(Number);const test=new Date(y,m-1,d);return test.getFullYear()===y&&test.getMonth()===m-1&&test.getDate()===d;}
export function formatMoney(s:BillingState,n:number){return `${n.toLocaleString('pt-PT',{minimumFractionDigits:2,maximumFractionDigits:2})} ${s.config.currency}`;}
export function emptyBilling():BillingState{return {version:1,revision:0,sequence:0,products:[],bills:[],payments:[],credits:[],cash:[],stockMoves:[],cashMoves:[],config:{name:'',nif:'',address:'',currency:'Kz'},audit:[]};}
