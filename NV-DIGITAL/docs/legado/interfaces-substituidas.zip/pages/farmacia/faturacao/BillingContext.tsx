import { createContext,useContext,useState } from 'react';
import type { BillingState } from './model';
import { useBilling } from './store';
export interface BillingContextValue {state:BillingState;org:string;actor:string;message:string;setMessage:(s:string)=>void;run:(fn:()=>unknown,success?:string)=>boolean;}
export const BillingContext=createContext<BillingContextValue|null>(null);
export function useBillingContext(){const value=useContext(BillingContext);if(!value)throw new Error('Facturação fora do contexto.');return value;}
export function BillingProvider({org,actor,children}:{org:string;actor:string;children:React.ReactNode}){const {state,error}=useBilling(org);const [message,setMessage]=useState('');function run(fn:()=>unknown,success='Operação guardada neste navegador.'){try{fn();setMessage(success);return true;}catch(e){setMessage(e instanceof Error?e.message:'Não foi possível completar a operação.');return false;}}return <BillingContext.Provider value={{state,org,actor,message:error||message,setMessage,run}}>{children}</BillingContext.Provider>;}
