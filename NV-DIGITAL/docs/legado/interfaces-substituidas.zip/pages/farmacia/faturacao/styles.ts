export const BILLING_CSS=`
#farm-wrapper .farm-billing{padding:4px;color:inherit;min-width:0}
#farm-wrapper .farm-billing .farm-card{padding:20px;margin-top:14px}
#farm-wrapper .farm-billing .farm-card-hdr{padding-bottom:14px;margin-bottom:14px;gap:12px;flex-wrap:wrap}
#farm-wrapper .farm-billing .billing-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px;margin:16px 0}
#farm-wrapper .farm-billing label{display:flex;flex-direction:column;gap:7px;font-size:13px;margin:10px 0;min-width:0}
#farm-wrapper .farm-billing input:not([type=checkbox]),#farm-wrapper .farm-billing select,#farm-wrapper .farm-billing textarea{width:100%;border:1px solid var(--fgb);background:var(--fg);color:inherit;border-radius:8px;padding:10px;font:inherit;min-width:0}
#farm-wrapper .farm-billing select option{color:#172033;background:#fff}
#farm-wrapper .farm-billing textarea{min-height:84px}
#farm-wrapper .farm-billing .billing-actions{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0}
#farm-wrapper .farm-billing .billing-summary{padding:16px;border:1px solid var(--fgb);border-radius:10px;margin:15px 0;line-height:1.8;background:var(--fg)}
#farm-wrapper .farm-billing .billing-check{flex-direction:row;align-items:flex-start;gap:10px}
#farm-wrapper .farm-billing h4{margin:20px 0 10px}
#farm-wrapper .farm-billing p{line-height:1.65;overflow-wrap:anywhere}
#farm-wrapper .farm-billing details{margin:18px 0;padding:14px;border:1px solid var(--fgb);border-radius:8px}
#farm-wrapper .farm-billing summary{cursor:pointer;font-weight:600}
#farm-wrapper .farm-billing .billing-notice{padding:12px;border:1px solid #d4a453;background:rgba(255,188,0,.1);border-radius:8px;font-size:12px;line-height:1.7}
#farm-wrapper .farm-billing .billing-active{box-shadow:inset 0 -3px 0 var(--fp)}
#farm-wrapper .farm-billing .farm-invoice-item{gap:14px;flex-wrap:wrap;padding:14px 0}
#farm-wrapper .farm-billing button:disabled{opacity:.45;cursor:not-allowed}
`;
