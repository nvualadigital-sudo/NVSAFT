import { useFarmaciaContext } from "./FarmaciaContext";
import Api from "./pages/Api";
import Armazens from "./pages/Armazens";
import Atividades from "./pages/Atividades";
import Auditoria from "./pages/Auditoria";
import Avaliacoes from "./pages/Avaliacoes";
import Backup from "./pages/Backup";
import Cache from "./pages/Cache";
import Calendario from "./pages/Calendario";
import Chat from "./pages/Chat";
import Clientes from "./pages/Clientes";
import Comissoes from "./pages/Comissoes";
import Configuracoes from "./pages/Configuracoes";
import Dashboard from "./pages/Dashboard";
import Documentos from "./pages/Documentos";
import Encomendas from "./pages/Encomendas";
import Faturacao from "./pages/Faturacao";
import Ferias from "./pages/Ferias";
import Fornecedores from "./pages/Fornecedores";
import Funcionarios from "./pages/Funcionarios";
import Integracoes from "./pages/Integracoes";
import Logs from "./pages/Logs";
import Marketing from "./pages/Marketing";
import Multiloja from "./pages/Multiloja";
import Perfil from "./pages/Perfil";
import Performance from "./pages/Performance";
import Permissoes from "./pages/Permissoes";
import PrescricoesMedicas from "./pages/PrescricoesMedicas";
import Promocoes from "./pages/Promocoes";
import Relatorios from "./pages/Relatorios";
import Suporte from "./pages/Suporte";
import Tarefas from "./pages/Tarefas";
import Transferencias from "./pages/Transferencias";
import Usuarios from "./pages/Usuarios";
import Validade from "./pages/Validade";
const pages={prescricoes_medicas:PrescricoesMedicas,dashboard:Dashboard,pos:BillingPOS,produtos:BillingStock,clientes:Clientes,multiloja:Multiloja,comissoes:Comissoes,avaliacoes:Avaliacoes,validade:Validade,ferias:Ferias,tarefas:Tarefas,marketing:Marketing,api:Api,cache:Cache,logs:Logs,auditoria:Auditoria,backup:Backup,integracoes:Integracoes,suporte:Suporte,atividades:Atividades,usuarios:Usuarios,permissoes:Permissoes,configuracoes:Configuracoes,perfil:Perfil,relatorios:Relatorios,faturacao:Faturacao,caixa:BillingCash,funcionarios:Funcionarios,fornecedores:Fornecedores,armazens:Armazens,transferencias:Transferencias,encomendas:Encomendas,performance:Performance,calendario:Calendario,promocoes:Promocoes,documentos:Documentos,chat:Chat};
export default function FarmaciaRouter(){const {activePage}=useFarmaciaContext();const Page=pages[activePage];return <Page />;}

function BillingPOS(){return <Faturacao initialTab="pos" />;}
function BillingStock(){return <Faturacao initialTab="stock" />;}
function BillingCash(){return <Faturacao initialTab="caixa" />;}
