import { useFarmaciaContext } from "../FarmaciaContext";
export default function FarmaciaNotificacoes(){
const {showNotifs,notifs,setNotifs}=useFarmaciaContext();
return <>
{/* NOTIFICATIONS DROPDOWN */}
      {showNotifs && (
        <div className="farm-notif-dropdown" onClick={e=>e.stopPropagation()}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12,paddingBottom:10,borderBottom:"1px solid var(--fgb)"}}>
            <strong>Notificações</strong>
            <button className="fbtn fbtn-p fbtn-sm" onClick={()=>setNotifs(prev=>prev.map(n=>({...n,read:true})))}>Marcar todas</button>
          </div>
          {notifs.map(n=>(
            <div key={n.id} className={`farm-notif-item${!n.read?" unread":""}`} onClick={()=>setNotifs(prev=>prev.map(x=>x.id===n.id?{...x,read:true}:x))}>
              <div style={{fontWeight:600,fontSize:".85rem",marginBottom:3}}>{n.title}</div>
              <div style={{fontSize:".78rem",opacity:.75}}>{n.desc}</div>
              <div style={{fontSize:".68rem",opacity:.5,marginTop:4}}>{n.time} atrás</div>
            </div>
          ))}
        </div>
      )}

      
</>;
}
