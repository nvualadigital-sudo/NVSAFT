import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function FarmaciaProdutoModal(){
const {showProdModal,setShowProdModal,pf,setPf,saveProd}=useFarmaciaContext();
return <>
{/* PRODUCT MODAL */}
      <div className={`farm-modal${showProdModal?" open":""}`} onClick={()=>setShowProdModal(false)}>
        <div className="farm-modal-box" onClick={e=>e.stopPropagation()}>
          <div className="farm-modal-hdr">
            <h3><Ico name="pills" /> Novo Produto</h3>
            <button className="farm-modal-close" onClick={()=>setShowProdModal(false)}>✕</button>
          </div>
          <form onSubmit={saveProd}>
            <div className="farm-form-row">
              <div className="farm-form-group"><label className="farm-form-label">Código</label><input className="farm-form-control" required value={pf.codigo} onChange={e=>setPf(p=>({...p,codigo:e.target.value}))} /></div>
              <div className="farm-form-group"><label className="farm-form-label">Nome</label><input className="farm-form-control" required value={pf.nome} onChange={e=>setPf(p=>({...p,nome:e.target.value}))} /></div>
            </div>
            <div className="farm-form-row">
              <div className="farm-form-group"><label className="farm-form-label">Categoria</label>
                <select className="farm-form-control" value={pf.categoria} onChange={e=>setPf(p=>({...p,categoria:e.target.value}))}>
                  <option>Medicamentos</option><option>Suplementos</option><option>Higiene</option><option>Cosméticos</option>
                </select>
              </div>
              <div className="farm-form-group"><label className="farm-form-label">Preço (€)</label><input className="farm-form-control" type="number" step="0.01" required value={pf.preco} onChange={e=>setPf(p=>({...p,preco:e.target.value}))} /></div>
            </div>
            <div className="farm-form-row">
              <div className="farm-form-group"><label className="farm-form-label">Stock</label><input className="farm-form-control" type="number" required value={pf.stock} onChange={e=>setPf(p=>({...p,stock:e.target.value}))} /></div>
              <div className="farm-form-group"><label className="farm-form-label">Armazém</label>
                <select className="farm-form-control" value={pf.armazem} onChange={e=>setPf(p=>({...p,armazem:e.target.value}))}>
                  <option>Armazém Principal</option><option>Armazém 2</option><option>Armazém 3</option>
                </select>
              </div>
            </div>
            <div className="farm-form-group"><label className="farm-form-label">Data de Validade</label><input className="farm-form-control" type="date" value={pf.validade} onChange={e=>setPf(p=>({...p,validade:e.target.value}))} /></div>
            <button type="submit" className="fbtn fbtn-p"><Ico name="save" /> Guardar</button>
          </form>
        </div>
      </div>

      
</>;
}
