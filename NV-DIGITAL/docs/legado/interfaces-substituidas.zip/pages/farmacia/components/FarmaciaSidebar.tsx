import { useFarmaciaContext } from "../FarmaciaContext";
import { navSections } from "../navigation";
import { Ico } from "../shared";
export default function FarmaciaSidebar(){
const {activePage,nav}=useFarmaciaContext();
return <nav className="farm-sidebar">
          <div className="farm-sidebar-hdr">
            <h3><Ico name="cube" style={{color:"var(--fp)"}} /> NVUALASOFT</h3>
            <p>Sistema de Gestão Integrada</p>
          </div>
          <ul className="farm-nav">
            {navSections.map((sec, si) => (
              <li key={si}>
                {sec.label && <div className="farm-nav-sec">{sec.label}</div>}
                {sec.items.map(item => (
                  <div key={item.id} className={`farm-nav-item${activePage===item.id?" active":""}`} onClick={()=>nav(item.id)}>
                    <span className="farm-nav-ico"><Ico name={item.ico} /></span>
                    {item.label}
                    {item.badge && <span className="farm-nav-badge">{item.badge}</span>}
                  </div>
                ))}
              </li>
            ))}
          </ul>
        </nav>;
}
