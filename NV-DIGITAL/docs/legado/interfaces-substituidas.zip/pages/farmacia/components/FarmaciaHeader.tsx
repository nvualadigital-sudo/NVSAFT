import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function FarmaciaHeader(){
const {clock,lightMode,setLightMode,setShowNotifs,search,setSearch,unreadCount,nav}=useFarmaciaContext();
return <>
{/* HEADER */}
      <header className="farm-hdr">
        <div className="farm-logo">
          <div className="farm-logo-icon">N</div>
          <div className="farm-logo-text"><h2>NVUALASOFT</h2><p>Enterprise v9.0</p></div>
        </div>
        <div className="farm-search">
          <input placeholder="Pesquisar..." value={search} onChange={e=>setSearch(e.target.value)} />
          <span className="farm-search-ico">🔍</span>
        </div>
        <div className="farm-hdr-right">
          <div className="farm-clock"><Ico name="clock" /> {clock}</div>
          <div className="farm-status"><span className="farm-dot" />Online</div>
          <button className="farm-hdr-btn" title="Tema" onClick={()=>setLightMode(v=>!v)}>
            <Ico name={lightMode?"sun":"moon"} />
          </button>
          <button className="farm-hdr-btn" title="Notificações" onClick={e=>{e.stopPropagation();setShowNotifs(v=>!v);}}>
            <Ico name="bell" />
            {unreadCount > 0 && <span className="farm-notif-dot" />}
          </button>
          <div className="farm-user" onClick={()=>nav("perfil")}>
            <div className="farm-user-av">AD</div>
            <div className="farm-user-info"><div>Administrador</div><div>admin@nvualasoft.com</div></div>
          </div>
        </div>
      </header>

      
</>;
}
