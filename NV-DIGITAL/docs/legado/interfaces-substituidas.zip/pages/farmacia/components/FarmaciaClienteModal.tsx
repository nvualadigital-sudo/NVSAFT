import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function FarmaciaClienteModal(){
const {showClientModal,setShowClientModal,cf,setCf,saveClient}=useFarmaciaContext();
return <>
{/* CLIENT MODAL */}
      <div className={`farm-modal${showClientModal?" open":""}`} onClick={()=>setShowClientModal(false)}>
        <div className="farm-modal-box" onClick={e=>e.stopPropagation()}>
          <div className="farm-modal-hdr">
            <h3><Ico name="user-plus" /> Novo Cliente</h3>
            <button className="farm-modal-close" onClick={()=>setShowClientModal(false)}>✕</button>
          </div>
          <form onSubmit={saveClient}>
            <div className="farm-form-row">
              <div className="farm-form-group"><label className="farm-form-label">Nome</label><input className="farm-form-control" required value={cf.nome} onChange={e=>setCf(c=>({...c,nome:e.target.value}))} /></div>
              <div className="farm-form-group"><label className="farm-form-label">NIF</label><input className="farm-form-control" required value={cf.nif} onChange={e=>setCf(c=>({...c,nif:e.target.value}))} /></div>
            </div>
            <div className="farm-form-row">
              <div className="farm-form-group"><label className="farm-form-label">Email</label><input className="farm-form-control" type="email" value={cf.email} onChange={e=>setCf(c=>({...c,email:e.target.value}))} /></div>
              <div className="farm-form-group"><label className="farm-form-label">Telefone</label><input className="farm-form-control" value={cf.telefone} onChange={e=>setCf(c=>({...c,telefone:e.target.value}))} /></div>
            </div>
            <button type="submit" className="fbtn fbtn-p"><Ico name="save" /> Guardar</button>
          </form>
        </div>
      </div>

      
</>;
}
