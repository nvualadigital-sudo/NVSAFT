import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Documentos(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="folder" /> Documentos</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Upload — em desenvolvimento")}><Ico name="upload" /> Upload</button></div>
            <div className="farm-doc-grid">
              {[["file-pdf","Relatório Mensal.pdf","2.4 MB"],["file-excel","Inventário.xlsx","1.8 MB"],["file-word","Contrato.docx","856 KB"],["file-image","Logo.png","245 KB"],["file-pdf","Fatura_001.pdf","128 KB"],["file-excel","Funcionarios.xlsx","512 KB"]].map(([ico,n,s])=>(
                <div key={n} className="farm-doc-card" onClick={()=>showToast("Abrir: "+n)}>
                  <div className="farm-doc-ico"><Ico name={ico} /></div>
                  <div className="farm-doc-name">{n}</div>
                  <div className="farm-doc-size">{s}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      );
}
