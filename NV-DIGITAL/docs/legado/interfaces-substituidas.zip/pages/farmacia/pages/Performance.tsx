import { Ico } from "../shared";
export default function Performance(){
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="star" /> Performance da Equipa</h3></div>
            {[{n:"Carlos Mendes",score:"9.2",vendas:"€13.000",atend:"98%",pontual:"95%"},
              {n:"Ana Rodrigues",score:"8.7",vendas:"€9.600",atend:"96%",pontual:"100%"},
              {n:"Rui Ferreira",score:"7.9",vendas:"—",atend:"94%",pontual:"88%"}].map(e=>(
              <div key={e.n} className="farm-perf-card">
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
                  <h4 style={{fontWeight:600}}>{e.n}</h4>
                  <div className="farm-perf-score">{e.score}/10</div>
                </div>
                <div className="farm-perf-metrics">
                  {[["Vendas",e.vendas],["Atendimento",e.atend],["Pontualidade",e.pontual]].map(([l,v])=>(
                    <div key={l} className="farm-perf-metric"><div className="farm-perf-metric-val">{v}</div><div className="farm-perf-metric-lbl">{l}</div></div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      );
}
