import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Suporte(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="headset" /> Suporte</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Novo ticket aberto")}><Ico name="plus" /> Novo Ticket</button></div>
            {[["Erro ao imprimir fatura","#TK-001 | 10/07/2026","priority-high","Alta"],
              ["Dúvida sobre relatórios","#TK-002 | 09/07/2026","priority-medium","Média"],
              ["Solicitação de novo usuário","#TK-003 | 08/07/2026","priority-low","Baixa"]].map(([h,d,cls,p])=>(
              <div key={h} className="farm-ticket-item">
                <div><h4 style={{fontWeight:600,marginBottom:4}}>{h}</h4><p style={{fontSize:".8rem",opacity:.65}}>{d}</p></div>
                <span className={`fbadge ${cls==="priority-high"?"fbadge-d":cls==="priority-medium"?"fbadge-w":"fbadge-s"}`}>{p}</span>
              </div>
            ))}
          </div>
        </div>
      );
}
