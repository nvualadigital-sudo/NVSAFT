import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Promocoes(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="tag" /> Promoções Ativas</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Nova promoção — em desenvolvimento")}><Ico name="plus" /> Nova</button></div>
            <div className="farm-promo-card">
              <div className="farm-promo-title">🎉 Promoção de Verão</div>
              <div className="farm-promo-desc">20% de desconto em todos os suplementos vitamínicos</div>
              <div className="farm-promo-code">Código: VERAO2026</div>
            </div>
            <div className="farm-promo-card" style={{background:"linear-gradient(135deg,#0acf97,#089970)"}}>
              <div className="farm-promo-title">🛒 Compra 2 Leva 3</div>
              <div className="farm-promo-desc">Em medicamentos selecionados da categoria analgésicos</div>
              <div className="farm-promo-code">Código: 2LEVA3</div>
            </div>
            <div className="farm-promo-card" style={{background:"linear-gradient(135deg,#ffbc00,#e5a800)",color:"#333"}}>
              <div className="farm-promo-title">🎁 Primeira Compra</div>
              <div className="farm-promo-desc">10% de desconto para novos clientes</div>
              <div className="farm-promo-code" style={{background:"rgba(0,0,0,.15)"}}>Código: NOVO10</div>
            </div>
          </div>
        </div>
      );
}
