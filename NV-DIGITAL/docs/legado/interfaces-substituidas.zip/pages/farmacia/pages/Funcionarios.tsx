import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Funcionarios(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="user-tie" /> Funcionários</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Novo funcionário — em desenvolvimento")}><Ico name="plus" /> Novo</button></div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:12}}>
              {[{n:"Carlos Mendes",r:"Vendedor",s:"€1.200",bg:"linear-gradient(135deg,#ff6b6b,#ee5a6f)"},
                {n:"Ana Rodrigues",r:"Caixa",s:"€950",bg:"linear-gradient(135deg,#4ecdc4,#44a08d)"},
                {n:"Rui Ferreira",r:"Armazém",s:"€900",bg:"linear-gradient(135deg,#ffa726,#fb8c00)"},
                {n:"Sofia Almeida",r:"Caixa",s:"€950",bg:"linear-gradient(135deg,#7e57c2,#5e35b1)"}].map(e=>(
                <div key={e.n} className="farm-employee-card">
                  <div className="farm-emp-av" style={{background:e.bg}}>{e.n.split(" ").map(x=>x[0]).join("")}</div>
                  <div className="farm-emp-name">{e.n}</div>
                  <div className="farm-emp-role">{e.r}</div>
                  <div className="farm-emp-sal">{e.s}/mês</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      );
}
