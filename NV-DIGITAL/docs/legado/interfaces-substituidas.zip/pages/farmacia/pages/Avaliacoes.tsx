import { Ico } from "../shared";
export default function Avaliacoes(){
return (
        <div className="farm-page">
          <div className="farm-stats">
            <div className="farm-stat s"><div className="farm-stat-label">Avaliação Média</div><div className="farm-stat-value">4.7/5</div></div>
            <div className="farm-stat i"><div className="farm-stat-label">Total</div><div className="farm-stat-value">156</div></div>
            <div className="farm-stat w"><div className="farm-stat-label">5 Estrelas</div><div className="farm-stat-value">89</div></div>
            <div className="farm-stat d"><div className="farm-stat-label">1 Estrela</div><div className="farm-stat-value">3</div></div>
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="star" /> Avaliações Recentes</h3></div>
            {[{autor:"João Silva",stars:5,text:"Excelente atendimento! Produto de qualidade e entrega rápida. Recomendo!",data:"10 Julho 2026"},
              {autor:"Maria Santos",stars:4,text:"Bom produto, mas o atendimento poderia ser mais rápido.",data:"9 Julho 2026"},
              {autor:"Pedro Costa",stars:5,text:"Perfeito! Voltarei a comprar com certeza.",data:"8 Julho 2026"}].map(r=>(
              <div key={r.autor} className="farm-review-card">
                <div className="farm-review-hdr">
                  <strong>{r.autor}</strong>
                  <span style={{color:"var(--fw)"}}>{"★".repeat(r.stars)}{"☆".repeat(5-r.stars)}</span>
                </div>
                <p style={{fontSize:".85rem",opacity:.9,marginBottom:8}}>{r.text}</p>
                <div style={{fontSize:".75rem",opacity:.55}}><Ico name="clock" /> {r.data}</div>
              </div>
            ))}
          </div>
        </div>
      );
}
