import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Cache(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="bolt" /> Cache & Performance</h3><button className="fbtn fbtn-w" onClick={()=>showToast("Cache limpo com sucesso")}><Ico name="broom" /> Limpar Cache</button></div>
            {[["Cache de Dados","Última atualização: 5 min atrás","245 MB"],["Cache de Sessão","Sessões ativas: 12","18 MB"],["Cache de Consultas","Taxa de acerto: 94%","156 MB"],["Tempo Médio Resposta","Últimas 24 horas","45ms"]].map(([n,d,v])=>(
              <div key={n} className="farm-cache-stat">
                <div><h4 style={{fontWeight:600,marginBottom:4}}>{n}</h4><p style={{fontSize:".8rem",opacity:.65}}>{d}</p></div>
                <div className="farm-cache-val">{v}</div>
              </div>
            ))}
          </div>
        </div>
      );
}
