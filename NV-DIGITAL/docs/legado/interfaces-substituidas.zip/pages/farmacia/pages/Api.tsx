import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Api(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="code" /> API REST</h3><button className="fbtn fbtn-i" onClick={()=>showToast("Token gerado: Bearer fa9d2...")}><Ico name="key" /> Gerar Token</button></div>
            {[["get","/api/v1/produtos"],["get","/api/v1/clientes"],["post","/api/v1/vendas"],["put","/api/v1/produtos/:id"],["delete","/api/v1/produtos/:id"]].map(([m,path])=>(
              <div key={m+path} className="farm-api-endpoint">
                <div><span className={`farm-api-method ${m==="delete"?"del":m}`}>{m.toUpperCase()}</span><span className="farm-api-path">{path}</span></div>
                <span className="fbadge fbadge-s">Ativo</span>
              </div>
            ))}
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="plug" /> Webhooks</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Novo webhook — em desenvolvimento")}><Ico name="plus" /> Novo</button></div>
            {[["Venda Criada","https://seusistema.com/webhook/venda"],["Stock Baixo","https://seusistema.com/webhook/stock"]].map(([n,u])=>(
              <div key={n} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"12px",background:"rgba(255,255,255,.04)",borderRadius:10,border:"1px solid var(--fgb)",marginBottom:8}}>
                <div><h4 style={{marginBottom:4}}>{n}</h4><p style={{fontSize:".78rem",opacity:.65,fontFamily:"monospace"}}>{u}</p></div>
                <span className="fbadge fbadge-s">Ativo</span>
              </div>
            ))}
          </div>
        </div>
      );
}
