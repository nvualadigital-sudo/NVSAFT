import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Marketing(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-stats">
            <div className="farm-stat s"><div className="farm-stat-label">Campanhas Ativas</div><div className="farm-stat-value">3</div></div>
            <div className="farm-stat i"><div className="farm-stat-label">Emails Enviados</div><div className="farm-stat-value">2.450</div></div>
            <div className="farm-stat w"><div className="farm-stat-label">Taxa Abertura</div><div className="farm-stat-value">68%</div></div>
            <div className="farm-stat d"><div className="farm-stat-label">Conversões</div><div className="farm-stat-value">156</div></div>
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="bullhorn" /> Campanhas</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Nova campanha — em desenvolvimento")}><Ico name="plus" /> Nova Campanha</button></div>
            {[{name:"🌞 Promoção de Verão 2026",status:"Ativa",enviados:"1.200",abertos:"816",cliques:"98",conv:"45"},
              {name:"📧 Newsletter Mensal",status:"Ativa",enviados:"850",abertos:"578",cliques:"67",conv:"34"}].map(c=>(
              <div key={c.name} className="farm-comm-card">
                <div className="farm-comm-hdr"><div style={{fontWeight:700}}>{c.name}</div><span className="fbadge fbadge-s">{c.status}</span></div>
                <div className="farm-comm-stats">
                  {[["Enviados",c.enviados],["Abertos",c.abertos],["Cliques",c.cliques],["Conversões",c.conv]].map(([l,v])=>(
                    <div key={l} className="farm-comm-stat"><div className="farm-comm-stat-val">{v}</div><div className="farm-comm-stat-lbl">{l}</div></div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      );
}
