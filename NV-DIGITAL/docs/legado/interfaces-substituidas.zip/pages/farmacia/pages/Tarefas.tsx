import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Tarefas(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="tasks" /> Tarefas</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Nova tarefa — em desenvolvimento")}><Ico name="plus" /> Nova Tarefa</button></div>
            {[{title:"Reunião de equipa semanal",info:"Atribuído a: Todos | Prioridade: Alta",due:"14 Jul 2026",cls:""},
              {title:"Inventário mensal",info:"Atribuído a: Carlos Mendes | Prioridade: Alta",due:"15 Jul 2026",cls:"hp"},
              {title:"Atualizar preços de produtos",info:"Atribuído a: Ana Rodrigues | Prioridade: Média",due:"18 Jul 2026",cls:""},
              {title:"Backup semanal",info:"Atribuído a: Sistema | Prioridade: Baixa",due:"Concluída",cls:"done"}].map(t=>(
              <div key={t.title} className={`farm-task-item ${t.cls}`}>
                <div><h4 style={{fontWeight:600,marginBottom:4}}>{t.title}</h4><p style={{fontSize:".8rem",opacity:.65}}>{t.info}</p></div>
                <div className="farm-task-due"><Ico name={t.cls==="done"?"check":"clock"} /> {t.due}</div>
              </div>
            ))}
          </div>
        </div>
      );
}
