import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Clientes(){
const {clients,search,setSearch,setShowClientModal,showToast,deleteClient}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr">
              <h3 className="farm-card-title"><Ico name="users" /> Clientes</h3>
              <button className="fbtn fbtn-p" onClick={()=>setShowClientModal(true)}><Ico name="user-plus" /> Novo Cliente</button>
            </div>
            <div className="farm-search-box">
              <input placeholder="Pesquisar clientes..." value={search} onChange={e=>setSearch(e.target.value)} />
            </div>
            <div className="farm-table-wrap">
              <table className="farm-tbl">
                <thead><tr><th>Nome</th><th>NIF</th><th>Email</th><th>Telefone</th><th>Saldo</th><th>Ações</th></tr></thead>
                <tbody>
                  {clients.filter(c=>!search||c.nome.toLowerCase().includes(search.toLowerCase())).map(c=>(
                    <tr key={c.id}>
                      <td style={{fontWeight:600}}>{c.nome}</td>
                      <td><code>{c.nif}</code></td>
                      <td>{c.email}</td>
                      <td>{c.telefone}</td>
                      <td><span style={{color:c.saldo>0?"var(--fw)":"var(--fs)"}}>{c.saldo>0?`€${c.saldo.toFixed(2)} (pendente)`:"—"}</span></td>
                      <td>
                        <button className="fbtn fbtn-i fbtn-sm" style={{marginRight:4}} onClick={()=>showToast("Editar: "+c.nome)}><Ico name="edit" /></button>
                        <button className="fbtn fbtn-d fbtn-sm" onClick={()=>deleteClient(c.id)}><Ico name="trash" /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      );
}
