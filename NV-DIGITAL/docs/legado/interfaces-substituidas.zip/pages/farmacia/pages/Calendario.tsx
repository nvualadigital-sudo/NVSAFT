import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Calendario(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr">
              <h3 className="farm-card-title"><Ico name="calendar-alt" /> Calendário — Julho 2026</h3>
              <div style={{display:"flex",gap:6}}>
                <button className="fbtn fbtn-p fbtn-sm"><Ico name="chevron-left" /></button>
                <button className="fbtn fbtn-p fbtn-sm"><Ico name="chevron-right" /></button>
              </div>
            </div>
            <div className="farm-calendar-grid">
              {["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"].map(d=><div key={d} className="farm-cal-day-hdr">{d}</div>)}
              {Array.from({length:31},((_,i)=>{
                const d = i+1;
                const today = d===25;
                const hasEvent = [14,15,20].includes(d);
                return (
                  <div key={d} className={`farm-cal-day${today?" today":""}${hasEvent?" has-event":""}`} onClick={()=>showToast(`Dia ${d} de Julho 2026`)}>
                    <div className="farm-cal-day-num">{d}</div>
                    {d===14&&<div className="farm-cal-event">Reunião</div>}
                    {d===15&&<div className="farm-cal-event">Entrega</div>}
                    {d===20&&<div className="farm-cal-event">Validade</div>}
                  </div>
                );
              }))}
            </div>
          </div>
        </div>
      );
}
