import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Encomendas(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="box" /> Encomendas</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Nova encomenda — em desenvolvimento")}><Ico name="plus" /> Nova</button></div>
            <div className="farm-table-wrap">
              <table className="farm-tbl">
                <thead><tr><th>Ref.</th><th>Fornecedor</th><th>Produtos</th><th>Valor</th><th>Data Entrega</th><th>Estado</th></tr></thead>
                <tbody>
                  {[["ENK-012","Pfizer Angola",5,"€1.250,00","15/07/2026","Aprovada"],
                    ["ENK-011","Bayer Portugal",3,"€780,00","12/07/2026","Em Trânsito"],
                    ["ENK-010","Roche Lda",8,"€2.100,00","10/07/2026","Entregue"]].map(([r,f,p,v,d,s])=>(
                    <tr key={r}><td><code>{r}</code></td><td>{f}</td><td>{p}</td><td style={{fontWeight:600}}>{v}</td><td>{d}</td>
                      <td><span className={`fbadge ${s==="Entregue"?"fbadge-s":s==="Em Trânsito"?"fbadge-i":"fbadge-w"}`}>{s}</span></td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      );
}
