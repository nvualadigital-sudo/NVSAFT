import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Logs(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="terminal" /> Logs do Sistema</h3><button className="fbtn fbtn-i" onClick={()=>showToast("Logs exportados")}><Ico name="download" /> Exportar</button></div>
            {[["2026-07-11 11:45:23","info","Venda #003 finalizada com sucesso — Total: €89,90"],
              ["2026-07-11 11:30:15","warn","Stock baixo: Azitromicina 500mg (45 unidades)"],
              ["2026-07-11 11:15:42","info","Backup automático iniciado"],
              ["2026-07-11 10:45:18","error","Falha ao conectar com API de pagamentos — Timeout"],
              ["2026-07-11 10:30:05","info","Utilizador admin@nvualasoft.com fez login"]].map(([t,l,m])=>(
              <div key={t} className="farm-log-item">
                <span className="farm-log-time">{t}</span>
                <span className={`farm-log-level ${l}`}>{l.toUpperCase()}</span>
                <span>{m}</span>
              </div>
            ))}
          </div>
        </div>
      );
}
