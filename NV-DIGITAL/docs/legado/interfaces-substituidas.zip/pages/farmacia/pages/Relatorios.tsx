import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Relatorios(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-stats">
            <div className="farm-stat s"><div className="farm-stat-label">Receita Total</div><div className="farm-stat-value">€18.450</div></div>
            <div className="farm-stat i"><div className="farm-stat-label">Total Vendas</div><div className="farm-stat-value">1.247</div></div>
            <div className="farm-stat w"><div className="farm-stat-label">Ticket Médio</div><div className="farm-stat-value">€14.80</div></div>
            <div className="farm-stat d"><div className="farm-stat-label">Devoluções</div><div className="farm-stat-value">23</div></div>
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="chart-bar" /> Vendas por Categoria</h3>
              <button className="fbtn fbtn-i fbtn-sm" onClick={()=>showToast("Relatório exportado")}><Ico name="download" /> Exportar</button>
            </div>
            <div className="farm-chart-placeholder">📊 Gráfico de barras por categoria</div>
            <div style={{marginTop:16}}>
              {[["Medicamentos",62],["Suplementos",18],["Higiene",12],["Cosméticos",8]].map(([cat,pct])=>(
                <div key={cat} style={{marginBottom:10}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:4,fontSize:".85rem"}}>
                    <span>{cat}</span><span style={{fontWeight:600}}>{pct}%</span>
                  </div>
                  <div className="farm-progress-bar"><div className="farm-progress-fill" style={{width:`${pct}%`}} /></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      );
}
