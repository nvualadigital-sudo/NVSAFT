import { CATEGORIES } from "../data";
import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico,PRODUCT_ICONS } from "../shared";
export default function PontoVenda(){
const {cart,setCart,posCategory,setPosCategory,posSearch,setPosSearch,posProducts,addToCart,changeQty,cartSubtotal,cartIVA,cartTotal,checkout}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-pos">
            <div className="farm-pos-products">
              <h3 style={{marginBottom:12,fontWeight:700}}><Ico name="pills" /> Produtos</h3>
              <div className="farm-search-box">
                <input placeholder="Pesquisar produto..." value={posSearch} onChange={e=>setPosSearch(e.target.value)} />
              </div>
              <div className="farm-cat-filter">
                {CATEGORIES.map(c=>(
                  <button key={c} className={`farm-cat-btn${posCategory===c?" active":""}`} onClick={()=>setPosCategory(c)}>{c}</button>
                ))}
              </div>
              <div className="farm-product-grid">
                {posProducts.map(p=>(
                  <div key={p.id} className="farm-product-card" onClick={()=>addToCart(p)}>
                    <span className="farm-product-ico">{PRODUCT_ICONS[p.categoria] || "📦"}</span>
                    <div className="farm-product-name">{p.nome}</div>
                    <div className="farm-product-price">€{p.preco.toFixed(2)}</div>
                    <div className="farm-product-stock">Stock: {p.stock}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="farm-pos-cart">
              <h3 style={{marginBottom:16,fontWeight:700}}><Ico name="shopping-cart" /> Carrinho</h3>
              <div className="farm-cart-items">
                {cart.length===0
                  ? <div style={{textAlign:"center",padding:"40px 0",opacity:.5}}><Ico name="cart-plus" /><br/>Carrinho vazio</div>
                  : cart.map(item=>(
                    <div key={item.produto.id} className="farm-cart-item">
                      <div className="farm-cart-item-info">
                        <div className="farm-cart-item-name">{item.produto.nome}</div>
                        <div className="farm-cart-item-price">€{item.produto.preco.toFixed(2)} × {item.qty}</div>
                      </div>
                      <div className="farm-qty-wrap">
                        <button className="farm-qty-btn" onClick={()=>changeQty(item.produto.id,-1)}>−</button>
                        <span style={{fontWeight:600,minWidth:20,textAlign:"center"}}>{item.qty}</span>
                        <button className="farm-qty-btn" onClick={()=>changeQty(item.produto.id,1)}>+</button>
                      </div>
                    </div>
                  ))
                }
              </div>
              <div className="farm-cart-total">
                <div className="farm-total-row"><span>Subtotal:</span><span>€{cartSubtotal.toFixed(2)}</span></div>
                <div className="farm-total-row"><span>IVA (23%):</span><span>€{cartIVA.toFixed(2)}</span></div>
                <div className="farm-total-row farm-total-final"><span>Total:</span><span>€{cartTotal.toFixed(2)}</span></div>
                <div className="farm-pay-btns">
                  <button className="fbtn fbtn-s" onClick={()=>checkout("dinheiro")}><Ico name="money-bill-wave" /> Dinheiro</button>
                  <button className="fbtn fbtn-p" onClick={()=>checkout("cartão")}><Ico name="credit-card" /> Cartão</button>
                  <button className="fbtn fbtn-i" onClick={()=>checkout("MB Way")}><Ico name="mobile-alt" /> MB Way</button>
                  <button className="fbtn fbtn-d" onClick={()=>setCart([])}><Ico name="trash" /> Limpar</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
}
