import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Fornecedores(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="industry" /> Fornecedores</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Novo fornecedor — em desenvolvimento")}><Ico name="plus" /> Novo</button></div>
            <div className="farm-table-wrap">
              <table className="farm-tbl">
                <thead><tr><th>Nome</th><th>NIF</th><th>Contacto</th><th>Produtos</th><th>Status</th></tr></thead>
                <tbody>
                  {[["Pfizer Angola","123456789","+244 923 111 222",45,"Ativo"],["Bayer Portugal","987654321","+244 931 333 444",32,"Ativo"],["Roche Lda","456789012","+244 942 555 666",28,"Ativo"],["Novartis SA","789012345","+244 912 777 888",19,"Inativo"]].map(([n,nif,t,p,s])=>(
                    <tr key={n as string}><td style={{fontWeight:600}}>{n}</td><td><code>{nif}</code></td><td>{t}</td><td>{p}</td><td><span className={`fbadge ${s==="Ativo"?"fbadge-s":"fbadge-d"}`}>{s}</span></td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      );
}
