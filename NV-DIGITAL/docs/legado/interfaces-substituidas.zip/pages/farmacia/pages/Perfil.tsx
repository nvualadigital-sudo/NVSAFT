import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Perfil(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div style={{display:"flex",gap:24,alignItems:"center",marginBottom:24,padding:24,background:"var(--fg)",borderRadius:14,border:"1px solid var(--fgb)"}}>
            <div style={{width:90,height:90,borderRadius:"50%",background:"linear-gradient(135deg,#ff6b6b,#ee5a6f)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"2.4rem",fontWeight:700,border:"3px solid var(--fp)",flexShrink:0}}>AD</div>
            <div>
              <h2 style={{fontSize:"1.5rem",marginBottom:4}}>Administrador NVUALASOFT</h2>
              <p style={{opacity:.65,marginBottom:8}}>admin@nvualasoft.com</p>
              <div style={{display:"flex",gap:16}}>
                {[["1.247","Vendas"],["€18.450","Receita"],["156","Clientes"]].map(([v,l])=>(
                  <div key={l} style={{textAlign:"center"}}><div style={{fontSize:"1.3rem",fontWeight:700,color:"var(--fp)"}}>{v}</div><div style={{fontSize:".75rem",opacity:.65}}>{l}</div></div>
                ))}
              </div>
            </div>
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="user-edit" /> Editar Perfil</h3></div>
            <div className="farm-form-row">
              <div className="farm-form-group"><label className="farm-form-label">Nome</label><input className="farm-form-control" defaultValue="Administrador NVUALASOFT" /></div>
              <div className="farm-form-group"><label className="farm-form-label">Email</label><input className="farm-form-control" defaultValue="admin@nvualasoft.com" /></div>
            </div>
            <div className="farm-form-row">
              <div className="farm-form-group"><label className="farm-form-label">Telefone</label><input className="farm-form-control" defaultValue="+244 941 70 70 61" /></div>
              <div className="farm-form-group"><label className="farm-form-label">Cargo</label><input className="farm-form-control" defaultValue="Administrador" readOnly /></div>
            </div>
            <button className="fbtn fbtn-p" onClick={()=>showToast("Perfil atualizado")}><Ico name="save" /> Salvar</button>
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="lock" /> Alterar Senha</h3></div>
            <div className="farm-form-group"><label className="farm-form-label">Senha Atual</label><input className="farm-form-control" type="password" /></div>
            <div className="farm-form-row">
              <div className="farm-form-group"><label className="farm-form-label">Nova Senha</label><input className="farm-form-control" type="password" /></div>
              <div className="farm-form-group"><label className="farm-form-label">Confirmar</label><input className="farm-form-control" type="password" /></div>
            </div>
            <button className="fbtn fbtn-w" onClick={()=>showToast("Senha alterada")}><Ico name="key" /> Alterar Senha</button>
          </div>
        </div>
      );
}
