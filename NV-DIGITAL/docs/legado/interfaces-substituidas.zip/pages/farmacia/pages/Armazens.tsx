import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Armazens(){
const {products}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-stats">
            {[["Armazém Principal","Luanda","520","245"],["Armazém 2","Viana","280","145"],["Armazém 3","Cacuaco","180","89"]].map(([n,l,total,cat])=>(
              <div key={n} className="farm-stat s">
                <div className="farm-stat-label">{n} — {l}</div>
                <div className="farm-stat-value">{total}</div>
                <div style={{fontSize:".8rem",opacity:.7,marginTop:4}}>{cat} categorias de produto</div>
              </div>
            ))}
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="warehouse" /> Gestão de Armazéns</h3></div>
            <div className="farm-table-wrap">
              <table className="farm-tbl">
                <thead><tr><th>Produto</th><th>Código</th><th>Armazém</th><th>Stock</th><th>Mínimo</th><th>Estado</th></tr></thead>
                <tbody>
                  {products.map(p=>(
                    <tr key={p.id}>
                      <td style={{fontWeight:600}}>{p.nome}</td>
                      <td><code>{p.codigo}</code></td>
                      <td>{p.armazem}</td>
                      <td><span style={{fontWeight:600,color:p.stock<50?"var(--fd)":p.stock<100?"var(--fw)":"inherit"}}>{p.stock}</span></td>
                      <td>50</td>
                      <td><span className={`fbadge ${p.stock<50?"fbadge-d":p.stock<100?"fbadge-w":"fbadge-s"}`}>{p.stock<50?"Crítico":p.stock<100?"Baixo":"OK"}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      );
}
