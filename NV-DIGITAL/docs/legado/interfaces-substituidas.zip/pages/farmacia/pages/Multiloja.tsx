import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Multiloja(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="store" /> Gestão Multi-Loja</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Nova loja — em desenvolvimento")}><Ico name="plus" /> Nova Loja</button></div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:16}}>
              {[{name:"🏪 Loja Principal — Lisboa",addr:"Rua Principal, 123 | Lisboa",vendas:"€8.5K",prods:145,funcs:12,clientes:89},
                {name:"🏪 Loja Porto",addr:"Av. dos Aliados, 45 | Porto",vendas:"€5.2K",prods:98,funcs:8,clientes:56},
                {name:"🏪 Loja Luanda",addr:"Av. Lenin, 22 | Luanda",vendas:"Kz 1.2M",prods:76,funcs:6,clientes:34}].map(s=>(
                <div key={s.name} className="farm-store-card">
                  <div className="farm-store-hdr"><div style={{fontWeight:700}}>{s.name}</div><span className="fbadge fbadge-s">Ativa</span></div>
                  <div style={{fontSize:".8rem",opacity:.7,marginBottom:8}}><Ico name="map-marker-alt" /> {s.addr}</div>
                  <div className="farm-store-stats">
                    <div className="farm-store-stat"><div className="farm-store-stat-val">{s.vendas}</div><div className="farm-store-stat-lbl">Vendas Hoje</div></div>
                    <div className="farm-store-stat"><div className="farm-store-stat-val">{s.prods}</div><div className="farm-store-stat-lbl">Produtos</div></div>
                    <div className="farm-store-stat"><div className="farm-store-stat-val">{s.funcs}</div><div className="farm-store-stat-lbl">Funcionários</div></div>
                    <div className="farm-store-stat"><div className="farm-store-stat-val">{s.clientes}</div><div className="farm-store-stat-lbl">Clientes</div></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      );
}
