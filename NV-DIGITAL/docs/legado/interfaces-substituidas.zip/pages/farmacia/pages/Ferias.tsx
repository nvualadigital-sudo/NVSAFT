import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Ferias(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-stats">
            <div className="farm-stat s"><div className="farm-stat-label">De Férias</div><div className="farm-stat-value">2</div></div>
            <div className="farm-stat i"><div className="farm-stat-label">Pendentes</div><div className="farm-stat-value">3</div></div>
            <div className="farm-stat w"><div className="farm-stat-label">Aprovadas</div><div className="farm-stat-value">12</div></div>
            <div className="farm-stat d"><div className="farm-stat-label">Dias Restantes</div><div className="farm-stat-value">22</div></div>
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="umbrella-beach" /> Pedidos de Férias</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Novo pedido — em desenvolvimento")}><Ico name="plus" /> Novo Pedido</button></div>
            {[{name:"Ana Rodrigues",period:"15-30 Julho 2026 | 15 dias",status:"ok",label:"Aprovado"},
              {name:"Rui Ferreira",period:"20-25 Julho 2026 | 5 dias",status:"pend",label:"Pendente"},
              {name:"Carlos Mendes",period:"1-10 Agosto 2026 | 10 dias",status:"ok",label:"Aprovado"}].map(l=>(
              <div key={l.name} className="farm-leave-item">
                <div><h4 style={{fontWeight:600}}>{l.name}</h4><p style={{fontSize:".8rem",opacity:.65}}>{l.period}</p></div>
                <span className={`farm-leave-status ${l.status}`}>{l.label}</span>
              </div>
            ))}
          </div>
        </div>
      );
}
