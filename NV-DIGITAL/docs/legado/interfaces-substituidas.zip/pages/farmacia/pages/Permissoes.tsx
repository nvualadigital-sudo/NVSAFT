import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Permissoes(){
const {perms,setPerms,showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="key" /> Permissões</h3></div>
            <div className="farm-perm-grid">
              {Object.entries(perms).map(([k,v])=>(
                <div key={k} className="farm-perm-item">
                  <div className="farm-perm-hdr">
                    <span style={{fontWeight:600}}>{k}</span>
                    <label className="farm-toggle">
                      <input type="checkbox" checked={v} onChange={()=>setPerms(prev=>({...prev,[k]:!prev[k]}))} />
                      <span className="farm-toggle-slider" />
                    </label>
                  </div>
                </div>
              ))}
            </div>
            <button className="fbtn fbtn-p" style={{marginTop:16}} onClick={()=>showToast("Permissões guardadas")}><Ico name="save" /> Salvar</button>
          </div>
        </div>
      );
}
