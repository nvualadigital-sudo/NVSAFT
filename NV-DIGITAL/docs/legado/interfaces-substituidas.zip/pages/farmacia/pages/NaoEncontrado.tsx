export default function NaoEncontrado(){
return (
        <div className="farm-page">
          <div className="farm-card" style={{textAlign:"center",padding:60}}>
            <div style={{fontSize:"3rem",marginBottom:16}}>🚧</div>
            <h2 style={{marginBottom:8}}>Módulo em desenvolvimento</h2>
            <p style={{opacity:.65}}>Esta secção será disponibilizada em breve.</p>
          </div>
        </div>
      );
}
