import DispensaFarmacia from "../../clinica/DispensaFarmacia";
import { useFarmaciaContext } from "../FarmaciaContext";
export default function PrescricoesMedicas(){const {session}=useFarmaciaContext();return <DispensaFarmacia session={session} />;}
