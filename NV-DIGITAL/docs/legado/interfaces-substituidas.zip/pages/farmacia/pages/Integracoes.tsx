import { Ico } from "../shared";
export default function Integracoes(){
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="plug" /> Integrações</h3></div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(160px,1fr))",gap:12}}>
              {[["file-invoice","Faturação E.","off"],["cloud","Cloud","ok"],["envelope","Email SMTP","ok"],["credit-card","Pagamentos","off"],["sms","SMS","ok"],["barcode","Código Barras","ok"],["whatsapp","WhatsApp API","ok"],["map-marker-alt","Google Maps","ok"]].map(([ico,name,status])=>(
                <div key={name} className="farm-integ-card">
                  <div className="farm-integ-ico"><Ico name={ico} style={{fontSize:"2rem",color:"var(--fp)"}} /></div>
                  <div className="farm-integ-name">{name}</div>
                  <span className={`farm-integ-status ${status}`}>{status==="ok"?"Conectado":"Desconectado"}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      );
}
