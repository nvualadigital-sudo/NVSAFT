import { Ico } from "../shared";
export default function Atividades(){
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="history" /> Atividades</h3></div>
            <ul className="farm-activity-list">
              {[["sign-in-alt","rgba(10,207,151,.2)","var(--fs)","Sistema iniciado","Admin - 2026-07-11 08:00"],
                ["cash-register","rgba(114,124,245,.2)","var(--fp)","Venda #001 — €125,50","Admin - 2026-07-11 09:30"],
                ["cash-register","rgba(114,124,245,.2)","var(--fp)","Venda #002 — €89,90","Admin - 2026-07-11 10:15"],
                ["money-bill-wave","rgba(250,92,124,.2)","var(--fd)","Saída — €500,00","Admin - 2026-07-11 11:00"]].map(([ico,bg,color,title,time])=>(
                <li key={title} className="farm-activity-item">
                  <div className="farm-activity-ico" style={{background:bg,color}}><Ico name={ico} /></div>
                  <div><div className="farm-activity-title">{title}</div><div className="farm-activity-time">{time}</div></div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      );
}
