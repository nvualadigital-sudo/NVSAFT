import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Configuracoes(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="cog" /> Configurações</h3></div>
            <div className="farm-form-row">
              <div className="farm-form-group"><label className="farm-form-label">Empresa</label><input className="farm-form-control" defaultValue="NVUALASOFT" /></div>
              <div className="farm-form-group"><label className="farm-form-label">NIF</label><input className="farm-form-control" defaultValue="123456789" /></div>
            </div>
            <div className="farm-form-row">
              <div className="farm-form-group"><label className="farm-form-label">IVA (%)</label><input className="farm-form-control" type="number" defaultValue={23} /></div>
              <div className="farm-form-group"><label className="farm-form-label">Moeda</label>
                <select className="farm-form-control"><option>Euro (€)</option><option>Dólar ($)</option><option>Kwanza (Kz)</option></select>
              </div>
            </div>
            <div className="farm-form-group"><label className="farm-form-label">Endereço</label><input className="farm-form-control" defaultValue="Luanda, Angola" /></div>
            <div className="farm-form-row">
              <div className="farm-form-group"><label className="farm-form-label">Telefone</label><input className="farm-form-control" defaultValue="+244 941 70 70 61" /></div>
              <div className="farm-form-group"><label className="farm-form-label">Email</label><input className="farm-form-control" defaultValue="info@nvualasoft.com" /></div>
            </div>
            <button className="fbtn fbtn-p" onClick={()=>showToast("Configurações guardadas")}><Ico name="save" /> Salvar Configurações</button>
          </div>
        </div>
      );
}
