import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Caixa(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-stats">
            <div className="farm-stat s"><div className="farm-stat-label">Saldo Caixa</div><div className="farm-stat-value">€1.847</div></div>
            <div className="farm-stat i"><div className="farm-stat-label">Entradas</div><div className="farm-stat-value">€2.347</div></div>
            <div className="farm-stat d"><div className="farm-stat-label">Saídas</div><div className="farm-stat-value">€500</div></div>
            <div className="farm-stat w"><div className="farm-stat-label">Movimentos</div><div className="farm-stat-value">47</div></div>
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="coins" /> Movimentos de Caixa</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Registar movimento — em desenvolvimento")}><Ico name="plus" /> Registar</button></div>
            {[["11/07 11:45","Venda #003","€89,90","entrada"],["11/07 11:00","Despesa fornecedor","-€500,00","saida"],["11/07 10:15","Venda #002","€125,50","entrada"],["11/07 09:30","Venda #001","€56,20","entrada"]].map(([t,d,v,tipo])=>(
              <div key={t+d} className="farm-caixa-item">
                <div><span style={{fontSize:".78rem",opacity:.6}}>{t}</span> — <span style={{fontWeight:600}}>{d}</span></div>
                <div style={{color:tipo==="entrada"?"var(--fs)":"var(--fd)",fontWeight:700}}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      );
}
