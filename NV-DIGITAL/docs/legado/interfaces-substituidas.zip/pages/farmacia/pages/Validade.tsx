import { Ico } from "../shared";
export default function Validade(){
return (
        <div className="farm-page">
          <div className="farm-alert warn"><Ico name="exclamation-triangle" /><div><strong>Atenção!</strong> Produtos próximos da validade requerem ação imediata.</div></div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="clock" /> Controlo de Validade</h3></div>
            {[{nome:"Paracetamol 500mg — Lote #4521",local:"Armazém Principal",dias:9,cls:"critical"},
              {nome:"Amoxicilina 500mg — Lote #3892",local:"Armazém 2",dias:23,cls:""},
              {nome:"Vitamina C 1000mg — Lote #7821",local:"Armazém Principal",dias:45,cls:""},
              {nome:"Ibuprofeno 400mg — Lote #5623",local:"Armazém 3",dias:180,cls:"ok"}].map(v=>(
              <div key={v.nome} className={`farm-validity-item ${v.cls}`}>
                <div className="farm-validity-info"><h4>{v.nome}</h4><p>{v.local}</p></div>
                <div className="farm-validity-days" style={{color:v.cls==="critical"?"var(--fd)":v.cls==="ok"?"var(--fs)":"var(--fw)"}}>{v.dias} dias</div>
              </div>
            ))}
          </div>
        </div>
      );
}
