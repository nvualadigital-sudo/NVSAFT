import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico,nowTime } from "../shared";
export default function Chat(){
const {chatUser,setChatUser,chatMsg,setChatMsg,chatMsgs,setChatMsgs,chatUsers}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="comments" /> Chat Interno NVUALASOFT</h3></div>
            <div className="farm-chat-container">
              <div className="farm-chat-sidebar">
                {chatUsers.map((u,i)=>(
                  <div key={u.name} className={`farm-chat-user${chatUser===i?" active":""}`} onClick={()=>setChatUser(i)}>
                    <div className="farm-chat-user-av" style={{background:u.color}}>{u.initials}</div>
                    <div><div style={{fontWeight:600,fontSize:".85rem"}}>{u.name}</div><div style={{fontSize:".75rem",opacity:.65}}>{u.last}</div></div>
                  </div>
                ))}
              </div>
              <div className="farm-chat-main">
                <div className="farm-chat-hdr">
                  <strong>{chatUsers[chatUser].name}</strong>
                  <div style={{fontSize:".8rem",opacity:.65}}>Online</div>
                </div>
                <div className="farm-chat-msgs">
                  {chatMsgs.map((m,i)=>(
                    <div key={i} className={`farm-msg${m.sent?" sent":""}`}>
                      <div className="farm-msg-av" style={{background:"var(--fp)"}}>{m.from}</div>
                      <div className="farm-msg-content">
                        <div className="farm-msg-text">{m.text}</div>
                        <div className="farm-msg-time">{m.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="farm-chat-inp">
                  <input placeholder="Escrever mensagem..." value={chatMsg} onChange={e=>setChatMsg(e.target.value)}
                    onKeyDown={e=>{ if(e.key==="Enter"&&chatMsg.trim()){
                      setChatMsgs(prev=>[...prev,{from:"AD",text:chatMsg.trim(),time:nowTime(),sent:true}]);
                      setChatMsg("");
                    }}} />
                  <button className="fbtn fbtn-p" onClick={()=>{ if(chatMsg.trim()){
                    setChatMsgs(prev=>[...prev,{from:"AD",text:chatMsg.trim(),time:nowTime(),sent:true}]);
                    setChatMsg("");
                  }}}><Ico name="paper-plane" /></button>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
}
