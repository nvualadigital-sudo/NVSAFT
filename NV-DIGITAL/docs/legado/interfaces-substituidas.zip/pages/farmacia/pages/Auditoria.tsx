import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Auditoria(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="shield-alt" /> Log de Auditoria</h3><button className="fbtn fbtn-i" onClick={()=>showToast("Auditoria exportada")}><Ico name="download" /> Exportar</button></div>
            {[["Login realizado","Administrador | 2026-07-11 08:00","LOGIN"],
              ["Produto criado: Paracetamol 500mg","Administrador | 2026-07-11 08:15","CREATE"],
              ["Venda finalizada: #001","Administrador | 2026-07-11 09:30","SALE"],
              ["Stock atualizado: Amoxicilina","Sistema | 2026-07-11 10:00","UPDATE"],
              ["Backup automático realizado","Sistema | 2026-07-11 03:00","BACKUP"]].map(([h,d,a])=>(
              <div key={h} className="farm-audit-item">
                <div><h4 style={{fontWeight:600,marginBottom:4}}>{h}</h4><p style={{fontSize:".8rem",opacity:.65}}>{d}</p></div>
                <span className="farm-audit-action">{a}</span>
              </div>
            ))}
          </div>
        </div>
      );
}
