import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
import type { FPage } from "../types";
export default function Dashboard(){
const {showToast,nav}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-alert warn">
            <Ico name="exclamation-triangle" /> <div><strong>Atenção!</strong> 3 produtos com stock abaixo do mínimo e 2 próximos da validade.</div>
          </div>
          <div className="farm-stats">
            <div className="farm-stat s"><div className="farm-stat-label">Vendas Hoje</div><div className="farm-stat-value">€1.847</div><div className="farm-stat-change pos">↑ 12% vs ontem</div></div>
            <div className="farm-stat w"><div className="farm-stat-label">Stock Total</div><div className="farm-stat-value">1.823</div><div className="farm-stat-change neg">↓ 45 unidades hoje</div></div>
            <div className="farm-stat d"><div className="farm-stat-label">Clientes Hoje</div><div className="farm-stat-value">47</div><div className="farm-stat-change pos">↑ 8% vs ontem</div></div>
            <div className="farm-stat i"><div className="farm-stat-label">Lucro Mensal</div><div className="farm-stat-value">€18.450</div><div className="farm-stat-change pos">↑ 23% vs mês anterior</div></div>
          </div>
          <div className="farm-kpi">
            {[["pills","524","Produtos"],["users","247","Clientes"],["industry","18","Fornecedores"],["warehouse","3","Armazéns"],["cash-register","1.245","Vendas/Mês"],["box","12","Encomendas"]].map(([ico,val,lbl])=>(
              <div key={lbl} className="farm-kpi-card"><div className="farm-kpi-ico"><Ico name={ico} /></div><div className="farm-kpi-val">{val}</div><div className="farm-kpi-lbl">{lbl}</div></div>
            ))}
          </div>
          <div className="farm-quick">
            {[["cash-register","Nova Venda","pos"],["plus-circle","Novo Produto",null],["user-plus","Novo Cliente",null],["file-invoice","Faturação","faturacao"],["chart-pie","Relatórios","relatorios"],["comments","Chat","chat"]].map(([ico,lbl,page])=>(
              <button key={lbl} className="farm-quick-btn" onClick={() => page ? nav(page as FPage) : showToast(`${lbl} — em desenvolvimento`)}>
                <i className={`fas fa-${ico}`} /><span>{lbl}</span>
              </button>
            ))}
          </div>
          <h3 style={{marginBottom:16,fontWeight:700}}><Ico name="th-large" /> Módulos Enterprise</h3>
          <div className="farm-modules">
            {[
              ["cash-register","VENDA POS","Gestão de Vendas","pos"],
              ["store","MULTI-LOJA","Gestão de Múltiplas Lojas","multiloja"],
              ["percentage","COMISSÕES","Gestão de Comissões","comissoes"],
              ["bullhorn","MARKETING","Campanhas & Newsletters","marketing"],
              ["code","API & WEBHOOKS","Integrações Externas","api"],
              ["star","AVALIAÇÕES","Feedback de Clientes","avaliacoes"],
              ["tasks","TAREFAS","Gestão de Projetos","tarefas"],
            ].map(([ico,title,sub,page])=>(
              <div key={title} className="farm-module" onClick={() => nav(page as FPage)}>
                <div className="farm-module-hdr">
                  <div className="farm-module-ico"><Ico name={ico} /></div>
                  <div className="farm-module-info"><h3>{title}</h3><p>{sub}</p></div>
                </div>
                <button className="farm-module-btn active">Acessar <Ico name="check" /></button>
              </div>
            ))}
            <div className="farm-module inactive">
              <span className="farm-ribbon">Breve</span>
              <div className="farm-module-hdr">
                <div className="farm-module-ico"><Ico name="file-invoice" /></div>
                <div className="farm-module-info"><h3>F.ELECTRÓNICA</h3><p>Gestão F.E</p></div>
              </div>
              <button className="farm-module-btn inactive">Inativo <Ico name="times" /></button>
            </div>
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="project-diagram" /> Fluxo de Processos</h3></div>
            <div className="farm-process">
              {[["industry","Fornecedor"],["box","Encomendas"],["warehouse","Armazéns"],["exchange-alt","Transferências"],["shopping-cart","Vendas"],["coins","Centros Custo"]].map(([ico,lbl])=>(
                <div key={lbl} className="farm-proc-step"><div className="farm-proc-ico"><Ico name={ico} /></div><div className="farm-proc-lbl">{lbl}</div></div>
              ))}
            </div>
          </div>
          <div className="farm-stats" style={{gridTemplateColumns:"1fr 1fr"}}>
            <div className="farm-card">
              <h3 style={{marginBottom:12}}><Ico name="chart-area" /> Vendas 7 Dias</h3>
              <div className="farm-chart-placeholder">📊 Gráfico — integração Chart.js disponível</div>
            </div>
            <div className="farm-card">
              <h3 style={{marginBottom:12}}><Ico name="chart-pie" /> Categorias</h3>
              <div className="farm-chart-placeholder">🥧 Gráfico circular por categoria</div>
            </div>
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="history" /> Últimas Transações</h3><button className="fbtn fbtn-p fbtn-sm" onClick={()=>nav("caixa")}><Ico name="eye" /> Ver Todas</button></div>
            <div className="farm-table-wrap">
              <table className="farm-tbl">
                <thead><tr><th>Data/Hora</th><th>Operação</th><th>Cliente</th><th>Valor</th><th>Status</th></tr></thead>
                <tbody>
                  <tr><td>11/07 11:45</td><td>Venda POS #003</td><td>João Silva</td><td>€89,90</td><td><span className="fbadge fbadge-s">Pago</span></td></tr>
                  <tr><td>11/07 11:30</td><td>Venda POS #002</td><td>Maria Santos</td><td>€125,50</td><td><span className="fbadge fbadge-s">Pago</span></td></tr>
                  <tr><td>11/07 10:15</td><td>Devolução #001</td><td>Pedro Costa</td><td>-€32,00</td><td><span className="fbadge fbadge-d">Devolvido</span></td></tr>
                  <tr><td>11/07 09:30</td><td>Venda POS #001</td><td>Ana Rodrigues</td><td>€56,20</td><td><span className="fbadge fbadge-s">Pago</span></td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      );
}
