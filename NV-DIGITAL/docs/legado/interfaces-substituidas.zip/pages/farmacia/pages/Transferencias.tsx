import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Transferencias(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="exchange-alt" /> Transferências</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Nova transferência — em desenvolvimento")}><Ico name="plus" /> Nova</button></div>
            <div className="farm-table-wrap">
              <table className="farm-tbl">
                <thead><tr><th>Data</th><th>Produto</th><th>Origem</th><th>Destino</th><th>Qtd</th><th>Estado</th></tr></thead>
                <tbody>
                  {[["11/07","Paracetamol 500mg","Armazém Principal","Armazém 2",50,"Concluída"],
                    ["10/07","Vitamina C 1000mg","Armazém 2","Armazém 3",20,"Concluída"],
                    ["09/07","Ibuprofeno 400mg","Armazém 3","Armazém Principal",30,"Pendente"]].map(([d,p,o,dest,q,s])=>(
                    <tr key={String(d)+String(p)}><td>{d}</td><td style={{fontWeight:600}}>{p}</td><td>{o}</td><td>{dest}</td><td>{q}</td>
                      <td><span className={`fbadge ${s==="Concluída"?"fbadge-s":"fbadge-w"}`}>{s}</span></td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      );
}
