import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Produtos(){
const {products,search,setSearch,setShowProdModal,showToast,deleteProd}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr">
              <h3 className="farm-card-title"><Ico name="pills" /> Produtos</h3>
              <button className="fbtn fbtn-p" onClick={()=>setShowProdModal(true)}><Ico name="plus" /> Novo Produto</button>
            </div>
            <div className="farm-search-box">
              <input placeholder="Pesquisar produtos..." value={search} onChange={e=>setSearch(e.target.value)} />
            </div>
            <div className="farm-table-wrap">
              <table className="farm-tbl">
                <thead><tr><th>Código</th><th>Nome</th><th>Categoria</th><th>Preço</th><th>Stock</th><th>Armazém</th><th>Validade</th><th>Ações</th></tr></thead>
                <tbody>
                  {products.filter(p=>!search||p.nome.toLowerCase().includes(search.toLowerCase())).map(p=>(
                    <tr key={p.id}>
                      <td><code>{p.codigo}</code></td>
                      <td>{p.nome}</td>
                      <td><span className="fbadge fbadge-p">{p.categoria}</span></td>
                      <td>€{p.preco.toFixed(2)}</td>
                      <td><span style={{color:p.stock<50?"var(--fd)":p.stock<100?"var(--fw)":"var(--fs)",fontWeight:600}}>{p.stock}</span></td>
                      <td style={{fontSize:".78rem"}}>{p.armazem}</td>
                      <td style={{fontSize:".78rem"}}>{p.validade}</td>
                      <td>
                        <button className="fbtn fbtn-i fbtn-sm" style={{marginRight:4}} onClick={()=>showToast("Editar: "+p.nome)}><Ico name="edit" /></button>
                        <button className="fbtn fbtn-d fbtn-sm" onClick={()=>deleteProd(p.id)}><Ico name="trash" /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      );
}
