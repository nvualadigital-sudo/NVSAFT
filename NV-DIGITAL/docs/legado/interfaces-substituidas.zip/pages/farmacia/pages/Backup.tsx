import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Backup(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr">
              <h3 className="farm-card-title"><Ico name="database" /> Backup & Restauração</h3>
              <div style={{display:"flex",gap:8}}>
                <button className="fbtn fbtn-p" onClick={()=>showToast("Backup criado com sucesso")}><Ico name="download" /> Criar Backup</button>
                <button className="fbtn fbtn-w" onClick={()=>showToast("Seleciona um ficheiro para restaurar")}><Ico name="upload" /> Restaurar</button>
              </div>
            </div>
            {[["Backup Automático","2026-07-11 03:00 | 2.4 MB"],["Backup Automático","2026-07-10 03:00 | 2.3 MB"],["Backup Manual","2026-07-09 15:30 | 2.2 MB"]].map(([n,d],i)=>(
              <div key={i} className="farm-backup-item">
                <div><h4 style={{fontWeight:600}}>{n}</h4><p style={{fontSize:".8rem",opacity:.65}}>{d}</p></div>
                <button className="fbtn fbtn-i fbtn-sm" onClick={()=>showToast("A descarregar backup...")}><Ico name="download" /></button>
              </div>
            ))}
          </div>
        </div>
      );
}
