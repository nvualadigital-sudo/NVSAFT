import { Ico } from "../shared";
export default function Comissoes(){
return (
        <div className="farm-page">
          <div className="farm-stats">
            <div className="farm-stat s"><div className="farm-stat-label">Total Comissões</div><div className="farm-stat-value">€2.450</div></div>
            <div className="farm-stat i"><div className="farm-stat-label">Vendedores Ativos</div><div className="farm-stat-value">8</div></div>
            <div className="farm-stat w"><div className="farm-stat-label">Pendentes</div><div className="farm-stat-value">€850</div></div>
            <div className="farm-stat d"><div className="farm-stat-label">Pagas este Mês</div><div className="farm-stat-value">€1.600</div></div>
          </div>
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="percentage" /> Comissões por Vendedor</h3></div>
            {[{nome:"Miguel Santos",role:"Vendedor | 45 vendas",total:"€13.000",taxa:"5%",pago:"€450",comissao:"€650"},
              {nome:"Sofia Almeida",role:"Caixa | 32 vendas",total:"€9.600",taxa:"5%",pago:"€320",comissao:"€480"}].map(v=>(
              <div key={v.nome} className="farm-comm-card">
                <div className="farm-comm-hdr">
                  <div><h4>{v.nome}</h4><p style={{fontSize:".82rem",opacity:.65}}>{v.role}</p></div>
                  <div style={{fontSize:"1.4rem",fontWeight:700,color:"var(--fs)"}}>{v.comissao}</div>
                </div>
                <div className="farm-comm-stats">
                  <div className="farm-comm-stat"><div className="farm-comm-stat-val">{v.total}</div><div className="farm-comm-stat-lbl">Vendas Totais</div></div>
                  <div className="farm-comm-stat"><div className="farm-comm-stat-val">{v.taxa}</div><div className="farm-comm-stat-lbl">Taxa</div></div>
                  <div className="farm-comm-stat"><div className="farm-comm-stat-val">{v.pago}</div><div className="farm-comm-stat-lbl">Já Pago</div></div>
                  <div className="farm-comm-stat"><div className="farm-comm-stat-val">{v.comissao}</div><div className="farm-comm-stat-lbl">Total</div></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
}
