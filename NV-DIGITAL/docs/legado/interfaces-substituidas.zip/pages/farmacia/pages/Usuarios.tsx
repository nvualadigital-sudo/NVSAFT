import { useFarmaciaContext } from "../FarmaciaContext";
import { Ico } from "../shared";
export default function Usuarios(){
const {showToast}=useFarmaciaContext();
return (
        <div className="farm-page">
          <div className="farm-card">
            <div className="farm-card-hdr"><h3 className="farm-card-title"><Ico name="user-shield" /> Usuários</h3><button className="fbtn fbtn-p" onClick={()=>showToast("Novo usuário — em desenvolvimento")}><Ico name="plus" /> Novo</button></div>
            <div className="farm-table-wrap">
              <table className="farm-tbl">
                <thead><tr><th>ID</th><th>Nome</th><th>Email</th><th>Cargo</th><th>Status</th><th>Último Acesso</th></tr></thead>
                <tbody>
                  {[{id:1,nome:"Administrador NVUALASOFT",email:"admin@nvualasoft.com",cargo:"Admin",status:"Ativo",acesso:"11/07/2026 11:45"},
                    {id:2,nome:"Carlos Mendes",email:"carlos@nvualasoft.com",cargo:"Vendedor",status:"Ativo",acesso:"11/07/2026 09:30"},
                    {id:3,nome:"Ana Rodrigues",email:"ana@nvualasoft.com",cargo:"Caixa",status:"Ativo",acesso:"11/07/2026 08:00"}].map(u=>(
                    <tr key={u.id}>
                      <td>#{u.id}</td><td style={{fontWeight:600}}>{u.nome}</td><td>{u.email}</td><td>{u.cargo}</td>
                      <td><span className="fbadge fbadge-s">{u.status}</span></td><td style={{fontSize:".78rem"}}>{u.acesso}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      );
}
