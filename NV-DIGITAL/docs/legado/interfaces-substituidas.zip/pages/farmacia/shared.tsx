export function Ico({ name, style }: { name: string; style?: React.CSSProperties }) {
  return <i className={`fas fa-${name}`} style={style} />;
}

export function nowTime() {
  const n = new Date();
  return n.getHours().toString().padStart(2,"0") + ":" + n.getMinutes().toString().padStart(2,"0");
}

export const PRODUCT_ICONS: Record<string, string> = {
  Medicamentos: "💊", Suplementos: "💉", Higiene: "🧴", Cosméticos: "💄"
};
