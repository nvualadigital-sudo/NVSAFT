import { useCallback,useEffect,useRef,useState } from "react";
import type { ClinicalSession } from "../clinica/store";
import { INITIAL_CLIENTS,INITIAL_NOTIFS,INITIAL_PRODUCTS } from "./data";
import { FARM_CSS } from "./styles";
import type { CartItem,Client,FPage,Notification,Product } from "./types";
export function useFarmacia(session?:ClinicalSession){
useEffect(() => {
    const style = document.createElement("style");
    style.id = "farm-style";
    style.textContent = FARM_CSS;
    document.head.appendChild(style);
    // Load FA if not present
    if (!document.getElementById("farm-fa")) {
      const link = document.createElement("link");
      link.id = "farm-fa";
      link.rel = "stylesheet";
      link.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css";
      document.head.appendChild(link);
    }
    return () => {
      document.getElementById("farm-style")?.remove();
    };
  }, []);

const [clock, setClock] = useState(() => new Date().toLocaleTimeString("pt-PT"));

useEffect(() => {
    const t = setInterval(() => setClock(new Date().toLocaleTimeString("pt-PT")), 1000);
    return () => clearInterval(t);
  }, []);

const [activePage, setActivePage] = useState<FPage>("dashboard");

const [lightMode, setLightMode] = useState(false);

const [showNotifs, setShowNotifs] = useState(false);

const [notifs, setNotifs] = useState<Notification[]>(INITIAL_NOTIFS);

const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);

const [clients, setClients] = useState<Client[]>(INITIAL_CLIENTS);

const [cart, setCart] = useState<CartItem[]>([]);

const [posCategory, setPosCategory] = useState("Todos");

const [posSearch, setPosSearch] = useState("");

const [toast, setToast] = useState("");

const [toastOn, setToastOn] = useState(false);

const toastRef = useRef<number | null>(null);

const [search, setSearch] = useState("");

const [showProdModal, setShowProdModal] = useState(false);

const [showClientModal, setShowClientModal] = useState(false);

const [pf, setPf] = useState({ codigo:"", nome:"", categoria:"Medicamentos", preco:"", stock:"", armazem:"Armazém Principal", validade:"" });

const [cf, setCf] = useState({ nome:"", nif:"", email:"", telefone:"" });

const [chatUser, setChatUser] = useState(0);

const [chatMsg, setChatMsg] = useState("");

const [chatMsgs, setChatMsgs] = useState([
    { from:"CM", text:"Olá, tudo bem?", time:"09:30", sent:false },
    { from:"AD", text:"Tudo ótimo! E contigo?", time:"09:31", sent:true },
    { from:"CM", text:"Preciso de ajuda com o inventário", time:"09:32", sent:false },
  ]);

const chatUsers = [
    { initials:"CM", name:"Carlos Mendes", last:"Olá, tudo bem?", color:"var(--fp)" },
    { initials:"AR", name:"Ana Rodrigues", last:"Reunião às 10h", color:"var(--fs)" },
    { initials:"RF", name:"Rui Ferreira", last:"Stock atualizado", color:"var(--fi)" },
    { initials:"SA", name:"Sofia Almeida", last:"Caixa fechado", color:"var(--fw)" },
  ];

const [perms, setPerms] = useState<Record<string, boolean>>({
    Dashboard:true, Produtos:true, Clientes:true, Fornecedores:true, Armazéns:true,
    Caixa:true, Faturação:true, Relatórios:true, Funcionários:true, Chat:true,
    Documentos:true, Usuários:false, Configurações:false, Auditoria:false
  });

const showToast = useCallback((msg: string) => {
    setToast(msg); setToastOn(true);
    if (toastRef.current) clearTimeout(toastRef.current);
    toastRef.current = window.setTimeout(() => setToastOn(false), 2200);
  }, []);

const posProducts = products.filter(p =>
    (posCategory === "Todos" || p.categoria === posCategory) &&
    (!posSearch || p.nome.toLowerCase().includes(posSearch.toLowerCase()))
  );

function addToCart(p: Product) {
    setCart(prev => {
      const e = prev.find(x => x.produto.id === p.id);
      if (e) return prev.map(x => x.produto.id === p.id ? { ...x, qty: x.qty + 1 } : x);
      return [...prev, { produto: p, qty: 1 }];
    });
    showToast(`${p.nome} adicionado ao carrinho`);
  }

function changeQty(id: number, delta: number) {
    setCart(prev => prev.map(x => x.produto.id === id ? { ...x, qty: Math.max(0, x.qty + delta) } : x).filter(x => x.qty > 0));
  }

const cartSubtotal = cart.reduce((s, x) => s + x.produto.preco * x.qty, 0);

const cartIVA = cartSubtotal * 0.23;

const cartTotal = cartSubtotal + cartIVA;

function checkout(method: string) {
    if (cart.length === 0) { showToast("Carrinho vazio"); return; }
    showToast(`Pagamento ${method} processado — Total: €${cartTotal.toFixed(2)}`);
    setCart([]);
  }

function saveProd(e: React.FormEvent) {
    e.preventDefault();
    setProducts(prev => [...prev, { id: Date.now(), ...pf, preco: parseFloat(pf.preco), stock: parseInt(pf.stock) }]);
    setPf({ codigo:"", nome:"", categoria:"Medicamentos", preco:"", stock:"", armazem:"Armazém Principal", validade:"" });
    setShowProdModal(false);
    showToast("Produto guardado com sucesso");
  }

function deleteProd(id: number) {
    if (!window.confirm("Eliminar produto?")) return;
    setProducts(prev => prev.filter(p => p.id !== id));
    showToast("Produto eliminado");
  }

function saveClient(e: React.FormEvent) {
    e.preventDefault();
    setClients(prev => [...prev, { id: Date.now(), ...cf, saldo: 0 }]);
    setCf({ nome:"", nif:"", email:"", telefone:"" });
    setShowClientModal(false);
    showToast("Cliente guardado com sucesso");
  }

function deleteClient(id: number) {
    if (!window.confirm("Eliminar cliente?")) return;
    setClients(prev => prev.filter(c => c.id !== id));
    showToast("Cliente eliminado");
  }

const unreadCount = notifs.filter(n => !n.read).length;

function nav(page: FPage) { setActivePage(page); setShowNotifs(false); }
useEffect(()=>()=>{if(toastRef.current)clearTimeout(toastRef.current);},[]);
return {session,clock,setClock,activePage,setActivePage,lightMode,setLightMode,showNotifs,setShowNotifs,notifs,setNotifs,products,setProducts,clients,setClients,cart,setCart,posCategory,setPosCategory,posSearch,setPosSearch,toast,setToast,toastOn,setToastOn,toastRef,search,setSearch,showProdModal,setShowProdModal,showClientModal,setShowClientModal,pf,setPf,cf,setCf,chatUser,setChatUser,chatMsg,setChatMsg,chatMsgs,setChatMsgs,chatUsers,perms,setPerms,showToast,posProducts,addToCart,changeQty,cartSubtotal,cartIVA,cartTotal,checkout,saveProd,deleteProd,saveClient,deleteClient,unreadCount,nav};
}
