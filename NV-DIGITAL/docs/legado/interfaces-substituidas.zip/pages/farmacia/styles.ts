export const FARM_CSS = `
#farm-wrapper {
  --fp: #727cf5; --fpd: #5a66e8;
  --fs: #0acf97; --fi: #39afd1; --fw: #ffbc00; --fd: #fa5c7c;
  --fg: rgba(255,255,255,0.08); --fgb: rgba(255,255,255,0.15);
  --fsh: 0 8px 32px rgba(0,0,0,0.3);
  font-family:'Segoe UI',system-ui,-apple-system,sans-serif;
  color:#fff; height:100%; width:100%; display:flex; flex-direction:column; overflow:hidden;
  background:linear-gradient(135deg,#0f1419 0%,#1e3a8a 50%,#0f1419 100%);
  position:relative;
}
#farm-wrapper.light {
  color:#1a1f2e;
  background:linear-gradient(135deg,#f0f4ff 0%,#e0e7ff 50%,#f0f4ff 100%);
  --fg:rgba(0,0,0,0.05); --fgb:rgba(0,0,0,0.1);
}
#farm-wrapper *{box-sizing:border-box;margin:0;padding:0;}

/* Header */
.farm-hdr{height:64px;background:rgba(15,20,25,0.85);backdrop-filter:blur(20px);border-bottom:1px solid var(--fgb);
  display:flex;align-items:center;justify-content:space-between;padding:0 20px;flex-shrink:0;gap:12px;z-index:20;}
#farm-wrapper.light .farm-hdr{background:rgba(255,255,255,0.85);}
.farm-logo{display:flex;align-items:center;gap:10px;flex-shrink:0;}
.farm-logo-icon{width:38px;height:38px;border-radius:10px;background:linear-gradient(135deg,var(--fp),var(--fpd));
  display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.1rem;color:white;box-shadow:0 4px 12px rgba(114,124,245,.4);}
.farm-logo-text h2{font-size:1rem;font-weight:700;background:linear-gradient(135deg,#fff,#a5b4fc);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
#farm-wrapper.light .farm-logo-text h2{background:linear-gradient(135deg,#1e3a8a,#5a66e8);-webkit-background-clip:text;}
.farm-logo-text p{font-size:0.68rem;opacity:0.7;}
.farm-search{flex:1;max-width:280px;position:relative;}
.farm-search input{width:100%;padding:8px 36px 8px 12px;background:var(--fg);border:1px solid var(--fgb);border-radius:20px;color:inherit;font-size:0.85rem;outline:none;font-family:inherit;}
.farm-search input::placeholder{color:rgba(255,255,255,.5);}
#farm-wrapper.light .farm-search input{color:#1a1f2e;}
#farm-wrapper.light .farm-search input::placeholder{color:rgba(0,0,0,.4);}
.farm-search-ico{position:absolute;right:10px;top:50%;transform:translateY(-50%);opacity:.5;font-size:0.85rem;}
.farm-hdr-right{display:flex;align-items:center;gap:8px;flex-shrink:0;}
.farm-hdr-btn{width:38px;height:38px;border-radius:10px;border:none;background:var(--fg);border:1px solid var(--fgb);color:inherit;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:1rem;transition:all .2s;position:relative;}
.farm-hdr-btn:hover{background:rgba(114,124,245,.3);transform:translateY(-1px);}
.farm-notif-dot{position:absolute;top:7px;right:7px;width:7px;height:7px;background:var(--fd);border-radius:50%;}
.farm-status{display:flex;align-items:center;gap:6px;padding:5px 10px;background:rgba(10,207,151,.15);border:1px solid rgba(10,207,151,.3);border-radius:16px;font-size:0.75rem;}
.farm-dot{width:7px;height:7px;background:var(--fs);border-radius:50%;animation:farmPulse 2s infinite;}
@keyframes farmPulse{0%,100%{opacity:1;transform:scale(1);}50%{opacity:.6;transform:scale(1.2);}}
.farm-clock{font-size:0.8rem;padding:5px 10px;background:var(--fg);border:1px solid var(--fgb);border-radius:16px;}
.farm-user{display:flex;align-items:center;gap:8px;padding:4px 10px 4px 4px;background:var(--fg);border:1px solid var(--fgb);border-radius:20px;cursor:pointer;}
.farm-user-av{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#ff6b6b,#ee5a6f);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.8rem;}
.farm-user-info{font-size:.8rem;}
.farm-user-info div:last-child{font-size:.68rem;opacity:.6;}

/* Body layout */
.farm-body{flex:1;display:flex;overflow:hidden;}

/* Sidebar */
.farm-sidebar{width:260px;background:rgba(15,20,25,.85);backdrop-filter:blur(20px);border-right:1px solid var(--fgb);overflow-y:auto;flex-shrink:0;transition:width .2s;}
.farm-sidebar::-webkit-scrollbar{width:4px;}
.farm-sidebar::-webkit-scrollbar-thumb{background:rgba(255,255,255,.15);border-radius:2px;}
#farm-wrapper.light .farm-sidebar{background:rgba(255,255,255,.85);}
.farm-sidebar-hdr{padding:18px 16px;border-bottom:1px solid var(--fgb);}
.farm-sidebar-hdr h3{font-size:.9rem;font-weight:700;display:flex;align-items:center;gap:8px;margin-bottom:3px;}
.farm-sidebar-hdr p{font-size:.7rem;opacity:.6;}
.farm-nav{list-style:none;padding:10px 0;}
.farm-nav-sec{padding:10px 16px 4px;font-size:.65rem;text-transform:uppercase;opacity:.45;letter-spacing:1.5px;font-weight:700;}
.farm-nav-item{padding:10px 16px;cursor:pointer;display:flex;align-items:center;gap:10px;transition:all .2s;border-left:3px solid transparent;font-size:.85rem;}
.farm-nav-item:hover{background:rgba(114,124,245,.12);border-left-color:var(--fp);}
.farm-nav-item.active{background:rgba(114,124,245,.18);border-left-color:var(--fp);font-weight:600;}
.farm-nav-ico{font-size:1rem;width:20px;text-align:center;color:var(--fp);}
.farm-nav-badge{margin-left:auto;background:var(--fd);color:white;padding:1px 6px;border-radius:8px;font-size:.65rem;font-weight:700;}

/* Main content */
.farm-content{flex:1;overflow-y:auto;padding:20px;}
.farm-content::-webkit-scrollbar{width:6px;}
.farm-content::-webkit-scrollbar-thumb{background:rgba(255,255,255,.15);border-radius:3px;}
.farm-page{animation:farmFadeIn .3s ease;}
@keyframes farmFadeIn{from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);}}

/* Glass card */
.farm-card{background:var(--fg);backdrop-filter:blur(20px);border:1px solid var(--fgb);border-radius:14px;padding:20px;margin-bottom:20px;box-shadow:var(--fsh);}
.farm-card-hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid var(--fgb);}
.farm-card-title{font-size:1.1rem;font-weight:700;display:flex;align-items:center;gap:8px;}

/* Stats grid */
.farm-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-bottom:20px;}
.farm-stat{background:var(--fg);border:1px solid var(--fgb);border-radius:14px;padding:20px;position:relative;overflow:hidden;transition:all .2s;}
.farm-stat:hover{transform:translateY(-3px);}
.farm-stat.s{border-left:4px solid var(--fs);}.farm-stat.w{border-left:4px solid var(--fw);}
.farm-stat.d{border-left:4px solid var(--fd);}.farm-stat.i{border-left:4px solid var(--fi);}
.farm-stat-label{font-size:.8rem;opacity:.7;margin-bottom:8px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;}
.farm-stat-value{font-size:2rem;font-weight:700;background:linear-gradient(135deg,#fff,#a5b4fc);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
#farm-wrapper.light .farm-stat-value{background:linear-gradient(135deg,#1e3a8a,#5a66e8);-webkit-background-clip:text;}
.farm-stat-change{font-size:.8rem;margin-top:6px;}
.farm-stat-change.pos{color:var(--fs);}.farm-stat-change.neg{color:var(--fd);}

/* KPI grid */
.farm-kpi{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-bottom:20px;}
.farm-kpi-card{background:var(--fg);border:1px solid var(--fgb);border-radius:12px;padding:16px;text-align:center;transition:all .2s;}
.farm-kpi-card:hover{transform:scale(1.03);border-color:var(--fp);}
.farm-kpi-ico{font-size:1.8rem;color:var(--fp);margin-bottom:8px;}
.farm-kpi-val{font-size:1.6rem;font-weight:700;margin-bottom:4px;}
.farm-kpi-lbl{font-size:.8rem;opacity:.65;}

/* Quick actions */
.farm-quick{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:20px;}
.farm-quick-btn{background:var(--fg);border:1px solid var(--fgb);border-radius:12px;padding:16px;text-align:center;cursor:pointer;transition:all .2s;border:none;color:inherit;}
.farm-quick-btn:hover{transform:translateY(-4px);border-color:var(--fp);background:rgba(114,124,245,.15);}
.farm-quick-btn i{font-size:1.6rem;color:var(--fp);display:block;margin-bottom:8px;}
.farm-quick-btn span{font-size:.8rem;font-weight:600;}

/* Modules grid */
.farm-modules{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;margin-bottom:20px;}
.farm-module{background:var(--fg);border:1px solid var(--fgb);border-radius:14px;padding:20px;transition:all .2s;cursor:pointer;position:relative;overflow:hidden;}
.farm-module:hover{transform:translateY(-6px) scale(1.01);border-color:rgba(114,124,245,.5);}
.farm-module.inactive{opacity:.55;cursor:default;}
.farm-module.inactive:hover{transform:none;}
.farm-module-hdr{display:flex;align-items:center;gap:12px;margin-bottom:12px;}
.farm-module-ico{width:60px;height:60px;background:linear-gradient(135deg,var(--fp),var(--fpd));border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;color:white;box-shadow:0 6px 16px rgba(114,124,245,.35);}
.farm-module-info h3{font-size:1rem;font-weight:700;margin-bottom:3px;}
.farm-module-info p{font-size:.8rem;opacity:.65;}
.farm-module-btn{padding:6px 16px;border:none;border-radius:16px;cursor:pointer;font-weight:600;font-size:.8rem;display:inline-flex;align-items:center;gap:6px;}
.farm-module-btn.active{background:linear-gradient(135deg,var(--fp),var(--fpd));color:white;}
.farm-module-btn.inactive{background:rgba(108,117,125,.3);color:rgba(255,255,255,.5);cursor:not-allowed;}
.farm-ribbon{position:absolute;top:12px;right:-32px;background:var(--fd);color:white;padding:4px 38px;font-size:.7rem;font-weight:700;transform:rotate(45deg);}

/* Process flow */
.farm-process{display:flex;justify-content:space-between;align-items:center;padding:24px;background:var(--fg);border:1px solid var(--fgb);border-radius:14px;margin-bottom:20px;overflow-x:auto;gap:8px;}
.farm-proc-step{text-align:center;flex:1;position:relative;padding:0 8px;min-width:90px;}
.farm-proc-step::after{content:'→';position:absolute;right:-16px;top:26px;font-size:1.2rem;color:var(--fp);font-weight:700;}
.farm-proc-step:last-child::after{display:none;}
.farm-proc-ico{width:60px;height:60px;background:linear-gradient(135deg,var(--fp),var(--fpd));color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 10px;font-size:1.5rem;}
.farm-proc-lbl{font-size:.8rem;font-weight:600;}

/* Buttons */
.fbtn{padding:9px 18px;border:none;border-radius:9px;cursor:pointer;font-size:.85rem;font-weight:600;display:inline-flex;align-items:center;gap:6px;color:white;transition:all .2s;}
.fbtn:hover{transform:translateY(-1px);}
.fbtn-p{background:linear-gradient(135deg,var(--fp),var(--fpd));}
.fbtn-s{background:linear-gradient(135deg,var(--fs),#089970);}
.fbtn-d{background:linear-gradient(135deg,var(--fd),#e04a6a);}
.fbtn-w{background:linear-gradient(135deg,var(--fw),#e5a800);color:#333;}
.fbtn-i{background:linear-gradient(135deg,var(--fi),#2a8fa8);}
.fbtn-sm{padding:5px 10px;font-size:.75rem;}
.fbtn-lg{padding:12px 24px;font-size:.95rem;}

/* Tables */
.farm-table-wrap{overflow-x:auto;}
table.farm-tbl{width:100%;border-collapse:collapse;}
table.farm-tbl th,table.farm-tbl td{padding:12px;text-align:left;border-bottom:1px solid var(--fgb);}
table.farm-tbl th{background:rgba(114,124,245,.12);font-weight:700;font-size:.75rem;text-transform:uppercase;letter-spacing:.5px;}
table.farm-tbl tr:hover{background:rgba(114,124,245,.06);}

/* Forms */
.farm-form-group{margin-bottom:16px;}
.farm-form-label{display:block;margin-bottom:6px;font-weight:600;font-size:.85rem;}
.farm-form-control{width:100%;padding:10px;background:rgba(255,255,255,.08);border:1px solid var(--fgb);border-radius:9px;font-size:.85rem;color:inherit;font-family:inherit;outline:none;}
.farm-form-control:focus{border-color:var(--fp);}
.farm-form-control option{background:#1a1f2e;color:white;}
#farm-wrapper.light .farm-form-control{background:rgba(0,0,0,.05);color:#1a1f2e;}
.farm-form-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;}

/* Modal */
.farm-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:1000;align-items:center;justify-content:center;backdrop-filter:blur(8px);}
.farm-modal.open{display:flex;animation:farmFadeIn .2s ease;}
.farm-modal-box{background:rgba(15,20,25,.97);border:1px solid var(--fgb);border-radius:18px;padding:26px;max-width:640px;width:90%;max-height:88vh;overflow-y:auto;}
#farm-wrapper.light .farm-modal-box{background:rgba(255,255,255,.97);color:#1a1f2e;}
.farm-modal-hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;padding-bottom:12px;border-bottom:1px solid var(--fgb);}
.farm-modal-close{background:rgba(255,255,255,.1);border:none;font-size:1.1rem;cursor:pointer;color:inherit;width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;}
.farm-modal-close:hover{background:rgba(250,92,124,.3);}

/* POS */
.farm-pos{display:grid;grid-template-columns:1fr 380px;gap:16px;height:calc(100vh - 200px);}
.farm-pos-products,.farm-pos-cart{background:var(--fg);border:1px solid var(--fgb);border-radius:14px;padding:16px;overflow-y:auto;}
.farm-pos-cart{display:flex;flex-direction:column;}
.farm-product-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-top:12px;}
.farm-product-card{border:1px solid var(--fgb);border-radius:12px;padding:12px;text-align:center;cursor:pointer;transition:all .2s;background:rgba(255,255,255,.04);}
.farm-product-card:hover{border-color:var(--fp);background:rgba(114,124,245,.15);transform:translateY(-4px);}
.farm-product-ico{font-size:2.5rem;margin-bottom:8px;display:block;}
.farm-product-name{font-size:.8rem;font-weight:600;margin-bottom:4px;}
.farm-product-price{color:var(--fp);font-weight:700;font-size:.95rem;}
.farm-product-stock{font-size:.7rem;opacity:.6;margin-top:3px;}
.farm-cart-items{flex:1;overflow-y:auto;margin-bottom:12px;}
.farm-cart-item{display:flex;justify-content:space-between;align-items:center;padding:10px;background:rgba(255,255,255,.03);border-radius:8px;margin-bottom:6px;}
.farm-cart-item-info{flex:1;}
.farm-cart-item-name{font-weight:600;font-size:.85rem;margin-bottom:2px;}
.farm-cart-item-price{font-size:.75rem;opacity:.6;}
.farm-qty-wrap{display:flex;align-items:center;gap:8px;}
.farm-qty-btn{width:28px;height:28px;border:1px solid var(--fgb);background:rgba(255,255,255,.08);border-radius:6px;cursor:pointer;font-weight:700;color:inherit;font-size:.9rem;}
.farm-qty-btn:hover{border-color:var(--fp);}
.farm-cart-total{border-top:1px solid var(--fgb);padding-top:12px;}
.farm-total-row{display:flex;justify-content:space-between;margin-bottom:8px;font-size:.85rem;}
.farm-total-final{font-size:1.5rem;font-weight:700;color:var(--fp);margin-top:8px;padding-top:8px;border-top:2px solid var(--fp);}
.farm-pay-btns{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px;}

/* Category filter */
.farm-cat-filter{display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap;}
.farm-cat-btn{padding:6px 14px;border:1px solid var(--fgb);background:rgba(255,255,255,.04);border-radius:18px;cursor:pointer;font-weight:600;font-size:.8rem;color:inherit;}
.farm-cat-btn:hover{border-color:var(--fp);}
.farm-cat-btn.active{background:var(--fp);border-color:var(--fp);color:white;}

/* Badges */
.fbadge{display:inline-block;padding:3px 10px;border-radius:16px;font-size:.72rem;font-weight:700;}
.fbadge-s{background:rgba(10,207,151,.2);color:var(--fs);border:1px solid rgba(10,207,151,.3);}
.fbadge-d{background:rgba(250,92,124,.2);color:var(--fd);border:1px solid rgba(250,92,124,.3);}
.fbadge-w{background:rgba(255,188,0,.2);color:var(--fw);border:1px solid rgba(255,188,0,.3);}
.fbadge-i{background:rgba(57,175,209,.2);color:var(--fi);border:1px solid rgba(57,175,209,.3);}
.fbadge-p{background:rgba(114,124,245,.2);color:var(--fp);border:1px solid rgba(114,124,245,.3);}

/* Toast */
.farm-toast{position:fixed;bottom:20px;right:20px;background:rgba(15,20,25,.95);color:white;padding:10px 18px;border-radius:10px;border-left:4px solid var(--fs);font-size:.85rem;opacity:0;pointer-events:none;transition:opacity .2s,transform .2s;transform:translateY(10px);z-index:9999;}
.farm-toast.show{opacity:1;transform:translateY(0);}

/* Alert banners */
.farm-alert{background:rgba(250,92,124,.12);border-left:4px solid var(--fd);border:1px solid rgba(250,92,124,.3);padding:14px 18px;border-radius:10px;margin-bottom:16px;display:flex;align-items:center;gap:12px;}
.farm-alert.warn{background:rgba(255,188,0,.12);border-left-color:var(--fw);border-color:rgba(255,188,0,.3);}
.farm-alert.info{background:rgba(57,175,209,.12);border-left-color:var(--fi);border-color:rgba(57,175,209,.3);}

/* Misc */
.farm-activity-list{list-style:none;}
.farm-activity-item{padding:12px;border-bottom:1px solid var(--fgb);display:flex;gap:12px;align-items:flex-start;}
.farm-activity-ico{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.farm-activity-title{font-weight:600;margin-bottom:3px;font-size:.9rem;}
.farm-activity-time{font-size:.75rem;opacity:.6;}
.farm-validity-item{padding:12px;background:rgba(255,255,255,.04);border-radius:10px;border-left:4px solid var(--fw);margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;}
.farm-validity-item.critical{border-left-color:var(--fd);background:rgba(250,92,124,.08);}
.farm-validity-item.ok{border-left-color:var(--fs);}
.farm-validity-info h4{margin-bottom:4px;font-size:.9rem;font-weight:600;}
.farm-validity-info p{font-size:.78rem;opacity:.65;}
.farm-validity-days{font-weight:700;font-size:1.1rem;}
.farm-audit-item{padding:12px;background:rgba(255,255,255,.04);border-radius:10px;border-left:4px solid var(--fp);margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;}
.farm-audit-action{padding:3px 10px;border-radius:10px;font-size:.72rem;font-weight:700;background:rgba(114,124,245,.2);color:var(--fp);}
.farm-log-item{padding:10px;background:rgba(255,255,255,.03);border-radius:8px;margin-bottom:6px;font-family:monospace;font-size:.82rem;display:flex;gap:12px;}
.farm-log-time{color:var(--fi);min-width:140px;}
.farm-log-level{padding:1px 8px;border-radius:4px;font-size:.68rem;font-weight:700;min-width:52px;text-align:center;}
.farm-log-level.info{background:rgba(57,175,209,.2);color:var(--fi);}
.farm-log-level.warn{background:rgba(255,188,0,.2);color:var(--fw);}
.farm-log-level.error{background:rgba(250,92,124,.2);color:var(--fd);}
.farm-promo-card{background:linear-gradient(135deg,var(--fp),var(--fpd));border-radius:14px;padding:20px;margin-bottom:16px;position:relative;overflow:hidden;}
.farm-promo-card::before{content:'';position:absolute;top:-40%;right:-15%;width:180px;height:180px;background:rgba(255,255,255,.1);border-radius:50%;}
.farm-promo-title{font-size:1.3rem;font-weight:700;margin-bottom:8px;}
.farm-promo-desc{font-size:.9rem;opacity:.9;margin-bottom:12px;}
.farm-promo-code{background:rgba(255,255,255,.2);padding:6px 14px;border-radius:8px;display:inline-block;font-weight:700;}
.farm-task-item{padding:12px;background:rgba(255,255,255,.04);border-radius:10px;border-left:4px solid var(--fp);margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;}
.farm-task-item.hp{border-left-color:var(--fd);}
.farm-task-item.done{opacity:.55;border-left-color:var(--fs);}
.farm-task-due{font-size:.78rem;color:var(--fw);}
.farm-comm-card{background:var(--fg);border:1px solid var(--fgb);border-radius:12px;padding:16px;margin-bottom:12px;}
.farm-comm-hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;}
.farm-comm-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;}
.farm-comm-stat{text-align:center;padding:8px;background:rgba(255,255,255,.05);border-radius:8px;}
.farm-comm-stat-val{font-size:1rem;font-weight:700;color:var(--fp);}
.farm-comm-stat-lbl{font-size:.7rem;opacity:.65;}
.farm-toggle{position:relative;width:46px;height:22px;}
.farm-toggle input{opacity:0;width:0;height:0;}
.farm-toggle-slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background:rgba(255,255,255,.2);border-radius:22px;transition:.3s;}
.farm-toggle-slider::before{position:absolute;content:'';height:16px;width:16px;left:3px;bottom:3px;background:white;transition:.3s;border-radius:50%;}
.farm-toggle input:checked + .farm-toggle-slider{background:var(--fp);}
.farm-toggle input:checked + .farm-toggle-slider::before{transform:translateX(24px);}
.farm-perm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;}
.farm-perm-item{background:rgba(255,255,255,.05);padding:12px;border-radius:10px;border:1px solid var(--fgb);}
.farm-perm-hdr{display:flex;justify-content:space-between;align-items:center;}
.farm-backup-item{background:rgba(255,255,255,.04);padding:16px;border-radius:10px;border:1px solid var(--fgb);margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;}
.farm-integ-card{background:rgba(255,255,255,.04);padding:16px;border-radius:10px;border:1px solid var(--fgb);text-align:center;transition:all .2s;}
.farm-integ-card:hover{border-color:var(--fp);transform:translateY(-2px);}
.farm-integ-ico{font-size:2rem;margin-bottom:8px;}
.farm-integ-name{font-weight:600;margin-bottom:6px;font-size:.85rem;}
.farm-integ-status{font-size:.72rem;padding:3px 10px;border-radius:10px;display:inline-block;}
.farm-integ-status.ok{background:rgba(10,207,151,.2);color:var(--fs);}
.farm-integ-status.off{background:rgba(250,92,124,.2);color:var(--fd);}
.farm-api-endpoint{background:var(--fg);border:1px solid var(--fgb);border-radius:10px;padding:12px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;}
.farm-api-method{padding:3px 10px;border-radius:6px;font-size:.7rem;font-weight:700;margin-right:8px;}
.farm-api-method.get{background:rgba(10,207,151,.2);color:var(--fs);}
.farm-api-method.post{background:rgba(114,124,245,.2);color:var(--fp);}
.farm-api-method.put{background:rgba(255,188,0,.2);color:var(--fw);}
.farm-api-method.del{background:rgba(250,92,124,.2);color:var(--fd);}
.farm-api-path{font-family:monospace;font-size:.85rem;}
.farm-cache-stat{background:var(--fg);border:1px solid var(--fgb);border-radius:10px;padding:16px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;}
.farm-cache-val{font-size:1.3rem;font-weight:700;color:var(--fp);}
.farm-review-card{background:var(--fg);border:1px solid var(--fgb);border-radius:12px;padding:16px;margin-bottom:12px;}
.farm-review-hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;}
.farm-store-card{background:var(--fg);border:1px solid var(--fgb);border-radius:12px;padding:20px;transition:all .2s;}
.farm-store-card:hover{transform:translateY(-4px);border-color:var(--fp);}
.farm-store-hdr{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;}
.farm-store-stats{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:12px;}
.farm-store-stat{text-align:center;padding:8px;background:rgba(255,255,255,.05);border-radius:8px;}
.farm-store-stat-val{font-size:1.1rem;font-weight:700;color:var(--fp);}
.farm-store-stat-lbl{font-size:.72rem;opacity:.65;}
.farm-chat-container{display:grid;grid-template-columns:260px 1fr;gap:16px;height:480px;}
.farm-chat-sidebar{background:var(--fg);border:1px solid var(--fgb);border-radius:12px;padding:14px;overflow-y:auto;}
.farm-chat-main{background:var(--fg);border:1px solid var(--fgb);border-radius:12px;display:flex;flex-direction:column;}
.farm-chat-hdr{padding:14px;border-bottom:1px solid var(--fgb);}
.farm-chat-msgs{flex:1;padding:14px;overflow-y:auto;display:flex;flex-direction:column;gap:10px;}
.farm-chat-inp{padding:12px;border-top:1px solid var(--fgb);display:flex;gap:8px;}
.farm-chat-inp input{flex:1;padding:10px;background:rgba(255,255,255,.08);border:1px solid var(--fgb);border-radius:9px;color:inherit;font-family:inherit;outline:none;}
.farm-chat-user{padding:10px;border-radius:8px;margin-bottom:6px;cursor:pointer;transition:all .2s;display:flex;align-items:center;gap:10px;}
.farm-chat-user:hover,.farm-chat-user.active{background:rgba(114,124,245,.2);}
.farm-chat-user-av{width:40px;height:40px;border-radius:50%;background:var(--fp);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.8rem;flex-shrink:0;}
.farm-msg{display:flex;gap:8px;align-items:flex-start;}
.farm-msg.sent{flex-direction:row-reverse;}
.farm-msg-av{width:36px;height:36px;border-radius:50%;background:var(--fp);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.75rem;flex-shrink:0;}
.farm-msg-content{background:rgba(255,255,255,.08);padding:10px;border-radius:10px;max-width:70%;}
.farm-msg.sent .farm-msg-content{background:var(--fp);}
.farm-msg-text{font-size:.85rem;margin-bottom:3px;}
.farm-msg-time{font-size:.68rem;opacity:.6;}
.farm-doc-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;}
.farm-doc-card{background:var(--fg);border:1px solid var(--fgb);border-radius:12px;padding:16px;text-align:center;cursor:pointer;transition:all .2s;}
.farm-doc-card:hover{transform:translateY(-4px);border-color:var(--fp);}
.farm-doc-ico{font-size:2.5rem;margin-bottom:8px;color:var(--fp);}
.farm-doc-name{font-weight:600;font-size:.85rem;margin-bottom:4px;}
.farm-doc-size{font-size:.75rem;opacity:.6;}
.farm-calendar-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:4px;margin-top:12px;}
.farm-cal-day-hdr{padding:8px;text-align:center;font-weight:700;font-size:.75rem;opacity:.65;}
.farm-cal-day{padding:8px;text-align:center;border-radius:8px;cursor:pointer;min-height:52px;background:rgba(255,255,255,.03);transition:all .2s;}
.farm-cal-day:hover{background:rgba(114,124,245,.18);}
.farm-cal-day.today{background:var(--fp);font-weight:700;}
.farm-cal-day.has-event{border:2px solid var(--fw);}
.farm-cal-day-num{font-size:.85rem;margin-bottom:4px;}
.farm-cal-event{font-size:.65rem;padding:2px 4px;background:rgba(255,188,0,.25);border-radius:4px;}
.farm-ticket-item{padding:16px;background:rgba(255,255,255,.04);border-radius:10px;border:1px solid var(--fgb);margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;}
.farm-leave-item{padding:12px;background:rgba(255,255,255,.04);border-radius:10px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;}
.farm-leave-status{padding:3px 10px;border-radius:10px;font-size:.72rem;font-weight:700;}
.farm-leave-status.ok{background:rgba(10,207,151,.2);color:var(--fs);}
.farm-leave-status.pend{background:rgba(255,188,0,.2);color:var(--fw);}
.farm-invoice-item{padding:12px;background:rgba(255,255,255,.05);border-radius:10px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;border:1px solid var(--fgb);}
.farm-inv-status{padding:4px 10px;border-radius:10px;font-size:.72rem;font-weight:700;}
.farm-inv-paid{background:rgba(10,207,151,.2);color:var(--fs);}
.farm-inv-pend{background:rgba(255,188,0,.2);color:var(--fw);}
.farm-inv-over{background:rgba(250,92,124,.2);color:var(--fd);}
.farm-search-box{position:relative;margin-bottom:16px;}
.farm-search-box input{width:100%;padding:10px 40px 10px 12px;background:rgba(255,255,255,.08);border:1px solid var(--fgb);border-radius:10px;font-size:.88rem;color:inherit;font-family:inherit;outline:none;}
.farm-search-box input::placeholder{color:rgba(255,255,255,.45);}
#farm-wrapper.light .farm-search-box input{color:#1a1f2e;}
.farm-employee-card{background:var(--fg);border:1px solid var(--fgb);border-radius:12px;padding:16px;text-align:center;transition:all .2s;}
.farm-employee-card:hover{transform:translateY(-4px);border-color:var(--fp);}
.farm-emp-av{width:70px;height:70px;border-radius:50%;margin:0 auto 12px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;font-weight:700;color:white;}
.farm-emp-name{font-weight:700;margin-bottom:3px;}
.farm-emp-role{font-size:.8rem;opacity:.65;margin-bottom:6px;}
.farm-emp-sal{font-size:1rem;color:var(--fs);font-weight:700;}
.farm-notif-dropdown{position:fixed;top:70px;right:16px;width:320px;background:rgba(15,20,25,.97);border:1px solid var(--fgb);border-radius:12px;padding:14px;z-index:100;box-shadow:var(--fsh);}
.farm-notif-item{padding:10px;border-radius:8px;margin-bottom:6px;background:rgba(255,255,255,.05);cursor:pointer;transition:all .2s;border-left:3px solid transparent;}
.farm-notif-item:hover{background:rgba(114,124,245,.15);}
.farm-notif-item.unread{border-left-color:var(--fp);}
.farm-floating{position:fixed;bottom:24px;right:24px;z-index:50;}
.farm-fab{width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,var(--fp),var(--fpd));border:none;color:white;font-size:1.4rem;cursor:pointer;box-shadow:0 6px 20px rgba(114,124,245,.5);display:flex;align-items:center;justify-content:center;transition:all .2s;}
.farm-fab:hover{transform:scale(1.05);}
.farm-chart-placeholder{height:260px;background:rgba(255,255,255,.03);border-radius:12px;display:flex;align-items:center;justify-content:center;border:1px dashed var(--fgb);color:rgba(255,255,255,.3);font-size:.9rem;}
.farm-progress-bar{width:100%;height:5px;background:rgba(255,255,255,.1);border-radius:3px;overflow:hidden;margin-top:8px;}
.farm-progress-fill{height:100%;background:linear-gradient(90deg,var(--fp),var(--fi));border-radius:3px;transition:width .5s ease;}
.farm-perf-card{background:var(--fg);border:1px solid var(--fgb);border-radius:12px;padding:16px;margin-bottom:12px;}
.farm-perf-score{font-size:1.8rem;font-weight:700;color:var(--fp);}
.farm-perf-metrics{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px;}
.farm-perf-metric{text-align:center;padding:8px;background:rgba(255,255,255,.05);border-radius:8px;}
.farm-perf-metric-val{font-size:.95rem;font-weight:700;}
.farm-perf-metric-lbl{font-size:.7rem;opacity:.65;}
.farm-caixa-item{padding:12px;background:rgba(255,255,255,.04);border-radius:10px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;}
@media(max-width:900px){
  .farm-pos{grid-template-columns:1fr;}
  .farm-sidebar{width:220px;}
  .farm-chat-container{grid-template-columns:1fr;}
  .farm-stats{grid-template-columns:1fr 1fr;}
}
@media(max-width:600px){
  .farm-sidebar{display:none;}
  .farm-stats{grid-template-columns:1fr;}
}
`;
