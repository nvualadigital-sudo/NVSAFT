import { createContext,useContext } from "react";
import type { useFarmacia } from "./useFarmacia";
export type FarmaciaState=ReturnType<typeof useFarmacia>;
export const FarmaciaContext=createContext<FarmaciaState|null>(null);
export function useFarmaciaContext(){const value=useContext(FarmaciaContext);if(!value)throw new Error("Componente fora da Farmácia");return value;}
