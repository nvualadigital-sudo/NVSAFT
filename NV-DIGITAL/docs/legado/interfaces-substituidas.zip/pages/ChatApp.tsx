import { useEffect, useRef, useState } from "react";

interface ChatSession { empresaId?: string; funcionarioId?: string; funcionarioNome?: string; username?: string; }
interface ChatAppProps { session?: ChatSession; }
interface Chat { id: number; name: string; preview: string; time: string; unread: number; av: number; type: string; call?: boolean; }
interface Message { text: string; type: "sent" | "received"; time: string; }
// Contactos e chamadas de exemplo preservados do HTML. Nenhuma mensagem é enviada a terceiros.
const INITIAL_CHATS: Chat[] = [
  {
    "name": "Colega",
    "preview": "De boas, e aí?",
    "time": "14:45",
    "unread": 1,
    "av": 1,
    "type": "individual",
    "id": 0
  },
  {
    "name": "TIPAGEM ABO",
    "preview": "Já transferi",
    "time": "14:44",
    "unread": 2,
    "av": 2,
    "type": "individual",
    "id": 1
  },
  {
    "name": "Recepção LAICISA",
    "preview": "Boss!",
    "time": "14:43",
    "unread": 0,
    "av": 3,
    "type": "individual",
    "id": 2
  },
  {
    "name": "MAMY SAKA",
    "preview": "🤣😂🤣 SERIA MUIATO BOM",
    "time": "13:43",
    "unread": 0,
    "av": 4,
    "type": "individual",
    "id": 3
  },
  {
    "name": "COMBO ISPEKA",
    "preview": "Valeu bossita!",
    "time": "10:50",
    "unread": 0,
    "av": 5,
    "type": "group",
    "id": 4
  },
  {
    "name": "Álvaro Gomes",
    "preview": "Mano tens as provas passadas da mana Ana?",
    "time": "09:09",
    "unread": 0,
    "av": 6,
    "type": "individual",
    "id": 5
  },
  {
    "name": "+244 974 852 614",
    "preview": "é o Domingos Brother!",
    "time": "09:08",
    "unread": 0,
    "av": 7,
    "type": "individual",
    "id": 6
  },
  {
    "name": "+244 933 595 350",
    "preview": "Chamada de voz",
    "time": "Ontem",
    "unread": 0,
    "av": 8,
    "type": "individual",
    "call": true,
    "id": 7
  },
  {
    "name": "+244 940 886 478",
    "preview": "Man qual o meno de Hoje?",
    "time": "Ontem",
    "unread": 0,
    "av": 9,
    "type": "individual",
    "id": 8
  },
  {
    "name": "Pf Wander",
    "preview": "Já anda aqui mano!",
    "time": "Ontem",
    "unread": 0,
    "av": 10,
    "type": "individual",
    "id": 9
  },
  {
    "name": "Àuria",
    "preview": "Envia do Álvaro",
    "time": "Ontem",
    "unread": 0,
    "av": 1,
    "type": "individual",
    "id": 10
  },
  {
    "name": "Isa pv",
    "preview": "Não entendi nada",
    "time": "Ontem",
    "unread": 0,
    "av": 2,
    "type": "individual",
    "id": 11
  },
  {
    "name": "Quissanga",
    "preview": "Valeu boss!",
    "time": "Ontem",
    "unread": 0,
    "av": 3,
    "type": "individual",
    "id": 12
  },
  {
    "name": "Lukoki PEVERIELA",
    "preview": "Esta mensagem foi eliminada",
    "time": "Terça-feira",
    "unread": 0,
    "av": 4,
    "type": "individual",
    "id": 13
  },
  {
    "name": "Janeth NVUALA",
    "preview": "Dmk",
    "time": "Terça-feira",
    "unread": 0,
    "av": 5,
    "type": "individual",
    "id": 14
  },
  {
    "name": "+244 931 010 182",
    "preview": "ficha-candidato-TDTM-046999.pdf",
    "time": "Terça-feira",
    "unread": 0,
    "av": 6,
    "type": "individual",
    "id": 15
  },
  {
    "name": "Mário",
    "preview": "Uige mano",
    "time": "Segunda-feira",
    "unread": 0,
    "av": 7,
    "type": "individual",
    "id": 16
  },
  {
    "name": "futilablaboratoriodeanalisescl",
    "preview": "Aguardando Dr/a",
    "time": "Segunda-feira",
    "unread": 0,
    "av": 8,
    "type": "individual",
    "id": 17
  },
  {
    "name": "Pastor Daniel",
    "preview": "Reagiu ✅ a: \"Amém--!\"",
    "time": "11/07/2026",
    "unread": 0,
    "av": 9,
    "type": "individual",
    "id": 18
  },
  {
    "name": "ULISSES 2",
    "preview": "O concurso se aproxima!",
    "time": "11/07/2026",
    "unread": 1,
    "av": 10,
    "type": "individual",
    "id": 19
  },
  {
    "name": "+244 942 759 552",
    "preview": "valeu mano",
    "time": "11/07/2026",
    "unread": 0,
    "av": 1,
    "type": "individual",
    "id": 20
  },
  {
    "name": "+244 940 373 724",
    "preview": "Valeu boss!",
    "time": "09/07/2026",
    "unread": 0,
    "av": 2,
    "type": "individual",
    "id": 21
  },
  {
    "name": "+244 921 935 514",
    "preview": "Esta bem... para facilitar meu tempo",
    "time": "09/07/2026",
    "unread": 0,
    "av": 3,
    "type": "individual",
    "id": 22
  },
  {
    "name": "+244 934 291 659",
    "preview": "Bom dia sra. ! Podemos sim dar continuidade",
    "time": "09/07/2026",
    "unread": 0,
    "av": 4,
    "type": "individual",
    "id": 23
  },
  {
    "name": "Explicação de Hematologia",
    "preview": "~Florinda Seke: Este exercício é da outra série",
    "time": "07/07/2026",
    "unread": 0,
    "av": 5,
    "type": "group",
    "id": 24
  },
  {
    "name": "Meta AI",
    "preview": "Pronto. Trabalhei a vibração e deixei com cara de foto profissional",
    "time": "07/07/2026",
    "unread": 2,
    "av": 10,
    "type": "individual",
    "id": 25
  },
  {
    "name": "SUZANA LAICISA",
    "preview": "Lhe passa o meu número!",
    "time": "06/07/2026",
    "unread": 0,
    "av": 6,
    "type": "individual",
    "id": 26
  },
  {
    "name": "LAICISA Calemba2",
    "preview": "😍",
    "time": "06/07/2026",
    "unread": 0,
    "av": 7,
    "type": "individual",
    "id": 27
  },
  {
    "name": "ISRAEL",
    "preview": "Volto às 8h, mano",
    "time": "04/07/2026",
    "unread": 1,
    "av": 8,
    "type": "individual",
    "id": 28
  },
  {
    "name": "Dorany",
    "preview": "De boas, e aí?",
    "time": "04/07/2026",
    "unread": 1,
    "av": 9,
    "type": "individual",
    "id": 29
  },
  {
    "name": "UltraCardio (funcionários)",
    "preview": "Sticker",
    "time": "24/06/2026",
    "unread": 0,
    "av": 10,
    "type": "group",
    "id": 30
  },
  {
    "name": "manuel",
    "preview": "Estou bem mano e aí?",
    "time": "23/06/2026",
    "unread": 0,
    "av": 1,
    "type": "individual",
    "id": 31
  },
  {
    "name": "Lauriana Priii❤️",
    "preview": "Estou bem aí?",
    "time": "23/06/2026",
    "unread": 0,
    "av": 2,
    "type": "individual",
    "id": 32
  },
  {
    "name": "Miguel Adn",
    "preview": "Reagiu 👏 a: \"Gostei 👏\"",
    "time": "16/06/2026",
    "unread": 0,
    "av": 3,
    "type": "individual",
    "id": 33
  },
  {
    "name": "+244 957 181 975",
    "preview": "Recebido Boss",
    "time": "13/06/2026",
    "unread": 0,
    "av": 4,
    "type": "individual",
    "id": 34
  },
  {
    "name": "+244 934 894 540",
    "preview": "Que bom 😸",
    "time": "11/06/2026",
    "unread": 0,
    "av": 5,
    "type": "individual",
    "id": 35
  },
  {
    "name": "Daniel Colega",
    "preview": "Mano como estás?",
    "time": "11/06/2026",
    "unread": 0,
    "av": 6,
    "type": "individual",
    "id": 36
  },
  {
    "name": "+244 931 343 421",
    "preview": "Muito obrigada",
    "time": "09/06/2026",
    "unread": 0,
    "av": 7,
    "type": "individual",
    "id": 37
  }
];
const CALLS: {name:string;type:string;time:string;count?:number}[] = [
  {
    "name": "COMBO ISPEKA",
    "type": "video-out",
    "time": "10:26"
  },
  {
    "name": "COMBO ISPEKA",
    "type": "video-in",
    "time": "10:24",
    "count": 2
  },
  {
    "name": "COMBO ISPEKA",
    "type": "video-out",
    "time": "10:22"
  },
  {
    "name": "+244 933 595 350",
    "type": "voice-out",
    "time": "Ontem"
  },
  {
    "name": "+244 933 595 350",
    "type": "voice-out",
    "time": "Ontem"
  },
  {
    "name": "+244 921 207 720",
    "type": "missed",
    "time": "Terça-feira",
    "count": 2
  },
  {
    "name": "+244 948 107 942",
    "type": "missed",
    "time": "Terça-feira"
  },
  {
    "name": "+244 921 207 720",
    "type": "missed",
    "time": "Terça-feira"
  },
  {
    "name": "COL SANDRA",
    "type": "missed",
    "time": "Segunda-feira"
  },
  {
    "name": "Álvaro Gomes",
    "type": "received",
    "time": "Segunda-feira"
  }
];
const EMOJIS = ["😀","😂","🤣","😊","😍","😘","😉","😎","🙌","👍","👏","🙏","🔥","❤️","💪","🎉","😢","😮","😡","🤔","👌","✅","🥳","🤗","😴","😇","😅","🙃","😏","🤩","😳","🙄"];
const CHAT_CSS = ".laicisa-chat{\n    --splashscreen-startup-background: #F7F5F3;\n    --WDS-green-400: #25d366;\n    --WDS-green-450: #21c063;\n    --WDS-green-500: #1daa61;\n    --WDS-green-700: #15603e;\n    --WDS-accent: #1DAA61;\n    --WDS-accent-deemphasized: #D9FDD3;\n    --WDS-surface-emphasized: #F7F5F3;\n    --WDS-surface-default: #FFFFFF;\n    --WDS-background-wash-inset: #F7F5F3;\n    --WDS-background-wash-plain: #FFFFFF;\n    --WDS-content-default: #0A0A0A;\n    --WDS-content-deemphasized: rgba(0, 0, 0, .6);\n    --WDS-content-disabled: #BDBDBD;\n    --WDS-lines-divider: rgba(0, 0, 0, .1);\n    --WDS-lines-outline-default: #959393;\n    --WDS-persistent-always-white: #FFFFFF;\n    --WDS-neutral-gray-50: #fafafa;\n    --WDS-neutral-gray-100: #eeeeee;\n    --WDS-neutral-gray-400: #959393;\n    --WDS-neutral-gray-500: #757778;\n    --WDS-neutral-gray-700: #424445;\n    --WDS-neutral-gray-800: #242626;\n    --WDS-neutral-gray-1000: #0a0a0a;\n    --WDS-cool-gray-200: #d4d6d8;\n    --WDS-warm-gray-75: #f7f5f3;\n    --WDS-warm-gray-100: #f1eeeb;\n    --WDS-warm-gray-200: #dbd8d4;\n    --WDS-warm-gray-300: #c2bdb8;\n    --WDS-warm-gray-300-alpha-15: rgba(194, 189, 184, .15);\n    --navbar-width: 72px;\n    --font-family: system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif;\n}\n.laicisa-chat.chat-dark{\n    --WDS-surface-emphasized: #202c33;\n    --WDS-surface-default: #111b21;\n    --WDS-background-wash-inset: #0b141a;\n    --WDS-background-wash-plain: #0b141a;\n    --WDS-content-default: #e9edef;\n    --WDS-content-deemphasized: rgba(233, 237, 239, .6);\n    --WDS-lines-divider: rgba(134, 150, 160, .15);\n    --WDS-warm-gray-75: #202c33;\n    --WDS-warm-gray-100: #202c33;\n    --WDS-warm-gray-200: #2a3942;\n    --WDS-warm-gray-300: #3b4a54;\n    --WDS-warm-gray-300-alpha-15: rgba(134, 150, 160, .15);\n    --WDS-neutral-gray-1000: #e9edef;\n    --WDS-neutral-gray-500: #aebac1;\n    --WDS-neutral-gray-400: #8696a0;\n    --WDS-neutral-gray-100: #2a3942;\n    --WDS-neutral-gray-800: #111b21;\n}\n.laicisa-chat *{\n    margin: 0;\n    padding: 0;\n    box-sizing: border-box;\n}\n.laicisa-chat, .laicisa-chat{\n    height: 100%;\n    overflow: hidden;\n    font-family: var(--font-family);\n    background: var(--WDS-background-wash-inset);\n    color: var(--WDS-content-default);\n}\n.laicisa-chat .app-wrapper{\n    display: flex;\n    height: 100%;\n    width: 100%;\n    background: var(--WDS-background-wash-plain);\n}\n.laicisa-chat .navbar{\n    width: var(--navbar-width);\n    background: var(--WDS-surface-emphasized);\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    padding: 12px 0;\n    border-right: 1px solid var(--WDS-lines-divider);\n    flex-shrink: 0;\n}\n.laicisa-chat .nav-logo{\n    width: 36px;\n    height: 36px;\n    margin-bottom: 16px;\n    cursor: pointer;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n}\n.laicisa-chat .nav-logo svg{\n    width: 32px;\n    height: 32px;\n    fill: var(--WDS-green-500);\n}\n.laicisa-chat .nav-items{\n    display: flex;\n    flex-direction: column;\n    gap: 4px;\n    flex: 1;\n    width: 100%;\n    padding: 0 10px;\n}\n.laicisa-chat .nav-item{\n    width: 52px;\n    height: 52px;\n    border-radius: 50%;\n    border: none;\n    background: transparent;\n    cursor: pointer;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    position: relative;\n    color: var(--WDS-neutral-gray-500);\n    transition: background .15s;\n}\n.laicisa-chat .nav-item:hover{\n    background: var(--WDS-warm-gray-300-alpha-15);\n}\n.laicisa-chat .nav-item.active{\n    background: var(--WDS-warm-gray-300-alpha-15);\n    color: var(--WDS-green-500);\n}\n.laicisa-chat .nav-item svg{\n    width: 24px;\n    height: 24px;\n    fill: currentColor;\n}\n.laicisa-chat .nav-badge{\n    position: absolute;\n    top: 6px;\n    right: 6px;\n    min-width: 18px;\n    height: 18px;\n    padding: 0 5px;\n    border-radius: 9px;\n    background: var(--WDS-green-500);\n    color: white;\n    font-size: 11px;\n    font-weight: 600;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n}\n.laicisa-chat .nav-badge.hidden{\n    display: none;\n}\n.laicisa-chat .nav-footer{\n    display: flex;\n    flex-direction: column;\n    gap: 8px;\n    padding: 0 10px;\n    width: 100%;\n}\n.laicisa-chat .nav-avatar{\n    width: 40px;\n    height: 40px;\n    border-radius: 50%;\n    background: linear-gradient(135deg, #667eea, #764ba2);\n    margin: 0 auto;\n    cursor: pointer;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: white;\n    font-weight: 600;\n    font-size: 16px;\n}\n.laicisa-chat .main-panel{\n    flex: 1;\n    display: flex;\n    flex-direction: column;\n    min-width: 0;\n    max-width: 520px;\n    background: var(--WDS-surface-default);\n}\n.laicisa-chat .panel-header{\n    height: 60px;\n    padding: 0 16px;\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    border-bottom: 1px solid var(--WDS-lines-divider);\n    flex-shrink: 0;\n}\n.laicisa-chat .panel-title{\n    font-size: 20px;\n    font-weight: 600;\n    color: var(--WDS-content-default);\n}\n.laicisa-chat .header-actions{\n    display: flex;\n    gap: 4px;\n}\n.laicisa-chat .icon-btn{\n    width: 36px;\n    height: 36px;\n    border-radius: 50%;\n    border: none;\n    background: transparent;\n    cursor: pointer;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: var(--WDS-neutral-gray-500);\n    transition: background .15s;\n}\n.laicisa-chat .icon-btn:hover{\n    background: var(--WDS-warm-gray-300-alpha-15);\n}\n.laicisa-chat .icon-btn svg{\n    width: 20px;\n    height: 20px;\n    fill: currentColor;\n}\n.laicisa-chat .search-box{\n    padding: 8px 12px;\n    border-bottom: 1px solid var(--WDS-lines-divider);\n}\n.laicisa-chat .search-input-wrap{\n    display: flex;\n    align-items: center;\n    gap: 12px;\n    background: var(--WDS-warm-gray-300-alpha-15);\n    border-radius: 8px;\n    padding: 6px 12px;\n    height: 36px;\n}\n.laicisa-chat .search-input-wrap svg{\n    width: 18px;\n    height: 18px;\n    fill: var(--WDS-neutral-gray-500);\n    flex-shrink: 0;\n}\n.laicisa-chat .search-input{\n    flex: 1;\n    border: none;\n    background: transparent;\n    outline: none;\n    font-size: 14px;\n    color: var(--WDS-content-default);\n    font-family: inherit;\n}\n.laicisa-chat .search-input::placeholder{\n    color: var(--WDS-content-deemphasized);\n}\n.laicisa-chat .search-clear{\n    border: none;\n    background: transparent;\n    cursor: pointer;\n    display: none;\n    align-items: center;\n    justify-content: center;\n    color: var(--WDS-neutral-gray-500);\n}\n.laicisa-chat .search-clear.show{ display: flex; }\n.laicisa-chat .search-clear svg{ width: 16px; height: 16px; fill: currentColor; }\n.laicisa-chat .filters{\n    display: flex;\n    gap: 8px;\n    padding: 8px 12px;\n    border-bottom: 1px solid var(--WDS-lines-divider);\n    overflow-x: auto;\n    flex-shrink: 0;\n}\n.laicisa-chat .filters::-webkit-scrollbar{\n    display: none;\n}\n.laicisa-chat .filter-btn{\n    padding: 6px 14px;\n    border-radius: 18px;\n    border: none;\n    background: var(--WDS-warm-gray-300-alpha-15);\n    color: var(--WDS-content-default);\n    font-size: 13px;\n    font-weight: 500;\n    cursor: pointer;\n    white-space: nowrap;\n    transition: all .15s;\n    font-family: inherit;\n}\n.laicisa-chat .filter-btn:hover{\n    background: var(--WDS-warm-gray-200);\n}\n.laicisa-chat .filter-btn.active{\n    background: var(--WDS-accent-deemphasized);\n    color: var(--WDS-green-700);\n}\n.laicisa-chat .dark .filter-btn.active{\n    color: var(--WDS-green-400);\n}\n.laicisa-chat .chat-list{\n    flex: 1;\n    overflow-y: auto;\n    overflow-x: hidden;\n}\n.laicisa-chat .chat-list::-webkit-scrollbar{\n    width: 6px;\n}\n.laicisa-chat .chat-list::-webkit-scrollbar-track{\n    background: transparent;\n}\n.laicisa-chat .chat-list::-webkit-scrollbar-thumb{\n    background: var(--WDS-warm-gray-300);\n    border-radius: 3px;\n}\n.laicisa-chat .chat-item{\n    display: flex;\n    align-items: center;\n    gap: 12px;\n    padding: 10px 14px;\n    cursor: pointer;\n    transition: background .1s;\n    border-bottom: 1px solid var(--WDS-lines-divider);\n    position: relative;\n}\n.laicisa-chat .chat-item:hover{\n    background: var(--WDS-warm-gray-300-alpha-15);\n}\n.laicisa-chat .chat-item.active{\n    background: var(--WDS-warm-gray-300-alpha-15);\n}\n.laicisa-chat .chat-avatar{\n    width: 49px;\n    height: 49px;\n    border-radius: 50%;\n    flex-shrink: 0;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: white;\n    font-weight: 600;\n    font-size: 18px;\n    overflow: hidden;\n}\n.laicisa-chat .chat-avatar img{\n    width: 100%;\n    height: 100%;\n    object-fit: cover;\n}\n.laicisa-chat .chat-info{\n    flex: 1;\n    min-width: 0;\n    display: flex;\n    flex-direction: column;\n    gap: 4px;\n}\n.laicisa-chat .chat-top{\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n    gap: 8px;\n}\n.laicisa-chat .chat-name{\n    font-size: 16px;\n    font-weight: 400;\n    color: var(--WDS-content-default);\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    flex: 1;\n}\n.laicisa-chat .chat-time{\n    font-size: 12px;\n    color: var(--WDS-content-deemphasized);\n    white-space: nowrap;\n    flex-shrink: 0;\n}\n.laicisa-chat .chat-item.unread .chat-time{\n    color: var(--WDS-green-500);\n    font-weight: 600;\n}\n.laicisa-chat .chat-bottom{\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n    gap: 8px;\n}\n.laicisa-chat .chat-preview{\n    font-size: 14px;\n    color: var(--WDS-content-deemphasized);\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    flex: 1;\n    display: flex;\n    align-items: center;\n    gap: 4px;\n}\n.laicisa-chat .chat-preview svg{\n    width: 18px;\n    height: 18px;\n    fill: var(--WDS-content-deemphasized);\n    flex-shrink: 0;\n}\n.laicisa-chat .chat-item.unread .chat-preview{\n    color: var(--WDS-content-default);\n    font-weight: 500;\n}\n.laicisa-chat .chat-item.unread .chat-preview svg{\n    fill: var(--WDS-green-500);\n}\n.laicisa-chat .unread-badge{\n    min-width: 20px;\n    height: 20px;\n    padding: 0 6px;\n    border-radius: 10px;\n    background: var(--WDS-green-500);\n    color: white;\n    font-size: 12px;\n    font-weight: 600;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    flex-shrink: 0;\n}\n.laicisa-chat .section-header{\n    padding: 12px 16px 6px;\n    font-size: 14px;\n    font-weight: 600;\n    color: var(--WDS-content-default);\n    background: var(--WDS-surface-default);\n}\n.laicisa-chat .no-results{\n    padding: 40px 20px;\n    text-align: center;\n    color: var(--WDS-content-deemphasized);\n    font-size: 14px;\n}\n.laicisa-chat .archived-btn{\n    display: flex;\n    align-items: center;\n    gap: 24px;\n    padding: 12px 16px;\n    cursor: pointer;\n    border-bottom: 1px solid var(--WDS-lines-divider);\n    transition: background .1s;\n}\n.laicisa-chat .archived-btn:hover{\n    background: var(--WDS-warm-gray-300-alpha-15);\n}\n.laicisa-chat .archived-btn svg{\n    width: 24px;\n    height: 24px;\n    fill: var(--WDS-neutral-gray-500);\n}\n.laicisa-chat .archived-btn span{\n    font-size: 15px;\n    color: var(--WDS-content-default);\n    flex: 1;\n}\n.laicisa-chat .archived-count{\n    font-size: 14px;\n    color: var(--WDS-content-deemphasized);\n}\n.laicisa-chat .e2e-message{\n    padding: 12px 16px;\n    display: flex;\n    align-items: center;\n    gap: 8px;\n    background: var(--WDS-warm-gray-300-alpha-15);\n    border-bottom: 1px solid var(--WDS-lines-divider);\n    font-size: 12px;\n    color: var(--WDS-content-deemphasized);\n}\n.laicisa-chat .e2e-message svg{\n    width: 14px;\n    height: 14px;\n    fill: currentColor;\n    flex-shrink: 0;\n}\n.laicisa-chat .e2e-message a{\n    color: var(--WDS-green-500);\n    text-decoration: none;\n}\n.laicisa-chat .chat-view{\n    flex: 1;\n    display: flex;\n    flex-direction: column;\n    background: var(--WDS-background-wash-inset);\n    min-width: 0;\n    position: relative;\n}\n.laicisa-chat .chat-view-header{\n    height: 60px;\n    padding: 0 16px;\n    display: flex;\n    align-items: center;\n    gap: 12px;\n    background: var(--WDS-surface-emphasized);\n    border-bottom: 1px solid var(--WDS-lines-divider);\n    flex-shrink: 0;\n}\n.laicisa-chat .chat-view-avatar{\n    width: 40px;\n    height: 40px;\n    border-radius: 50%;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: white;\n    font-weight: 600;\n    flex-shrink: 0;\n}\n.laicisa-chat .chat-view-info{\n    flex: 1;\n    min-width: 0;\n    cursor: pointer;\n}\n.laicisa-chat .chat-view-name{\n    font-size: 16px;\n    font-weight: 500;\n    color: var(--WDS-content-default);\n}\n.laicisa-chat .chat-view-status{\n    font-size: 13px;\n    color: var(--WDS-content-deemphasized);\n}\n.laicisa-chat .chat-view-actions{\n    display: flex;\n    gap: 4px;\n}\n.laicisa-chat .back-btn{\n    display: none;\n}\n.laicisa-chat .messages-area{\n    flex: 1;\n    overflow-y: auto;\n    padding: 20px 60px;\n    display: flex;\n    flex-direction: column;\n    gap: 4px;\n    background-image: \n        radial-gradient(circle at 20% 30%, rgba(37, 211, 102, 0.03) 0%, transparent 50%),\n        radial-gradient(circle at 80% 70%, rgba(37, 211, 102, 0.03) 0%, transparent 50%);\n}\n.laicisa-chat .messages-area::-webkit-scrollbar{\n    width: 6px;\n}\n.laicisa-chat .messages-area::-webkit-scrollbar-thumb{\n    background: var(--WDS-warm-gray-300);\n    border-radius: 3px;\n}\n.laicisa-chat .date-separator{\n    align-self: center;\n    padding: 6px 12px;\n    background: var(--WDS-surface-emphasized);\n    border-radius: 8px;\n    font-size: 12px;\n    color: var(--WDS-content-deemphasized);\n    margin: 12px 0;\n    box-shadow: 0 1px 1px rgba(0,0,0,0.05);\n}\n.laicisa-chat .message{\n    max-width: 65%;\n    padding: 6px 10px 8px;\n    border-radius: 8px;\n    position: relative;\n    font-size: 14.2px;\n    line-height: 19px;\n    word-wrap: break-word;\n    box-shadow: 0 1px 0.5px rgba(0,0,0,0.08);\n}\n.laicisa-chat .message.received{\n    background: var(--WDS-surface-default);\n    align-self: flex-start;\n    border-top-left-radius: 0;\n}\n.laicisa-chat .message.sent{\n    background: var(--WDS-accent-deemphasized);\n    align-self: flex-end;\n    border-top-right-radius: 0;\n}\n.laicisa-chat .dark .message.sent{\n    background: #005c4b;\n}\n.laicisa-chat .message-text{\n    color: var(--WDS-content-default);\n    padding-right: 55px;\n    white-space: pre-wrap;\n}\n.laicisa-chat .message-meta{\n    position: absolute;\n    bottom: 4px;\n    right: 8px;\n    display: flex;\n    align-items: center;\n    gap: 3px;\n    font-size: 11px;\n    color: var(--WDS-content-deemphasized);\n}\n.laicisa-chat .message-meta svg{\n    width: 16px;\n    height: 11px;\n    fill: var(--WDS-green-500);\n}\n.laicisa-chat .composer{\n    min-height: 62px;\n    padding: 8px 16px;\n    display: flex;\n    align-items: center;\n    gap: 8px;\n    background: var(--WDS-surface-emphasized);\n    border-top: 1px solid var(--WDS-lines-divider);\n    flex-shrink: 0;\n    position: relative;\n}\n.laicisa-chat .composer-input-wrap{\n    flex: 1;\n    background: var(--WDS-surface-default);\n    border-radius: 8px;\n    padding: 9px 12px;\n    min-height: 42px;\n    display: flex;\n    align-items: center;\n}\n.laicisa-chat .composer-input{\n    flex: 1;\n    border: none;\n    background: transparent;\n    outline: none;\n    font-size: 15px;\n    color: var(--WDS-content-default);\n    font-family: inherit;\n    resize: none;\n    max-height: 100px;\n}\n.laicisa-chat .composer-input::placeholder{\n    color: var(--WDS-content-deemphasized);\n}\n.laicisa-chat .send-btn svg{ fill: var(--WDS-green-500); }\n.laicisa-chat .emoji-picker{\n    position: absolute;\n    bottom: 64px;\n    left: 8px;\n    background: var(--WDS-surface-default);\n    border: 1px solid var(--WDS-lines-divider);\n    border-radius: 10px;\n    padding: 10px;\n    display: none;\n    grid-template-columns: repeat(8, 1fr);\n    gap: 4px;\n    box-shadow: 0 4px 16px rgba(0,0,0,0.15);\n    z-index: 10;\n}\n.laicisa-chat .emoji-picker.show{ display: grid; }\n.laicisa-chat .emoji-picker button{\n    border: none;\n    background: transparent;\n    font-size: 20px;\n    cursor: pointer;\n    border-radius: 6px;\n    padding: 4px;\n    line-height: 1;\n}\n.laicisa-chat .emoji-picker button:hover{\n    background: var(--WDS-warm-gray-300-alpha-15);\n}\n.laicisa-chat .empty-state{\n    flex: 1;\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    justify-content: center;\n    padding: 40px;\n    text-align: center;\n    background: var(--WDS-warm-gray-75);\n    border-bottom: 6px solid var(--WDS-green-500);\n}\n.laicisa-chat .empty-state-icon{\n    width: 320px;\n    height: 188px;\n    margin-bottom: 40px;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n}\n.laicisa-chat .empty-state-icon svg{\n    width: 260px;\n    height: 160px;\n    fill: var(--WDS-neutral-gray-400);\n    opacity: 0.4;\n}\n.laicisa-chat .empty-state h2{\n    font-size: 32px;\n    font-weight: 300;\n    color: var(--WDS-content-default);\n    margin-bottom: 16px;\n}\n.laicisa-chat .empty-state p{\n    font-size: 14px;\n    color: var(--WDS-content-deemphasized);\n    max-width: 500px;\n    line-height: 20px;\n}\n.laicisa-chat .av-1{ background: linear-gradient(135deg, #FF6B6B, #EE5A6F); }\n.laicisa-chat .av-2{ background: linear-gradient(135deg, #4ECDC4, #44A08D); }\n.laicisa-chat .av-3{ background: linear-gradient(135deg, #FFA726, #FB8C00); }\n.laicisa-chat .av-4{ background: linear-gradient(135deg, #7E57C2, #5E35B1); }\n.laicisa-chat .av-5{ background: linear-gradient(135deg, #26C6DA, #00ACC1); }\n.laicisa-chat .av-6{ background: linear-gradient(135deg, #66BB6A, #43A047); }\n.laicisa-chat .av-7{ background: linear-gradient(135deg, #EC407A, #D81B60); }\n.laicisa-chat .av-8{ background: linear-gradient(135deg, #5C6BC0, #3949AB); }\n.laicisa-chat .av-9{ background: linear-gradient(135deg, #FF7043, #F4511E); }\n.laicisa-chat .av-10{ background: linear-gradient(135deg, #26A69A, #00897B); }\n.laicisa-chat .toast{\n    position: fixed;\n    bottom: 24px;\n    left: 50%;\n    transform: translateX(-50%) translateY(20px);\n    background: var(--WDS-neutral-gray-800);\n    color: white;\n    padding: 10px 18px;\n    border-radius: 8px;\n    font-size: 13px;\n    opacity: 0;\n    pointer-events: none;\n    transition: opacity .2s, transform .2s;\n    z-index: 100;\n}\n.laicisa-chat .toast.show{\n    opacity: 1;\n    transform: translateX(-50%) translateY(0);\n}\n@media  (max-width: 900px) {.laicisa-chat .chat-view{\n        display: none;\n    }\n.laicisa-chat .chat-view.active{\n        display: flex;\n    }\n.laicisa-chat .main-panel{\n        max-width: none;\n    }\n.laicisa-chat .main-panel.hide-on-mobile{\n        display: none;\n    }\n.laicisa-chat .back-btn{\n        display: flex;\n    }}\n@media  (max-width: 600px) {.laicisa-chat .navbar{\n        width: 60px;\n    }\n.laicisa-chat .nav-item{\n        width: 44px;\n        height: 44px;\n    }\n.laicisa-chat .messages-area{\n        padding: 12px;\n    }}\n.laicisa-chat .tab-content{\n    display: none;\n    flex: 1;\n    flex-direction: column;\n    min-height: 0;\n}\n.laicisa-chat .tab-content.active{\n    display: flex;\n}\n.laicisa-chat { height:100%; min-height:420px; width:100%; position:relative; isolation:isolate; overflow:hidden; }\n.laicisa-chat .app-wrapper {min-height:0;}\n.laicisa-chat .toast {position:absolute; max-width:85%; text-align:center;}\n.laicisa-chat .message-text {white-space:pre-wrap; overflow-wrap:anywhere;}\n.laicisa-chat .chat-item {width:100%;text-align:left;border:0;background:transparent;color:inherit;font:inherit;}\n.laicisa-chat .chat-item.active {background:var(--WDS-surface-emphasized);}\n.laicisa-chat button:focus-visible {outline:2px solid var(--WDS-accent);outline-offset:-2px;}\n";
const initial = (name: string) => name.startsWith("+") ? "📱" : name === "Meta AI" ? "✨" : name.charAt(0).toUpperCase();
const callLabel = (type: string) => ({"video-out":"Vídeo efetuada", "video-in":"Vídeo recebida", "voice-out":"Voz efetuada", "missed":"Perdida"}[type] || "Recebida");

export default function ChatApp({ session }: ChatAppProps = {}) {
  const [chats, setChats] = useState<Chat[]>(() => INITIAL_CHATS.map(chat => ({...chat})));
  const [messages, setMessages] = useState<Record<number, Message[]>>({});
  const [activeId, setActiveId] = useState<number | null>(null);
  const [section, setSection] = useState("chats");
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [callsSearch, setCallsSearch] = useState("");
  const [draft, setDraft] = useState("");
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [messageSearch, setMessageSearch] = useState("");
  const [newChatOpen, setNewChatOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [toast, setToast] = useState("");
  const [dark, setDark] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const messagesRef = useRef<HTMLDivElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const nextId = useRef(INITIAL_CHATS.length);
  const activeChat = chats.find(chat => chat.id === activeId);
  const currentMessages = activeId === null ? [] : messages[activeId] ?? [];
  const totalUnread = chats.reduce((sum, chat) => sum + chat.unread, 0);
  const favorites = INITIAL_CHATS.slice(0,5).map(chat => chat.id);
  const visibleChats = chats.filter(chat => (filter !== "unread" || chat.unread > 0) && (filter !== "groups" || chat.type === "group") && (filter !== "favorites" || favorites.includes(chat.id)) && `${chat.name} ${chat.preview}`.toLocaleLowerCase().includes(search.toLocaleLowerCase()));
  const visibleCalls = CALLS.filter(call => call.name.toLocaleLowerCase().includes(callsSearch.toLocaleLowerCase()));
  const notify = (text:string) => setToast(text);
  useEffect(() => { if(!toast) return; const timer = window.setTimeout(() => setToast(""), 3000); return () => window.clearTimeout(timer); },[toast]);
  useEffect(() => { const area=messagesRef.current; if(area) area.scrollTop=area.scrollHeight; },[messages,activeId]);
  useEffect(() => {
    const close = (event:PointerEvent) => { const target=event.target; if(target instanceof Element && !target.closest(".composer")) setEmojiOpen(false); };
    const root=rootRef.current; root?.addEventListener("pointerdown",close);
    return () => root?.removeEventListener("pointerdown",close);
  },[]);
  function openChat(id:number) {
    const chat=chats.find(item => item.id===id); if(!chat) return;
    setMessages(previous => previous[id] ? previous : {...previous,[id]:chat.preview ? [
      {text:"Olá! Tudo bem?",type:"received",time:"14:30"},
      {text:"Tudo ótimo, e contigo?",type:"sent",time:"14:32"},
      {text:chat.preview,type:"received",time:chat.time},
    ] : []});
    setChats(previous => previous.map(item => item.id===id ? {...item,unread:0} : item));
    setActiveId(id); setDraft(""); setMessageSearch(""); setSearchOpen(false); setEmojiOpen(false);
  }
  function sendMessage() {
    const text=draft.trim(); if(!text || activeId===null) return;
    const time=new Date().toLocaleTimeString("pt-PT",{hour:"2-digit",minute:"2-digit"});
    setMessages(previous => ({...previous,[activeId]:[...(previous[activeId] ?? []),{text,type:"sent",time}]}));
    setChats(previous => { const chat=previous.find(item => item.id===activeId); return chat ? [{...chat,preview:text,time},...previous.filter(item => item.id!==activeId)] : previous; });
    setDraft(""); setEmojiOpen(false); inputRef.current?.focus();
  }
  function createChat() {
    const name=newName.trim(); if(!name) return;
    const existing=chats.find(chat => chat.name.toLocaleLowerCase()===name.toLocaleLowerCase());
    const id=existing?.id ?? nextId.current++;
    if(!existing) {
      setChats(previous => [{id,name,preview:"",time:"",unread:0,av:id%10+1,type:"individual"},...previous]);
      setMessages(previous => ({...previous,[id]:[]}));
      setActiveId(id); setDraft(""); setMessageSearch(""); setSearchOpen(false);
    } else openChat(id);
    setNewChatOpen(false); setNewName(""); setSection("chats"); setFilter("all"); setSearch("");
  }
  return <div ref={rootRef} className={`laicisa-chat${dark ? " chat-dark" : ""}`}>
    <style>{CHAT_CSS}</style>

<div className="app-wrapper">

<nav className="navbar">
<div className="nav-logo">
<svg viewBox="0 0 24 24"><path d="M17.5 14.4c-.3-.1-1.7-.8-2-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.1-.2.2-.3.2-.6.1-.3-.1-1.2-.5-2.3-1.4-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6.1-.1.3-.3.4-.5.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5 0-.1-.7-1.6-.9-2.2-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.4 0 1.4 1 2.8 1.2 3 .1.2 2 3.1 4.9 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.6-.1 1.7-.7 1.9-1.4.2-.7.2-1.2.2-1.4-.1-.1-.3-.2-.6-.3zM12 2C6.5 2 2 6.5 2 12c0 1.8.5 3.5 1.3 5L2 22l5.2-1.4c1.5.8 3.1 1.2 4.8 1.2 5.5 0 10-4.5 10-10S17.5 2 12 2z"></path></svg>
</div>
<div className="nav-items">
<button data-tab="chats" title="Conversas" className={`nav-item${section === "chats" ? " active" : ""}`} onClick={() => {setSection("chats"); setActiveId(null);}} type="button">
<svg viewBox="0 0 24 24"><path d="M19.08 3H4.92C3.31 3 2 4.31 2 5.92v12.16c0 1.61 1.31 2.92 2.92 2.92H8l4 3 4-3h3.08c1.61 0 2.92-1.31 2.92-2.92V5.92C22 4.31 20.69 3 19.08 3zM8 11a1 1 0 011-1h9a1 1 0 110 2H9a1 1 0 01-1-1zm0 4a1 1 0 011-1h6a1 1 0 110 2H9a1 1 0 01-1-1z"></path></svg>
<span id="navBadge" className={`nav-badge${totalUnread ? "" : " hidden"}`}>{totalUnread || null}</span>
</button>
<button data-tab="calls" title="Chamadas" className={`nav-item${section === "calls" ? " active" : ""}`} onClick={() => {setSection("calls"); setActiveId(null);}} type="button">
<svg viewBox="0 0 24 24"><path d="M19.95 21c-2.08 0-4.14-.45-6.17-1.36a18.3 18.3 0 01-5.55-3.87 18.47 18.47 0 01-3.87-5.54C3.46 8.18 3 6.13 3 4.04A1.02 1.02 0 014.05 3H8.1c.23 0 .44.08.63.24a.9.9 0 01.32.56l.65 3.5c.03.27.03.5-.02.67-.05.19-.15.35-.28.48L6.97 10.9c.34.62.73 1.21 1.2 1.79.45.57.96 1.13 1.5 1.66A17.59 17.59 0 0013.1 17l2.35-2.35a1.61 1.61 0 011.3-.4l3.45.7c.23.07.43.19.57.36.16.18.23.37.23.59v4.05A1.02 1.02 0 0119.95 21z"></path></svg>
</button>
<button data-tab="status" title="Estados" className={`nav-item${section === "status" ? " active" : ""}`} onClick={() => {setSection("status"); setActiveId(null);}} type="button">
<svg viewBox="0 0 24 24"><path d="M13.56 3.14c.1-.55.62-.92 1.15-.77a10 10 0 016.98 12.1.91.91 0 01-1.23.6c-.52-.18-.78-.75-.66-1.3a8 8 0 00-5.44-9.41c-.53-.17-.9-.68-.8-1.22zm5.34 14.65c.42.35.48.98.08 1.37a10 10 0 01-13.96 0c-.4-.39-.34-1.02.08-1.38a1.11 1.11 0 011.46.09 8 8 0 0010.88 0c.4-.38 1.03-.44 1.45-.09zM3.54 15.08c-.52.19-1.1-.08-1.23-.62A10 10 0 019.29 2.37c.53-.15 1.05.22 1.15.77.1.54-.27 1.05-.8 1.22a8 8 0 00-5.44 9.42c.12.54-.14 1.1-.66 1.3z"></path><path d="M12 16a4 4 0 100-8 4 4 0 000 8zm0 2a6 6 0 100-12 6 6 0 000 12z"></path></svg>
</button>
<button data-tab="channels" title="Canais" className={`nav-item${section === "channels" ? " active" : ""}`} onClick={() => {setSection("channels"); setActiveId(null);}} type="button">
<svg viewBox="0 0 24 24"><path d="M15.83 8.63A1 1 0 0117.2 9a5.98 5.98 0 010 6 1 1 0 01-1.73-1 3.98 3.98 0 000-4 1 1 0 01.36-1.37zm-7.66 0A1 1 0 018.53 10a3.98 3.98 0 000 4 1 1 0 01-1.73 1 5.98 5.98 0 010-6 1 1 0 011.37-.37z"></path><path d="M13.5 12a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z"></path><path d="m5.33 16.48-.23.8c-.24.77-.48 1.6-.68 2.3.7-.2 1.53-.44 2.3-.68l.8-.23.72.39a8 8 0 10-3.3-3.3l.4.72zm-2.15.22A48.91 48.91 0 002 21a1 1 0 001 1c.31 0 2.46-.63 4.3-1.18a10 10 0 10-4.12-4.12z"></path></svg>
</button>
<button data-tab="communities" title="Comunidades" className={`nav-item${section === "communities" ? " active" : ""}`} onClick={() => {setSection("communities"); setActiveId(null);}} type="button">
<svg viewBox="0 0 24 24"><path d="M6.37 18.67a1.81 1.81 0 01-.58-1.24c-.01-.5-.03-1.5.03-1.94a2.7 2.7 0 01.4-1.1 2.84 2.84 0 01.9-.82c.46-.28.98-.46 1.4-.58A12.2 12.2 0 0112 12.5a12.69 12.69 0 013.47.49 5.76 5.76 0 011.52.65c.28.19.56.44.78.76a2.41 2.41 0 01.41 1.1c.06.43.04 1.43.03 1.93a1.9 1.9 0 01-.58 1.24c-.22.2-.48.33-.75.33H7.12c-.27 0-.53-.13-.75-.33zm13.6-3.27c.04.6.03.86.02 1.6v.49a4.58 4.58 0 01-.3 1.51h2.97c.72 0 1.31-1.85 1.33-2.58.01-.4.02-.13-.02-.46a2.34 2.34 0 00-.95-1.6 4.27 4.27 0 00-1.41-.68h-.02v-.01a7.72 7.72 0 00-2.35-.27 4.18 4.18 0 01.72 2zm-2.04-3.95a2.65 2.65 0 003.16.06 2.67 2.67 0 10-3.16-.06zM14.9 9.62A3.54 3.54 0 0015.5 7a3.56 3.56 0 10-.61 2.62zm-7.88.4a2.67 2.67 0 10-5.16-1.38 2.67 2.67 0 005.16 1.38zm-4.42 3.6l-.18.05h-.03a4.3 4.3 0 00-1.41.69 2.3 2.3 0 00-.95 1.6c-.04.33-.03 1.06-.02 1.46.02.73.61 1.58 1.33 1.58H4.3a4.58 4.58 0 01-.3-1.51V17c-.01-.74-.02-1 .03-1.6 0-.05 0-.1.02-.15a4.48 4.48 0 01.7-1.85 7.22 7.22 0 00-2.16.22zm9.4.88c-1.21 0-2.22.2-2.92.4-.37.12-.68.23-.91.38-.23.13-.3.25-.34.34a.7.7 0 00-.03.14L7.79 17h8.42v-1.24a.7.7 0 00-.04-.14c-.03-.09-.11-.2-.34-.34a3.84 3.84 0 00-.91-.37c-.7-.2-1.7-.41-2.92-.41zM12 6a1.55 1.55 0 100 3.11c.86 0 1.56-.7 1.56-1.55C13.56 6.7 12.86 6 12 6z"></path></svg>
</button>
</div>
<div className="nav-footer">
<button className="nav-item" title="Meta AI" id="metaAiBtn" onClick={() => notify("O assistente de IA ainda não está ligado a um serviço.")} type="button">
<svg viewBox="0 0 24 24" fill="url(#meta-gradient)">
<defs >
<linearGradient id="meta-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
<stop offset="0%" style={{"stopColor": "#0064E0"}}></stop>
<stop offset="50%" style={{"stopColor": "#8B5CF6"}}></stop>
<stop offset="100%" style={{"stopColor": "#EC4899"}}></stop>
</linearGradient>
</defs>
<circle cx="12" cy="12" r="10" fill="url(#meta-gradient)"></circle>
<circle cx="9" cy="10" r="1.5" fill="white"></circle>
<circle cx="15" cy="10" r="1.5" fill="white"></circle>
<path d="M8 14c1 1.5 2.5 2 4 2s3-.5 4-2" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round"></path>
</svg>
</button>
<div className="nav-avatar" title="Perfil" id="myAvatarBtn" onClick={() => notify(session?.funcionarioNome || session?.username || "Perfil local")} role={"button"} tabIndex={0} onKeyDown={(event) => {if(event.key === "Enter" || event.key === " ") notify(session?.funcionarioNome || session?.username || "Perfil local");}}>{initial(session?.funcionarioNome || session?.username || "EU")}</div>
</div>
</nav>

<div id="mainPanel" className={`main-panel${activeId !== null ? " hide-on-mobile" : ""}`}>

<div data-tab-content="chats" className={`tab-content${section === "chats" ? " active" : ""}`}>
<div className="panel-header">
<h1 className="panel-title">Conversas</h1>
<div className="header-actions">
<button className="icon-btn" title="Nova conversa" id="newChatBtn" onClick={() => setNewChatOpen(true)} type="button">
<svg viewBox="0 0 24 24"><path d="M19.08 3H4.92C3.31 3 2 4.31 2 5.92v12.16c0 1.61 1.31 2.92 2.92 2.92H8l4 3 4-3h3.08c1.61 0 2.92-1.31 2.92-2.92V5.92C22 4.31 20.69 3 19.08 3zM12 11V7h-2v4H6v2h4v4h2v-4h4v-2h-4z"></path></svg>
</button>
</div>
</div>
<div className="search-box">
<div className="search-input-wrap">
<svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path></svg>
<input type="text" className="search-input" id="searchInput" placeholder="Procurar ou criar uma nova conversa" value={search} onChange={(event) => setSearch(event.target.value)} />
<button id="searchClear" title="Limpar" className={`search-clear${search ? " show" : ""}`} onClick={() => setSearch("")} type="button">
<svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg>
</button>
</div>
</div>
<div className="filters">
<button data-filter="all" className={`filter-btn${filter === "all" ? " active" : ""}`} onClick={() => setFilter("all")} type="button">Tudo</button>
<button data-filter="unread" className={`filter-btn${filter === "unread" ? " active" : ""}`} onClick={() => setFilter("unread")} type="button">Não lidas <span style={{"opacity": ".7"}} id="unreadFilterCount">{totalUnread}</span></button>
<button data-filter="favorites" className={`filter-btn${filter === "favorites" ? " active" : ""}`} onClick={() => setFilter("favorites")} type="button">Favoritos</button>
<button data-filter="groups" className={`filter-btn${filter === "groups" ? " active" : ""}`} onClick={() => setFilter("groups")} type="button">Grupos</button>
</div>
<div className="chat-list" id="chatList">
<div className="archived-btn" id="archivedBtn" onClick={() => notify("O HTML fornecido não contém conversas arquivadas.")} role={"button"} tabIndex={0}>
<svg viewBox="0 0 24 24"><path d="M20.54 5.23l-1.39-1.68C18.88 3.21 18.47 3 18 3H6c-.47 0-.88.21-1.16.55L3.46 5.23C3.17 5.57 3 6.02 3 6.5V19c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6.5c0-.48-.17-.93-.46-1.27zM12 17.5L6.5 12H10v-2h4v2h3.5L12 17.5zM5.12 5l.81-1h12l.94 1H5.12z"></path></svg>
<span >Arquivadas</span>
<span className="archived-count">0</span>
</div>
<div className="section-header">Recentes</div>
<div id="chatItemsContainer">{visibleChats.length === 0 ? <div className="no-results">Nenhuma conversa encontrada.</div> : visibleChats.map(chat => (
<button type="button" key={chat.id} onClick={() => openChat(chat.id)} className={`chat-item${chat.unread ? " unread" : ""}${activeId === chat.id ? " active" : ""}`}>
<div className={`chat-avatar av-${chat.av}`}>{initial(chat.name)}</div><div className="chat-info"><div className="chat-top"><span className="chat-name">{chat.name}</span><span className="chat-time">{chat.time}</span></div><div className="chat-bottom"><span className="chat-preview">{chat.call ? "☎ " : ""}{chat.preview}</span>{chat.unread > 0 && <span className="unread-badge">{chat.unread}</span>}</div></div>
</button>))}</div>
</div>
<div className="e2e-message">Mensagens locais neste dispositivo. Sem ligação ao servidor.</div>
</div>

<div data-tab-content="calls" className={`tab-content${section === "calls" ? " active" : ""}`}>
<div className="panel-header">
<h1 className="panel-title">Chamadas</h1>
</div>
<div className="search-box">
<div className="search-input-wrap">
<svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path></svg>
<input type="text" className="search-input" id="callsSearchInput" placeholder="Procurar nome ou número" value={callsSearch} onChange={(event) => setCallsSearch(event.target.value)} />
</div>
</div>
<div className="chat-list" id="callsList">{visibleCalls.length === 0 ? <div className="no-results">Nenhuma chamada encontrada.</div> : visibleCalls.map((call, index) => <button type="button" key={index} className="chat-item" onClick={() => notify("Chamadas requerem ligação a um serviço de chamadas.")}><div className={`chat-avatar av-${call.name.charCodeAt(0) % 10 + 1}`}>{initial(call.name)}</div><div className="chat-info"><div className="chat-top"><span className="chat-name">{call.name}</span><span className="chat-time">{call.time}</span></div><div className="chat-bottom"><span className="chat-preview" style={{color:call.type === "missed" ? "#ea0038" : undefined}}>☎ {callLabel(call.type)}{call.count ? ` (${call.count})` : ""}</span></div></div></button>)}</div>
</div>

<div data-tab-content="status" className={`tab-content${section === "status" ? " active" : ""}`}>
<div className="panel-header">
<h1 className="panel-title">Estados</h1>
</div>
<div className="chat-list" style={{"padding": "20px", "textAlign": "center", "color": "var(--WDS-content-deemphasized)"}}>
<p style={{"padding": "40px 20px"}}>Os estados dos seus contactos aparecerão aqui</p>
</div>
</div>

<div data-tab-content="channels" className={`tab-content${section === "channels" ? " active" : ""}`}>
<div className="panel-header">
<h1 className="panel-title">Canais</h1>
</div>
<div className="chat-list" style={{"padding": "20px", "textAlign": "center", "color": "var(--WDS-content-deemphasized)"}}>
<p style={{"padding": "40px 20px"}}>Os canais que segue aparecerão aqui</p>
</div>
</div>

<div data-tab-content="communities" className={`tab-content${section === "communities" ? " active" : ""}`}>
<div className="panel-header">
<h1 className="panel-title">Comunidades</h1>
</div>
<div className="chat-list" style={{"padding": "20px", "textAlign": "center", "color": "var(--WDS-content-deemphasized)"}}>
<p style={{"padding": "40px 20px"}}>As suas comunidades aparecerão aqui</p>
</div>
</div>
</div>

<div id="chatView" className={`chat-view${activeId !== null ? " active" : ""}`}>
<div className="empty-state" id="emptyState" style={{display:activeChat ? "none" : undefined}}>
<div className="empty-state-icon">
<svg viewBox="0 0 303 172"><path d="M229.565 160.229c27.762-15.17 46.774-44.78 46.774-78.78 0-49.706-40.294-90-90-90s-90 40.294-90 90c0 27.762 12.556 52.58 32.302 69.09L105 172l32.302-21.461c11.028 5.04 23.29 7.847 36.198 7.847 19.88 0 38.44-6.28 53.625-17.03l2.44-1.127z" fill="currentColor" opacity=".15"></path><circle cx="140" cy="80" r="6" fill="currentColor" opacity=".3"></circle><circle cx="170" cy="80" r="6" fill="currentColor" opacity=".3"></circle><circle cx="200" cy="80" r="6" fill="currentColor" opacity=".3"></circle></svg>
</div>
<h2 >Chat da App</h2>
<p >Seleccione uma conversa para começar. Os contactos e o histórico inicial são os exemplos do HTML fornecido.</p>
</div>
<div id="activeChatView" style={{display:activeChat ? "flex" : "none",flex:1,flexDirection:"column",minHeight:0}}>{searchOpen && <input aria-label="Pesquisar mensagens" placeholder="Pesquisar nesta conversa" value={messageSearch} onChange={event => setMessageSearch(event.target.value)} style={{padding:12}} />}
<div className="chat-view-header">
<button className="icon-btn back-btn" id="backBtn" title="Voltar" onClick={() => setActiveId(null)} type="button">
<svg viewBox="0 0 24 24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
</button>
<div id="viewAvatar" className={`chat-view-avatar av-${activeChat?.av ?? 1}`}>{activeChat ? initial(activeChat.name) : ""}</div>
<div className="chat-view-info" id="viewInfo">
<div className="chat-view-name" id="viewName">{activeChat?.name}</div>
<div className="chat-view-status" id="viewStatus">{activeChat?.type === "group" ? "Grupo" : "Contacto"}</div>
</div>
<div className="chat-view-actions">
<button className="icon-btn" title="Chamada de vídeo" data-action="video" onClick={() => notify("Chamadas reais requerem ligação a um serviço de chamadas.")} type="button">
<svg viewBox="0 0 24 24"><path d="M15.99 14.26c-.01-.08-.02-.16-.02-.26 0-.94.39-1.81 1.01-2.49l-3.26-2.35c-.27.13-.57.2-.87.2-.31 0-.6-.08-.87-.2l-3.26 2.35c.62.68 1.01 1.55 1.01 2.49 0 .1-.01.18-.02.26l3.14 2.26 3.14-2.26zM17.5 3C16.12 3 15 4.12 15 5.5V6h-2V5.5C13 4.12 11.88 3 10.5 3S8 4.12 8 5.5V6H6V5.5C6 4.12 4.88 3 3.5 3S1 4.12 1 5.5V18c0 1.66 1.34 3 3 3h16c1.66 0 3-1.34 3-3V5.5c0-1.38-1.12-2.5-2.5-2.5S18 4.12 18 5.5V6h-2V5.5c0-1.38-1.12-2.5-2.5-2.5z"></path></svg>
</button>
<button className="icon-btn" title="Chamada" data-action="voice" onClick={() => notify("Chamadas reais requerem ligação a um serviço de chamadas.")} type="button">
<svg viewBox="0 0 24 24"><path d="M19.95 21c-2.08 0-4.14-.45-6.17-1.36a18.3 18.3 0 01-5.55-3.87 18.47 18.47 0 01-3.87-5.54C3.46 8.18 3 6.13 3 4.04A1.02 1.02 0 014.05 3H8.1c.23 0 .44.08.63.24a.9.9 0 01.32.56l.65 3.5c.03.27.03.5-.02.67-.05.19-.15.35-.28.48L6.97 10.9c.34.62.73 1.21 1.2 1.79.45.57.96 1.13 1.5 1.66A17.59 17.59 0 0013.1 17l2.35-2.35a1.61 1.61 0 011.3-.4l3.45.7c.23.07.43.19.57.36.16.18.23.37.23.59v4.05A1.02 1.02 0 0119.95 21z"></path></svg>
</button>
<button className="icon-btn" title="Pesquisar na conversa" id="inChatSearchBtn" onClick={() => setSearchOpen(value => !value)} type="button">
<svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path></svg>
</button>
</div>
</div>
<div className="messages-area" id="messagesArea" ref={messagesRef} aria-live={"polite"}><div className="date-separator">Conversa</div>{currentMessages.filter(message => message.text.toLocaleLowerCase().includes(messageSearch.toLocaleLowerCase())).map((message,index) => <div key={index} className={`message ${message.type}`}><div className="message-text">{message.text}</div><div className="message-meta">{message.time}{message.type === "sent" && <span title="Mensagem local"> ✓</span>}</div></div>)}</div>
<div className="composer">
<button className="icon-btn" title="Emoji" id="emojiBtn" onClick={() => setEmojiOpen(value => !value)} aria-expanded={emojiOpen} type="button">
<svg viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"></path></svg>
</button>
<div id="emojiPicker" className={`emoji-picker${emojiOpen ? " show" : ""}`}>{EMOJIS.map(emoji => <button key={emoji} type="button" onClick={() => {setDraft(value => value + emoji); inputRef.current?.focus();}}>{emoji}</button>)}</div>
<button className="icon-btn" title="Anexar" id="attachBtn" onClick={() => notify("O envio de anexos requer ligação ao servidor.")} type="button">
<svg viewBox="0 0 24 24"><path d="M1.816 15.556v.002c0 1.502.584 2.912 1.646 3.972s2.472 1.647 3.974 1.647a5.58 5.58 0 003.972-1.645l9.547-9.548c.769-.768 1.147-1.767 1.058-2.817-.079-.968-.548-1.927-1.319-2.698-1.594-1.592-4.068-1.711-5.517-.262l-7.916 7.915c-.881.881-.792 2.25.214 3.261.959.958 2.423 1.053 3.263.215l5.511-5.512c.28-.28.267-.722.053-.936l-.244-.244c-.191-.191-.567-.349-.957.04l-5.506 5.506c-.18.18-.635.127-.976-.214-.098-.097-.576-.613-.213-.973l7.915-7.917c.818-.817 2.267-.231 2.694.195.271.271.436.64.474.98.041.399-.121.737-.446 1.061l-9.546 9.549a3.97 3.97 0 01-2.829 1.171 3.975 3.975 0 01-2.83-1.171 3.973 3.973 0 01-1.172-2.828c0-1.071.415-2.076 1.172-2.83l7.209-7.211c.157-.157.264-.579.028-.814L11.5 4.36a.572.572 0 00-.834.018l-7.205 7.207a5.577 5.577 0 00-1.645 3.971z"></path></svg>
</button>
<div className="composer-input-wrap">
<input type="text" className="composer-input" id="composerInput" placeholder="Escreva uma mensagem" ref={inputRef} value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => {if(event.key === "Enter" && !event.nativeEvent.isComposing) {event.preventDefault(); sendMessage();}}} />
</div>
<button className="icon-btn send-btn" id="sendBtn" title="Enviar" onClick={sendMessage} disabled={!draft.trim() || !activeChat} type="button">
<svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path></svg>
</button>
</div>
</div>
</div>
</div>
<div id="toast" className={`toast${toast ? " show" : ""}`} role={"status"}>{toast}</div>


    <button type="button" onClick={() => setDark(value => !value)} aria-label="Alternar tema do chat" style={{position:"absolute",bottom:76,left:14,zIndex:3,border:0,borderRadius:20,padding:8,cursor:"pointer",background:"var(--WDS-surface-emphasized)",color:"var(--WDS-content-default)"}}>{dark ? "☀" : "☾"}</button>
    {newChatOpen && <div role="dialog" aria-modal="true" aria-label="Nova conversa local" style={{position:"absolute",inset:0,zIndex:20,background:"#0008",display:"grid",placeItems:"center"}} onKeyDown={event => {if(event.key === "Escape") setNewChatOpen(false);}}>
      <form onSubmit={event => {event.preventDefault();createChat();}} style={{padding:24,borderRadius:12,background:"var(--WDS-surface-default)",width:"min(90%,360px)"}}>
        <h2>Nova conversa local</h2><label htmlFor="chat-contact-name">Nome do contacto</label>
        <input id="chat-contact-name" autoFocus value={newName} onChange={event => setNewName(event.target.value)} required style={{width:"100%",padding:10,margin:"12px 0",border:"1px solid #aaa",borderRadius:8,color:"inherit",background:"transparent"}} />
        <p style={{fontSize:12,marginBottom:12}}>A conversa fica apenas nesta sessão do navegador.</p>
        <button type="button" onClick={() => setNewChatOpen(false)} style={{padding:8}}>Cancelar</button> <button type="submit" disabled={!newName.trim()} style={{padding:8}}>Criar</button>
      </form>
    </div>}
  </div>;
}
