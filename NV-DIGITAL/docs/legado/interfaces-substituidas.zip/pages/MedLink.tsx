import { useState, useEffect, useRef, useCallback } from "react";

// ─── Types ──────────────────────────────────────────────────────────────────
interface Patient {
  id: string;
  name: string;
  nif: string;
  birth: string;
  gender: string;
  blood: string;
  phone: string;
  address: string;
  allergies: string;
  conditions: string;
  createdAt: string;
}

interface Process {
  id: number;
  sender: string;
  email: string;
  subject: string;
  preview: string;
  date: string;
  dateFull: string;
  unread: boolean;
  priority: "emergency" | "urgent" | "normal" | "low";
  type: string;
  typeName: string;
  patient: string;
  patientNif: string;
  insurer: string;
  policy: string;
  status: string;
  statusName: string;
  color: string;
  initials: string;
  flagged: boolean;
  archived: boolean;
  processNumber: string;
  body: string;
}

interface Toast { msg: string; type: string }

// ─── Sample data ─────────────────────────────────────────────────────────────
const SAMPLE_PATIENTS: Omit<Patient, "id" | "createdAt">[] = [
  { name: "Maria João Silva", nif: "005478921LA045", birth: "1985-03-15", gender: "F", blood: "A+", phone: "+244 923 456 789", address: "Maianga, Luanda", allergies: "Penicilina", conditions: "Hipertensão arterial" },
  { name: "António Fernandes Costa", nif: "009874523LA078", birth: "1958-07-22", gender: "M", blood: "O+", phone: "+244 924 789 123", address: "Talatona, Luanda", allergies: "", conditions: "Diabetes tipo 2, HTA" },
  { name: "João Baptista Neto", nif: "002345678LA012", birth: "1972-11-08", gender: "M", blood: "B+", phone: "+244 925 321 654", address: "Viana, Luanda", allergies: "AAS", conditions: "Cardiopatia isquémica" },
  { name: "Rosa Domingos Miguel", nif: "006789123LA034", birth: "1971-05-30", gender: "F", blood: "AB+", phone: "+244 926 147 258", address: "Cazenga, Luanda", allergies: "", conditions: "" },
  { name: "Carlos Mendes", nif: "003456789LA056", birth: "1965-09-12", gender: "M", blood: "A-", phone: "+244 927 963 852", address: "Belas, Luanda", allergies: "Iodo", conditions: "Neoplasia pulmonar" },
  { name: "Teresa Baptista", nif: "004567890LA023", birth: "1997-02-18", gender: "F", blood: "O-", phone: "+244 928 741 852", address: "Cacuaco, Luanda", allergies: "", conditions: "Gravidez 34 semanas" },
  { name: "Pedro Afonso Lemos", nif: "008765432LA090", birth: "1980-12-03", gender: "M", blood: "B-", phone: "+244 929 369 258", address: "Kilamba, Luanda", allergies: "", conditions: "" },
];

const INITIAL_PROCESSES: Process[] = [
  {
    id: 1, sender: "Laboratório MedAnálises", email: "resultados@medanalises.ao",
    subject: "Resultados Análises - Maria João Silva",
    preview: "Resultados das análises sanguíneas solicitadas em 20/07/2026",
    date: "10:32", dateFull: "qua, 22/07/2026 10:32", unread: true,
    priority: "normal", type: "exam", typeName: "Resultado de Exame",
    patient: "Maria João Silva", patientNif: "005478921LA045",
    insurer: "Multicare", policy: "MC-2024-78451",
    status: "pending", statusName: "Pendente de Validação",
    color: "#107c10", initials: "MA", flagged: false, archived: false,
    processNumber: "PRC-2026-0847",
    body: "<p>Exmo. Dr. Domingos Nvuala,</p><p>Enviamos em anexo os resultados das análises clínicas solicitadas para a paciente <strong>Maria João Silva</strong>, NIF 005478921LA045.</p><p><strong>Exames realizados:</strong></p><ul style='margin-left:20px;margin-bottom:12px'><li>Hemograma completo</li><li>Glicemia em jejum</li><li>Colesterol total e frações</li><li>Função hepática (TGO, TGP)</li><li>Função renal (Ureia, Creatinina)</li></ul><p>Todos os valores encontram-se dentro dos parâmetros de referência, exceto colesterol LDL ligeiramente elevado (142 mg/dL).</p><p>Relatório completo disponível em anexo.</p><p style='margin-top:24px;color:#616161;font-size:13px'>Com os melhores cumprimentos,<br><strong>Dr. Paulo Mendes</strong><br>Director Técnico - Laboratório MedAnálises<br>Tel: +244 222 445 789</p>",
  },
  {
    id: 2, sender: "Hospital Américo Boavida", email: "urgencia@hab.ao",
    subject: "URGENTE - Transferência de Paciente",
    preview: "Solicitamos transferência urgente de paciente com quadro de AVC isquémico",
    date: "09:15", dateFull: "qua, 22/07/2026 09:15", unread: true,
    priority: "emergency", type: "transfer", typeName: "Transferência",
    patient: "António Fernandes Costa", patientNif: "009874523LA078",
    insurer: "ENS", policy: "ENS-2025-12847",
    status: "processing", statusName: "Em Processamento",
    color: "#a4262c", initials: "HA", flagged: false, archived: false,
    processNumber: "PRC-2026-0846",
    body: "<p>Exmo. Director Clínico,</p><p><strong style='color:#a4262c'>⚠ URGÊNCIA MÉDICA</strong></p><p>Solicitamos transferência URGENTE do paciente <strong>António Fernandes Costa</strong>, 67 anos, com quadro clínico compatível com <strong>AVC isquémico</strong> em evolução.</p><ul style='margin-left:20px;margin-bottom:12px'><li>Idade: 67 anos</li><li>Início dos sintomas: há 2 horas</li><li>TAC craniana: sem hemorragia</li><li>NIHSS: 14 pontos</li><li>Comorbilidades: HTA, Diabetes tipo 2</li></ul><p>Solicitamos transferência para unidade com capacidade de trombólise/trombectomia.</p><p style='margin-top:24px;color:#616161;font-size:13px'>Dr. Manuel Sousa<br>Serviço de Urgência - HAB<br>Tel: +244 222 667 000</p>",
  },
  {
    id: 3, sender: "Seguradora Multicare", email: "autorizacoes@multicare.ao",
    subject: "Autorização Concedida - Cirurgia Cardíaca",
    preview: "Autorização nº AUT-2026-4521 aprovada para cirurgia de bypass",
    date: "08:47", dateFull: "qua, 22/07/2026 08:47", unread: true,
    priority: "normal", type: "auth", typeName: "Autorização",
    patient: "João Baptista Neto", patientNif: "002345678LA012",
    insurer: "Multicare", policy: "MC-2023-45892",
    status: "approved", statusName: "Aprovado",
    color: "#0078d4", initials: "MC", flagged: false, archived: false,
    processNumber: "PRC-2026-0845",
    body: "<p>Exmo. Dr. Domingos Nvuala,</p><p>Informamos que foi <strong style='color:#107c10'>APROVADA</strong> a autorização para o procedimento solicitado:</p><ul style='margin-left:20px;margin-bottom:12px'><li>Nº Autorização: AUT-2026-4521</li><li>Paciente: João Baptista Neto</li><li>Procedimento: Cirurgia de Bypass Aorto-Coronário</li><li>Data prevista: 28/07/2026</li><li>Valor autorizado: 4.850.000 Kz</li></ul><p>Validade da autorização: 30 dias a partir da data de emissão.</p><p style='margin-top:24px;color:#616161;font-size:13px'>Departamento de Autorizações<br>Multicare Angola<br>Tel: +244 222 200 400</p>",
  },
  {
    id: 4, sender: "Clínica Sagrada Esperança", email: "pedidos@cse.ao",
    subject: "Pedido de Consulta Especializada - Cardiologia",
    preview: "Solicitamos marcação de consulta de cardiologia para paciente referenciado",
    date: "ontem", dateFull: "ter, 21/07/2026 16:23", unread: true,
    priority: "urgent", type: "consult", typeName: "Consulta",
    patient: "Rosa Domingos Miguel", patientNif: "006789123LA034",
    insurer: "Aliança Seguros", policy: "AS-2024-98745",
    status: "pending", statusName: "Pendente de Aprovação",
    color: "#7719aa", initials: "CS", flagged: false, archived: false,
    processNumber: "PRC-2026-0844",
    body: "<p>Exmo. Director Clínico,</p><p>Solicitamos marcação de consulta especializada de <strong>Cardiologia</strong> para a paciente <strong>Rosa Domingos Miguel</strong>, 54 anos.</p><ul style='margin-left:20px;margin-bottom:12px'><li>Dor torácica recorrente</li><li>Dispneia aos esforços</li><li>ECG com alterações de ST</li><li>Histórico familiar de doença coronária</li></ul><p>Agradecemos resposta em 48h.</p><p style='margin-top:24px;color:#616161;font-size:13px'>Dra. Isabel Correia<br>Clínica Sagrada Esperança<br>Tel: +244 222 334 567</p>",
  },
  {
    id: 5, sender: "Laboratório BioTech", email: "biotech@lab.ao",
    subject: "Resultado Biópsia - Urgente",
    preview: "Resultado da biópsia do paciente Carlos Mendes disponível",
    date: "ontem", dateFull: "ter, 21/07/2026 14:08", unread: false,
    priority: "urgent", type: "result", typeName: "Resultado",
    patient: "Carlos Mendes", patientNif: "003456789LA056",
    insurer: "", policy: "",
    status: "approved", statusName: "Concluído",
    color: "#ca5010", initials: "BT", flagged: false, archived: false,
    processNumber: "PRC-2026-0843",
    body: "<p>Exmo. Dr. Domingos Nvuala,</p><p>Informamos que o resultado da biópsia solicitada para o paciente <strong>Carlos Mendes</strong> já se encontra disponível.</p><p><strong>Diagnóstico histopatológico:</strong></p><p>Adenocarcinoma moderadamente diferenciado, grau II (Grau histológico de Nottingham: 6). Margens cirúrgicas livres.</p><p>Recomenda-se reunião de oncologia para planeamento terapêutico.</p><p style='margin-top:24px;color:#616161;font-size:13px'>Dr. Fernando Alves<br>Anatomopatologista — Laboratório BioTech</p>",
  },
  {
    id: 6, sender: "Hospital Principal de Luanda", email: "direccao@hpl.ao",
    subject: "Relatório Mensal - Julho 2026",
    preview: "Enviamos relatório consolidado de actividades do mês de Julho",
    date: "20/07", dateFull: "dom, 20/07/2026 11:45", unread: false,
    priority: "low", type: "report", typeName: "Relatório",
    patient: "", patientNif: "", insurer: "", policy: "",
    status: "approved", statusName: "Recebido",
    color: "#0F6CBD", initials: "HP", flagged: false, archived: false,
    processNumber: "PRC-2026-0842",
    body: "<p>Exmo. Director Clínico,</p><p>Enviamos em anexo o Relatório Mensal de Actividades referente a Julho de 2026.</p><ul style='margin-left:20px;margin-bottom:12px'><li>Total de internamentos: 342</li><li>Consultas externas: 2.847</li><li>Cirurgias realizadas: 187</li><li>Taxa de ocupação: 82%</li><li>Média de permanência: 4.2 dias</li></ul><p style='margin-top:24px;color:#616161;font-size:13px'>Dr. Alberto Teixeira<br>Director Clínico - HPL</p>",
  },
  {
    id: 7, sender: "ENS - Empresa Nacional de Seguros", email: "sinistros@ens.ao",
    subject: "Pedido de Documentação - Processo Sinistro",
    preview: "Solicitamos documentação complementar para processo de sinistro",
    date: "19/07", dateFull: "sáb, 19/07/2026 09:30", unread: false,
    priority: "normal", type: "auth", typeName: "Documentação",
    patient: "Pedro Afonso Lemos", patientNif: "008765432LA090",
    insurer: "ENS", policy: "ENS-2024-56231",
    status: "pending", statusName: "Aguarda Documentação",
    color: "#0078d4", initials: "EN", flagged: false, archived: false,
    processNumber: "PRC-2026-0841",
    body: "<p>Exmo. Director Clínico,</p><p>No âmbito do processo de sinistro nº <strong>SIN-2026-12847</strong>, referente ao segurado <strong>Pedro Afonso Lemos</strong>, vimos solicitar a seguinte documentação complementar:</p><ul style='margin-left:20px;margin-bottom:12px'><li>Relatório clínico detalhado</li><li>Cópia das facturas originais</li><li>Prescrições médicas</li><li>Exames complementares de diagnóstico</li></ul><p>Agradecemos o envio no prazo máximo de 10 dias úteis.</p><p style='margin-top:24px;color:#616161;font-size:13px'>Departamento de Sinistros<br>ENS Angola</p>",
  },
  {
    id: 8, sender: "Clínica Vila Mariana", email: "geral@cvmariana.ao",
    subject: "Encaminhamento - Paciente Grávida",
    preview: "Encaminhamos paciente grávida de 34 semanas para avaliação especializada",
    date: "18/07", dateFull: "sex, 18/07/2026 15:12", unread: false,
    priority: "urgent", type: "transfer", typeName: "Encaminhamento",
    patient: "Teresa Baptista", patientNif: "004567890LA023",
    insurer: "Sulamericana", policy: "SS-2025-34521",
    status: "approved", statusName: "Recebido",
    color: "#7719aa", initials: "CV", flagged: false, archived: false,
    processNumber: "PRC-2026-0840",
    body: "<p>Exmo. Director Clínico,</p><p>Encaminhamos a paciente <strong>Teresa Baptista</strong>, 28 anos, grávida de 34 semanas, para avaliação especializada em Obstetrícia de Risco.</p><ul style='margin-left:20px;margin-bottom:12px'><li>Pré-eclâmpsia ligeira</li><li>TA: 145/95 mmHg</li><li>Proteinúria: 320 mg/24h</li><li>Ecografia com restrição de crescimento fetal</li></ul><p>Paciente estabilizada e medicada com metildopa.</p><p style='margin-top:24px;color:#616161;font-size:13px'>Dra. Luísa Domingos<br>Clínica Vila Mariana</p>",
  },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────
function priorityLabel(p: string) {
  return ({ emergency: "Emergência", urgent: "Urgente", normal: "Normal", low: "Baixa" } as Record<string, string>)[p] ?? p;
}
function priorityColor(p: string) {
  return ({ emergency: "#a4262c", urgent: "#ca5010", normal: "#0078d4", low: "#107c10" } as Record<string, string>)[p] ?? "#616161";
}
function priorityBg(p: string) {
  return ({ emergency: "#fde7e9", urgent: "#fff4ce", normal: "#ebf3fc", low: "#f1faf1" } as Record<string, string>)[p] ?? "#f0f0f0";
}
function statusClass(s: string) {
  return ({ pending: "pending", approved: "approved", rejected: "rejected", processing: "processing" } as Record<string, string>)[s] ?? "pending";
}
function statusStyle(s: string): React.CSSProperties {
  const styles: Record<string, React.CSSProperties> = {
    pending: { background: "#fff4ce", color: "#8a6d0b" },
    approved: { background: "#dff6de", color: "#0e700e" },
    rejected: { background: "#fde7e9", color: "#a4262c" },
    processing: { background: "#ebf3fc", color: "#005ea6" },
  };
  return styles[s] ?? styles.pending;
}
function getGroup(dateStr: string) {
  if (dateStr === "agora" || (dateStr.includes(":") && !dateStr.includes("/"))) return "Hoje";
  if (dateStr === "ontem") return "Ontem";
  return "Julho 2026";
}
function calculateAge(birth: string) {
  if (!birth) return "";
  const today = new Date();
  const b = new Date(birth);
  let age = today.getFullYear() - b.getFullYear();
  if (today.getMonth() < b.getMonth() || (today.getMonth() === b.getMonth() && today.getDate() < b.getDate())) age--;
  return age;
}
function makePatient(data: Omit<Patient, "id" | "createdAt">): Patient {
  return { ...data, id: "P" + Date.now() + Math.floor(Math.random() * 1000), createdAt: new Date().toISOString() };
}

// ─── Vitals alert helper ──────────────────────────────────────────────────────
function vitalAlert(field: string, val: string): "alert" | "warning" | "normal" | "" {
  if (!val) return "";
  if (field === "bp") {
    const [sys, dia] = val.split("/").map(Number);
    if (isNaN(sys) || isNaN(dia)) return "";
    if (sys >= 180 || dia >= 120) return "alert";
    if (sys >= 140 || dia >= 90) return "warning";
    if (sys >= 90 && sys < 140 && dia >= 60 && dia < 90) return "normal";
    return "";
  }
  const n = parseFloat(val);
  if (isNaN(n)) return "";
  if (field === "hr") { if (n > 120 || n < 50) return "alert"; if (n > 100 || n < 60) return "warning"; return "normal"; }
  if (field === "temp") { if (n >= 39 || n < 35) return "alert"; if (n >= 37.5 || n < 36) return "warning"; return "normal"; }
  if (field === "spo2") { if (n < 90) return "alert"; if (n < 95) return "warning"; return "normal"; }
  if (field === "rr") { if (n > 25 || n < 10) return "alert"; if (n > 20 || n < 12) return "warning"; return "normal"; }
  if (field === "gly") { if (n > 200 || n < 70) return "alert"; if (n > 140 || n < 80) return "warning"; return "normal"; }
  return "";
}
function vitalColor(level: string) {
  if (level === "alert") return "#c50f1f";
  if (level === "warning") return "#f7630c";
  if (level === "normal") return "#107c10";
  return "#616161";
}
function vitalBg(level: string) {
  if (level === "alert") return "#fde7e9";
  if (level === "warning") return "#fff4ce";
  if (level === "normal") return "#f1faf1";
  return "#f5f5f5";
}

// ─── CSS (injected once) ──────────────────────────────────────────────────────
const ML_STYLE = `
.ml-wrap { display:flex; flex-direction:column; height:100%; background:#fff; font-family:"Segoe UI",-apple-system,BlinkMacSystemFont,Roboto,sans-serif; font-size:14px; color:#242424; overflow:hidden; }
.ml-titlebar { height:48px; background:#f5f5f5; display:flex; align-items:center; padding:0 12px; border-bottom:1px solid #e0e0e0; flex-shrink:0; gap:8px; }
.ml-brand { display:flex; align-items:center; gap:8px; padding:0 8px; font-weight:700; font-size:15px; color:#0F6CBD; }
.ml-search { flex:1; max-width:500px; display:flex; align-items:center; background:#fafafa; border:1px solid transparent; border-radius:4px; height:34px; padding:0 8px; transition:all .15s; }
.ml-search:focus-within { background:#fff; border-color:#0F6CBD; border-width:2px; }
.ml-search input { flex:1; border:none; background:transparent; outline:none; font-size:14px; padding:0 6px; color:#242424; }
.ml-search input::placeholder { color:#707070; }
.ml-main { flex:1; display:flex; overflow:hidden; }
.ml-leftrail { width:48px; background:#fff; display:flex; flex-direction:column; align-items:center; padding:4px 0; gap:2px; border-right:1px solid #e0e0e0; flex-shrink:0; }
.ml-rail-btn { width:40px; height:40px; display:flex; align-items:center; justify-content:center; border-radius:4px; color:#424242; border:none; background:none; cursor:pointer; transition:background .15s; }
.ml-rail-btn:hover { background:#f0f0f0; }
.ml-rail-btn.active { background:#ebf3fc; color:#0F6CBD; }
.ml-rail-btn svg { width:20px; height:20px; }
.ml-rail-divider { width:24px; height:1px; background:#e0e0e0; margin:4px 0; }
.ml-navpane { width:220px; background:#fafafa; border-right:1px solid #e0e0e0; display:flex; flex-direction:column; overflow:hidden; flex-shrink:0; }
.ml-nav-header { padding:12px 16px 8px; border-bottom:1px solid #e0e0e0; display:flex; align-items:center; justify-content:space-between; }
.ml-nav-title { font-size:14px; font-weight:700; color:#242424; }
.ml-nav-list { flex:1; overflow-y:auto; padding:4px 0; }
.ml-nav-section-title { font-size:10px; font-weight:600; color:#707070; text-transform:uppercase; letter-spacing:.5px; padding:8px 16px 4px; }
.ml-nav-item { display:flex; align-items:center; gap:8px; padding:6px 12px; cursor:pointer; border-radius:4px; margin:1px 4px; transition:background .15s; font-size:13px; color:#424242; }
.ml-nav-item:hover { background:#f0f0f0; }
.ml-nav-item.selected { background:#ebf3fc; color:#0F6CBD; font-weight:600; }
.ml-nav-item svg { width:16px; height:16px; flex-shrink:0; }
.ml-nav-count { margin-left:auto; font-size:11px; font-weight:700; background:#c50f1f; color:#fff; border-radius:10px; padding:1px 6px; min-width:18px; text-align:center; }
.ml-nav-count.normal { background:#e0e0e0; color:#424242; }
.ml-msglist { width:320px; border-right:1px solid #e0e0e0; display:flex; flex-direction:column; overflow:hidden; flex-shrink:0; }
.ml-msglist-header { padding:8px 12px; border-bottom:1px solid #e0e0e0; display:flex; align-items:center; gap:6px; min-height:44px; }
.ml-tab-btn { padding:4px 10px; border-radius:4px; font-size:12px; font-weight:600; border:none; cursor:pointer; transition:all .15s; }
.ml-tab-btn.active { background:#0F6CBD; color:#fff; }
.ml-tab-btn:not(.active) { background:transparent; color:#616161; }
.ml-tab-btn:not(.active):hover { background:#f0f0f0; }
.ml-messages { flex:1; overflow-y:auto; }
.ml-month { font-size:11px; font-weight:600; color:#707070; text-transform:uppercase; letter-spacing:.5px; padding:8px 12px 4px; }
.ml-message { display:flex; gap:8px; padding:10px 12px; cursor:pointer; border-bottom:1px solid #f0f0f0; transition:background .15s; }
.ml-message:hover { background:#f5f5f5; }
.ml-message.selected { background:#ebf3fc; }
.ml-message.unread .ml-msg-sender { font-weight:700; color:#0F6CBD; }
.ml-msg-avatar { width:36px; height:36px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff; font-weight:700; font-size:13px; flex-shrink:0; }
.ml-msg-content { flex:1; min-width:0; }
.ml-msg-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:2px; }
.ml-msg-sender { font-size:13px; color:#242424; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:160px; }
.ml-msg-date { font-size:11px; color:#707070; flex-shrink:0; }
.ml-msg-subject { font-size:12px; color:#424242; margin-bottom:2px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; display:flex; align-items:center; gap:4px; }
.ml-msg-preview { font-size:11px; color:#707070; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.ml-badge { display:inline-flex; align-items:center; padding:1px 6px; border-radius:10px; font-size:10px; font-weight:700; flex-shrink:0; }
.ml-readpane { flex:1; display:flex; flex-direction:column; overflow:hidden; }
.ml-rp-empty { flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center; color:#707070; gap:12px; padding:40px; text-align:center; }
.ml-rp-empty svg { width:80px; height:80px; opacity:.3; }
.ml-rp-toolbar { display:flex; align-items:center; padding:6px 12px; gap:2px; border-bottom:1px solid #e0e0e0; min-height:46px; flex-shrink:0; }
.ml-rp-body-scroll { flex:1; overflow-y:auto; }
.ml-rp-header { padding:20px 24px 16px; border-bottom:1px solid #e0e0e0; }
.ml-rp-subject { font-size:20px; font-weight:600; color:#242424; margin-bottom:14px; display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.ml-rp-meta { display:grid; grid-template-columns:repeat(2,1fr); gap:10px; margin-bottom:14px; padding:12px; background:#fafafa; border-radius:6px; }
.ml-rp-meta-label { font-size:11px; font-weight:600; color:#707070; text-transform:uppercase; letter-spacing:.5px; }
.ml-rp-meta-value { font-size:13px; color:#242424; font-weight:500; margin-top:2px; }
.ml-rp-sender-row { display:flex; align-items:center; gap:10px; }
.ml-rp-avatar { width:38px; height:38px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff; font-weight:700; font-size:14px; flex-shrink:0; }
.ml-rp-body { padding:20px 24px; font-size:14px; line-height:1.65; color:#242424; }
.ml-rp-body p { margin-bottom:12px; }
.ml-rp-body ul { margin-bottom:12px; }
.ml-rp-status { display:flex; align-items:center; gap:8px; padding:10px 16px; background:#fafafa; border-top:1px solid #e0e0e0; font-size:13px; flex-shrink:0; }
.ml-status-pill { display:inline-flex; align-items:center; gap:4px; padding:3px 10px; border-radius:12px; font-size:12px; font-weight:600; }
.ml-icoBtn { width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:4px; color:#424242; border:none; background:none; cursor:pointer; transition:background .15s; }
.ml-icoBtn:hover { background:#f0f0f0; }
.ml-icoBtn:disabled { opacity:.4; cursor:default; }
.ml-icoBtn svg { width:18px; height:18px; }
.ml-btn { display:inline-flex; align-items:center; gap:6px; padding:6px 14px; border-radius:4px; font-size:13px; font-weight:600; border:none; cursor:pointer; transition:all .15s; }
.ml-btn-primary { background:#0F6CBD; color:#fff; }
.ml-btn-primary:hover { background:#005EA6; }
.ml-btn-ghost { background:transparent; color:#424242; border:1px solid #d1d1d1; }
.ml-btn-ghost:hover { background:#f0f0f0; }
.ml-btn-danger { background:#c50f1f; color:#fff; }
.ml-btn-danger:hover { background:#a4262c; }
.ml-modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,.4); z-index:1000; display:flex; align-items:center; justify-content:center; padding:20px; animation:ml-fade-in .15s; }
@keyframes ml-fade-in { from{opacity:0} to{opacity:1} }
.ml-modal { background:#fff; border-radius:8px; box-shadow:0 8px 32px rgba(0,0,0,.2); width:100%; max-width:680px; max-height:90vh; display:flex; flex-direction:column; animation:ml-slide-up .2s; overflow:hidden; }
.ml-modal-lg { max-width:780px; }
.ml-modal-sm { max-width:480px; }
@keyframes ml-slide-up { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
.ml-modal-header { padding:16px 20px; border-bottom:1px solid #e0e0e0; display:flex; align-items:center; justify-content:space-between; flex-shrink:0; }
.ml-modal-title { font-size:16px; font-weight:700; color:#242424; }
.ml-modal-body { flex:1; overflow-y:auto; padding:20px; }
.ml-modal-footer { padding:12px 20px; border-top:1px solid #e0e0e0; display:flex; align-items:center; justify-content:flex-end; gap:8px; flex-shrink:0; }
.ml-tabs { display:flex; border-bottom:1px solid #e0e0e0; margin-bottom:20px; flex-shrink:0; }
.ml-tab { padding:8px 16px; font-size:13px; font-weight:600; color:#616161; border:none; background:none; cursor:pointer; border-bottom:2px solid transparent; margin-bottom:-1px; transition:all .15s; }
.ml-tab.active { color:#0F6CBD; border-bottom-color:#0F6CBD; }
.ml-tab:hover:not(.active) { color:#242424; }
.ml-form-row { display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:14px; }
.ml-form-field { margin-bottom:14px; }
.ml-form-label { display:block; font-size:12px; font-weight:600; color:#424242; margin-bottom:4px; }
.ml-form-input { width:100%; padding:7px 10px; border:1px solid #d1d1d1; border-radius:4px; font-size:13px; outline:none; transition:border .15s; font-family:inherit; color:#242424; background:#fff; }
.ml-form-input:focus { border-color:#0F6CBD; box-shadow:0 0 0 2px rgba(15,108,189,.15); }
.ml-form-input:read-only { background:#f5f5f5; color:#707070; }
.ml-form-textarea { width:100%; padding:7px 10px; border:1px solid #d1d1d1; border-radius:4px; font-size:13px; outline:none; min-height:80px; resize:vertical; font-family:inherit; transition:border .15s; }
.ml-form-textarea:focus { border-color:#0F6CBD; }
.ml-form-hint { font-size:11px; color:#707070; margin-top:3px; }
.ml-form-required { color:#c50f1f; }
.ml-section-header { display:flex; align-items:center; gap:8px; margin-bottom:12px; }
.ml-section-icon { width:26px; height:26px; border-radius:6px; background:#ebf3fc; color:#0F6CBD; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.ml-section-icon svg { width:14px; height:14px; }
.ml-section-title { font-size:13px; font-weight:700; color:#242424; }
.ml-triage-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:8px; margin-bottom:16px; }
.ml-triage-opt { padding:10px 8px; border:2px solid #e0e0e0; border-radius:6px; cursor:pointer; text-align:center; transition:all .15s; background:#fff; }
.ml-triage-opt:hover { border-color:#707070; }
.ml-triage-label { font-size:12px; font-weight:700; margin-top:4px; }
.ml-triage-desc { font-size:10px; color:#707070; margin-top:2px; }
.ml-triage-dot { width:28px; height:28px; border-radius:50%; margin:0 auto 4px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:14px; }
.ml-vitals-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; margin-bottom:14px; }
.ml-vital { border:1px solid #e0e0e0; border-radius:6px; padding:10px; transition:all .15s; }
.ml-vital label { font-size:11px; font-weight:600; color:#707070; display:block; margin-bottom:4px; }
.ml-vital input { width:100%; border:none; outline:none; font-size:14px; font-weight:600; background:transparent; font-family:inherit; }
.ml-vital.alert { border-color:#c50f1f; background:#fde7e9; }
.ml-vital.warning { border-color:#f7630c; background:#fff4ce; }
.ml-vital.normal { border-color:#107c10; background:#f1faf1; }
.ml-vital-status { font-size:10px; font-weight:700; margin-top:2px; }
.ml-patient-card { background:#ebf3fc; border:1px solid #cfe4fa; border-radius:6px; padding:12px; margin-bottom:12px; position:relative; }
.ml-progress-bar { height:3px; background:#e0e0e0; border-radius:2px; overflow:hidden; margin:0 20px 0; flex:1; max-width:200px; }
.ml-progress-fill { height:100%; background:#0F6CBD; border-radius:2px; transition:width .3s; }
.ml-progress-text { font-size:11px; color:#707070; }
.ml-checkbox-field { display:flex; align-items:flex-start; gap:8px; padding:8px 10px; background:#fafafa; border-radius:4px; margin-bottom:6px; cursor:pointer; }
.ml-checkbox-field:hover { background:#f0f0f0; }
.ml-checkbox-field input { width:16px; height:16px; accent-color:#0F6CBD; margin-top:1px; flex-shrink:0; }
.ml-allergy-tags { display:flex; flex-wrap:wrap; gap:6px; margin-top:6px; }
.ml-allergy-tag { display:inline-flex; align-items:center; gap:5px; padding:3px 8px; background:#fde7e9; color:#a4262c; border-radius:12px; font-size:12px; font-weight:600; }
.ml-allergy-tag button { color:#a4262c; padding:0; border:none; background:none; cursor:pointer; font-size:14px; line-height:1; }
.ml-patient-db-item { display:flex; align-items:center; gap:10px; padding:8px 12px; border-bottom:1px solid #f0f0f0; transition:background .15s; }
.ml-patient-db-item:hover { background:#f5f5f5; }
.ml-toast { position:fixed; bottom:24px; right:24px; background:#242424; color:#fff; padding:10px 18px; border-radius:6px; box-shadow:0 4px 16px rgba(0,0,0,.2); font-size:13px; z-index:9999; display:flex; align-items:center; gap:10px; animation:ml-slide-up .3s; max-width:380px; }
.ml-toast.success { background:#107c10; }
.ml-toast.danger { background:#c50f1f; }
.ml-toast.warning { background:#ca5010; }
@media(max-width:900px) { .ml-navpane{display:none} .ml-msglist{flex:1;max-width:none} .ml-readpane{display:none} .ml-vitals-grid,.ml-triage-grid,.ml-form-row{grid-template-columns:1fr} }
`;

// ─── Main Component ───────────────────────────────────────────────────────────
export default function MedLink() {
  // Core state
  const [processes, setProcesses] = useState<Process[]>(INITIAL_PROCESSES);
  const [patients, setPatients] = useState<Patient[]>(() => SAMPLE_PATIENTS.map(makePatient));
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [currentFolder, setCurrentFolder] = useState<"inbox" | "sent" | "urgent" | "flagged" | "archive">("inbox");
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState<Toast | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Modals
  const [showNewProcess, setShowNewProcess] = useState(false);
  const [showPatientDb, setShowPatientDb] = useState(false);
  const [showNewPatient, setShowNewPatient] = useState(false);
  const [patientDbSearch, setPatientDbSearch] = useState("");

  // New process form
  const [modalTab, setModalTab] = useState(0);
  const [form, setForm] = useState({
    type: "", number: "", destination: "", subject: "",
    cid10: "", specialty: "", diagnosis: "", history: "",
    bp: "", hr: "", temp: "", spo2: "", rr: "", gly: "", weight: "",
    priority: "normal",
    insurance: false, insurerName: "", policyNum: "", authNum: "",
    consent: false, dnr: false, isolation: false, criticalPat: false,
    notes: "",
    allergyInput: "",
  });
  const [formAllergies, setFormAllergies] = useState<string[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [replyMode, setReplyMode] = useState(false);

  // New patient form
  const [newPatForm, setNewPatForm] = useState({
    name: "", nif: "", birth: "", gender: "", blood: "",
    phone: "", address: "", allergies: "", conditions: ""
  });

  // Toast helper
  const showToast = useCallback((msg: string, type = "") => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ msg, type });
    toastTimer.current = setTimeout(() => setToast(null), 3000);
  }, []);

  // Inject CSS once
  useEffect(() => {
    if (!document.getElementById("ml-styles")) {
      const style = document.createElement("style");
      style.id = "ml-styles";
      style.textContent = ML_STYLE;
      document.head.appendChild(style);
    }
    return () => {
      // leave style; multiple mounts rare
    };
  }, []);

  // ─── Filtered processes ────────────────────────────────────────────────────
  const filtered = processes.filter(p => {
    if (currentFolder === "archive") return p.archived;
    if (p.archived) return false;
    if (currentFolder === "sent") return p.sender === "Dr. Domingos Nvuala";
    if (currentFolder === "urgent") return p.priority === "emergency" || p.priority === "urgent";
    if (currentFolder === "flagged") return p.flagged;
    return true; // inbox = all non-archived
  }).filter(p => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      p.sender.toLowerCase().includes(q) ||
      p.subject.toLowerCase().includes(q) ||
      (p.patient && p.patient.toLowerCase().includes(q)) ||
      (p.patientNif && p.patientNif.toLowerCase().includes(q))
    );
  });

  // Group by date
  const grouped: Record<string, Process[]> = {};
  filtered.forEach(p => {
    const g = getGroup(p.date);
    if (!grouped[g]) grouped[g] = [];
    grouped[g].push(p);
  });

  const selectedProcess = processes.find(p => p.id === selectedId) ?? null;
  const unreadCount = processes.filter(p => !p.archived && p.unread).length;
  const urgentCount = processes.filter(p => !p.archived && (p.priority === "emergency" || p.priority === "urgent")).length;
  const flaggedCount = processes.filter(p => !p.archived && p.flagged).length;
  const archiveCount = processes.filter(p => p.archived).length;

  // ─── Process actions ───────────────────────────────────────────────────────
  function selectProcess(id: number) {
    setProcesses(ps => ps.map(p => p.id === id ? { ...p, unread: false } : p));
    setSelectedId(id);
  }

  function handleDelete() {
    if (!selectedId) return;
    setProcesses(ps => ps.filter(p => p.id !== selectedId));
    setSelectedId(null);
    showToast("Processo eliminado", "danger");
  }

  function handleArchive() {
    if (!selectedId) return;
    setProcesses(ps => ps.map(p => p.id === selectedId ? { ...p, archived: !p.archived } : p));
    const p = processes.find(x => x.id === selectedId);
    showToast(p?.archived ? "Processo restaurado" : "Processo arquivado", "");
    if (!p?.archived) setSelectedId(null);
  }

  function handleFlag() {
    if (!selectedId) return;
    setProcesses(ps => ps.map(p => p.id === selectedId ? { ...p, flagged: !p.flagged } : p));
    const p = processes.find(x => x.id === selectedId);
    showToast(p?.flagged ? "Marcação removida" : "Processo marcado 🚩", "");
  }

  function handleApprove() {
    if (!selectedId) return;
    setProcesses(ps => ps.map(p => p.id === selectedId ? { ...p, status: "approved", statusName: "Aprovado" } : p));
    showToast("Processo aprovado", "success");
  }

  function handleReject() {
    if (!selectedId) return;
    setProcesses(ps => ps.map(p => p.id === selectedId ? { ...p, status: "rejected", statusName: "Rejeitado" } : p));
    showToast("Processo rejeitado", "danger");
  }

  function handlePrint() {
    if (!selectedProcess) return;
    showToast("A preparar impressão...", "success");
    setTimeout(() => window.print(), 500);
  }

  function handleReply() {
    if (!selectedProcess) return;
    setReplyMode(true);
    setForm(f => ({
      ...f,
      type: selectedProcess.type,
      number: selectedProcess.processNumber,
      subject: "RE: " + selectedProcess.subject,
      destination: "",
    }));
    setModalTab(0);
    setShowNewProcess(true);
  }

  // ─── New process modal ────────────────────────────────────────────────────
  function openNewProcess() {
    setReplyMode(false);
    setSelectedPatient(null);
    setFormAllergies([]);
    setForm({
      type: "", number: "PRC-2026-" + String(Math.floor(Math.random() * 9000) + 1000),
      destination: "", subject: "", cid10: "", specialty: "",
      diagnosis: "", history: "", bp: "", hr: "", temp: "", spo2: "", rr: "", gly: "", weight: "",
      priority: "normal", insurance: false, insurerName: "", policyNum: "", authNum: "",
      consent: false, dnr: false, isolation: false, criticalPat: false, notes: "",
      allergyInput: "",
    });
    setModalTab(0);
    setShowNewProcess(true);
  }

  function formProgress() {
    let score = 0, total = 5;
    if (form.type) score++;
    if (form.destination) score++;
    if (form.subject.trim()) score++;
    if (selectedPatient) score++;
    if (form.diagnosis.trim()) score++;
    return Math.round((score / total) * 100);
  }

  function submitProcess() {
    if (!form.type || !form.destination || !form.subject.trim()) {
      showToast("Preencha os campos obrigatórios (Tipo, Destino e Assunto)", "danger");
      return;
    }
    const typeNames: Record<string, string> = {
      transfer: "Transferência", exam: "Pedido de Exame", consult: "Consulta",
      surgery: "Pedido Cirúrgico", auth: "Autorização", result: "Resultado de Exame",
      report: "Relatório Clínico", prescription: "Prescrição", internment: "Internamento",
      high: "Alta Clínica", second_opinion: "2ª Opinião", telemedicine: "Telemedicina",
    };
    const newProc: Process = {
      id: Date.now(),
      sender: "Dr. Domingos Nvuala",
      email: "d.nvuala@lab.ao",
      subject: form.subject,
      preview: form.diagnosis || "Processo clínico criado",
      date: new Date().toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" }),
      dateFull: new Date().toLocaleDateString("pt-PT", { weekday: "short", day: "2-digit", month: "2-digit", year: "numeric" }) + " " + new Date().toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" }),
      unread: false,
      priority: form.priority as Process["priority"],
      type: form.type,
      typeName: typeNames[form.type] ?? form.type,
      patient: selectedPatient?.name ?? "",
      patientNif: selectedPatient?.nif ?? "",
      insurer: form.insurerName,
      policy: form.policyNum,
      status: "pending",
      statusName: "Pendente",
      color: "#0F6CBD",
      initials: "DN",
      flagged: false,
      archived: false,
      processNumber: form.number,
      body: `<p><strong>Diagnóstico:</strong> ${form.diagnosis || "—"}</p><p><strong>Notas:</strong> ${form.notes || "—"}</p>`,
    };
    setProcesses(ps => [newProc, ...ps]);
    setShowNewProcess(false);
    showToast(replyMode ? "Resposta enviada com sucesso!" : "Processo criado e enviado!", "success");
  }

  // ─── Patient DB ────────────────────────────────────────────────────────────
  const filteredPatients = patients.filter(p => {
    if (!patientDbSearch) return true;
    const q = patientDbSearch.toLowerCase();
    return p.name.toLowerCase().includes(q) || p.nif.toLowerCase().includes(q) || p.phone.includes(q);
  });

  function saveNewPatient() {
    if (!newPatForm.name || !newPatForm.nif || !newPatForm.birth) {
      showToast("Preencha os campos obrigatórios (Nome, NIF e Data Nascimento)", "danger");
      return;
    }
    const saved = makePatient(newPatForm);
    setPatients(ps => [...ps, saved]);
    setSelectedPatient(saved);
    setNewPatForm({ name: "", nif: "", birth: "", gender: "", blood: "", phone: "", address: "", allergies: "", conditions: "" });
    setShowNewPatient(false);
    setShowPatientDb(false);
    showToast("Paciente registado com sucesso!", "success");
  }

  function deletePatient(id: string) {
    if (!window.confirm("Tem a certeza que pretende eliminar este paciente?")) return;
    setPatients(ps => ps.filter(p => p.id !== id));
    if (selectedPatient?.id === id) setSelectedPatient(null);
    showToast("Paciente eliminado", "danger");
  }

  // ─── Vitals ───────────────────────────────────────────────────────────────
  const vitalFields = [
    { key: "bp", label: "Tensão Arterial", placeholder: "120/80 mmHg", unit: "mmHg" },
    { key: "hr", label: "Frequência Cardíaca", placeholder: "60-100 bpm", unit: "bpm" },
    { key: "temp", label: "Temperatura", placeholder: "36-37°C", unit: "°C" },
    { key: "spo2", label: "SpO2", placeholder: "95-100%", unit: "%" },
    { key: "rr", label: "Frequência Respiratória", placeholder: "12-20/min", unit: "/min" },
    { key: "gly", label: "Glicemia", placeholder: "70-140 mg/dL", unit: "mg/dL" },
  ];

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <div className="ml-wrap" style={{ height: "100%" }}>
      {/* ── Titlebar ── */}
      <header className="ml-titlebar">
        <div className="ml-brand">
          <svg width="22" height="22" viewBox="0 0 20 20" fill="currentColor">
            <path d="M10 2a8 8 0 100 16 8 8 0 000-16zM9 5h2v4h4v2h-4v4H9v-4H5V9h4V5z"/>
          </svg>
          MedLink
        </div>
        <div className="ml-search">
          <svg width="16" height="16" viewBox="0 0 20 20" fill="#707070">
            <path d="M12.9 14.32a8 8 0 111.41-1.41l5.35 5.33-1.42 1.42-5.33-5.34zM8 14A6 6 0 108 2a6 6 0 000 12z"/>
          </svg>
          <input placeholder="Pesquisar processos, pacientes, NIF..." value={search}
            onChange={e => setSearch(e.target.value)} />
        </div>
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8 }}>
          <button className="ml-btn ml-btn-primary" onClick={openNewProcess} style={{ fontSize: 13 }}>
            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path d="M11 9V5H9v4H5v2h4v4h2v-4h4V9h-4z"/></svg>
            Novo Processo
          </button>
          <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg,#0F6CBD,#0078d4)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 13 }}>DN</div>
        </div>
      </header>

      <div className="ml-main">
        {/* ── Left Rail ── */}
        <nav className="ml-leftrail">
          {[
            { icon: <path d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm1 3a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1zm0 3a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1zm0 3a1 1 0 011-1h5a1 1 0 110 2H6a1 1 0 01-1-1z"/>, active: true, label: "Processos" },
            { icon: <path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-6 8a6 6 0 0112 0H4z"/>, active: false, label: "Pacientes", onClick: () => setShowPatientDb(true) },
            { icon: <path d="M12 2L4 6v6c0 5.5 3.8 10.7 8 12 4.2-1.3 8-6.5 8-12V6l-8-4z"/>, active: false, label: "Asseguradoras" },
            { icon: <path d="M8 2v5L3 15a2 2 0 002 2h10a2 2 0 002-2l-5-8V2H8zm2 0v5.5l4.5 7h-9L10 7.5V2z"/>, active: false, label: "Laboratórios" },
          ].map((b, i) => (
            <button key={i} className={`ml-rail-btn${b.active ? " active" : ""}`} title={b.label} onClick={b.onClick}>
              <svg viewBox="0 0 20 20" fill="currentColor">{b.icon}</svg>
            </button>
          ))}
          <div className="ml-rail-divider" />
          <button className="ml-rail-btn" title="Agenda">
            <svg viewBox="0 0 20 20" fill="currentColor"><path d="M14.5 3A2.5 2.5 0 0117 5.5v10a2.5 2.5 0 01-2.5 2.5h-9A2.5 2.5 0 013 15.5v-10A2.5 2.5 0 015.5 3h9zm0 2h-9c-.28 0-.5.22-.5.5V7h12v-1.5c0-.28-.22-.5-.5-.5zM4 9v6.5c0 .28.22.5.5.5h9c.28 0 .5-.22.5-.5V9H4z"/></svg>
          </button>
          <button className="ml-rail-btn" title="Relatórios">
            <svg viewBox="0 0 20 20" fill="currentColor"><path d="M2 17h16v2H2v-2zm1-5h2v4H3v-4zm4-4h2v8H7V8zm4-4h2v12h-2V4zm4 6h2v6h-2v-6z"/></svg>
          </button>
        </nav>

        {/* ── Nav Pane ── */}
        <aside className="ml-navpane">
          <div className="ml-nav-header">
            <span className="ml-nav-title">MedLink</span>
            <button className="ml-btn ml-btn-ghost" style={{ padding: "3px 8px", fontSize: 11 }} onClick={openNewProcess}>+ Novo</button>
          </div>
          <div className="ml-nav-list">
            <div className="ml-nav-section-title">Caixas Principais</div>
            {([
              { key: "inbox", label: "Processos Recebidos", count: unreadCount, danger: true },
              { key: "sent", label: "Processos Enviados", count: 47, danger: false },
              { key: "urgent", label: "Urgentes", count: urgentCount, danger: urgentCount > 0 },
            ] as const).map(f => (
              <div key={f.key} className={`ml-nav-item${currentFolder === f.key ? " selected" : ""}`}
                onClick={() => { setCurrentFolder(f.key); setSelectedId(null); }}>
                <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16">
                  {f.key === "inbox" && <path d="M3 5a2 2 0 012-2h10a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2V5zm2 0l5 4 5-4H5zm10 1.5L10 10 5 6.5V15h10V6.5z"/>}
                  {f.key === "sent" && <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/>}
                  {f.key === "urgent" && <path d="M10 2l8 14H2L10 2zm0 5v4m0 2v1"/>}
                </svg>
                <span style={{ flex: 1, fontSize: 13 }}>{f.label}</span>
                {f.count > 0 && <span className={`ml-nav-count${f.danger ? "" : " normal"}`}>{f.count}</span>}
              </div>
            ))}
            <div style={{ height: 8 }} />
            <div className="ml-nav-section-title">Pastas</div>
            {([
              { key: "flagged", label: "Marcados", count: flaggedCount },
              { key: "archive", label: "Arquivo", count: archiveCount },
            ] as const).map(f => (
              <div key={f.key} className={`ml-nav-item${currentFolder === f.key ? " selected" : ""}`}
                onClick={() => { setCurrentFolder(f.key); setSelectedId(null); }}>
                <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16">
                  {f.key === "flagged" && <path d="M3 6a3 3 0 013-3h10l-1.5 5L16 13H6a3 3 0 01-3-3V6z"/>}
                  {f.key === "archive" && <path d="M4 3a2 2 0 00-2 2v1a1 1 0 001 1h14a1 1 0 001-1V5a2 2 0 00-2-2H4zm-1 5v7a2 2 0 002 2h10a2 2 0 002-2V8H3zm6 1h2a1 1 0 110 2H9a1 1 0 110-2z"/>}
                </svg>
                <span style={{ flex: 1, fontSize: 13 }}>{f.label}</span>
                {f.count > 0 && <span className="ml-nav-count normal">{f.count}</span>}
              </div>
            ))}
          </div>
          <div style={{ padding: "12px 16px", borderTop: "1px solid #e0e0e0" }}>
            <button className="ml-btn ml-btn-ghost" style={{ width: "100%", justifyContent: "center", fontSize: 12 }}
              onClick={() => setShowPatientDb(true)}>
              <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-6 8a6 6 0 0112 0H4z"/></svg>
              Base de Dados ({patients.length} pacientes)
            </button>
          </div>
        </aside>

        {/* ── Message List ── */}
        <div className="ml-msglist">
          <div className="ml-msglist-header">
            <span style={{ fontSize: 13, fontWeight: 700, color: "#242424", marginRight: "auto" }}>
              {currentFolder === "inbox" ? "Recebidos" : currentFolder === "sent" ? "Enviados" :
               currentFolder === "urgent" ? "Urgentes" : currentFolder === "flagged" ? "Marcados" : "Arquivo"}
              {" "}
              <span style={{ color: "#707070", fontWeight: 400 }}>({filtered.length})</span>
            </span>
          </div>
          <div className="ml-messages">
            {Object.keys(grouped).length === 0 && (
              <div style={{ padding: 40, textAlign: "center", color: "#707070" }}>Nenhum processo encontrado</div>
            )}
            {Object.entries(grouped).map(([grp, items]) => (
              <div key={grp}>
                <div className="ml-month">▼ {grp}</div>
                {items.map(p => (
                  <div key={p.id} className={`ml-message${selectedId === p.id ? " selected" : ""}${p.unread ? " unread" : ""}`}
                    onClick={() => selectProcess(p.id)}>
                    <div className="ml-msg-avatar" style={{ background: p.color }}>{p.initials}</div>
                    <div className="ml-msg-content">
                      <div className="ml-msg-header">
                        <span className="ml-msg-sender" style={{ fontWeight: p.unread ? 700 : 400, color: p.unread ? "#0F6CBD" : "#242424" }}>
                          {p.sender}
                        </span>
                        <span className="ml-msg-date">{p.flagged ? "🚩 " : ""}{p.date}</span>
                      </div>
                      <div className="ml-msg-subject">
                        <span className="ml-badge" style={{ background: priorityBg(p.priority), color: priorityColor(p.priority) }}>
                          {priorityLabel(p.priority)}
                        </span>
                        {p.subject}
                      </div>
                      <div className="ml-msg-preview">{p.preview}</div>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>

        {/* ── Reading Pane ── */}
        <div className="ml-readpane">
          {!selectedProcess ? (
            <div className="ml-rp-empty">
              <svg viewBox="0 0 20 20" fill="currentColor">
                <path d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm1 3a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1zm0 3a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1zm0 3a1 1 0 011-1h5a1 1 0 110 2H6a1 1 0 01-1-1z"/>
              </svg>
              <div style={{ fontSize: 18, fontWeight: 600, color: "#424242" }}>Nenhum processo selecionado</div>
              <div style={{ fontSize: 14 }}>Selecione um processo para ver os detalhes</div>
              <button className="ml-btn ml-btn-primary" onClick={openNewProcess}>Criar Novo Processo</button>
            </div>
          ) : (
            <>
              {/* Toolbar */}
              <div className="ml-rp-toolbar">
                <button className="ml-icoBtn" title="Eliminar" onClick={handleDelete} style={{ color: "#c50f1f" }}>
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M8.5 3c-.83 0-1.5.67-1.5 1.5V5H4a1 1 0 100 2h1v9a2 2 0 002 2h6a2 2 0 002-2V7h1a1 1 0 100-2h-3v-.5c0-.83-.67-1.5-1.5-1.5h-3z"/></svg>
                </button>
                <button className="ml-icoBtn" title={selectedProcess.archived ? "Restaurar" : "Arquivar"} onClick={handleArchive}>
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M4 3a2 2 0 00-2 2v1a1 1 0 001 1h14a1 1 0 001-1V5a2 2 0 00-2-2H4zm-1 5v7a2 2 0 002 2h10a2 2 0 002-2V8H3zm6 1h2a1 1 0 110 2H9a1 1 0 110-2z"/></svg>
                </button>
                <button className="ml-icoBtn" title={selectedProcess.flagged ? "Remover marcação" : "Marcar"} onClick={handleFlag}
                  style={{ color: selectedProcess.flagged ? "#ca5010" : undefined }}>
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M3 6a3 3 0 013-3h10l-1.5 5L16 13H6a3 3 0 01-3-3V6z"/></svg>
                </button>
                <div style={{ width: 1, height: 20, background: "#e0e0e0", margin: "0 4px" }} />
                <button className="ml-icoBtn" title="Responder" onClick={handleReply}>
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M8 7.5L3 12l5 4.5V13c5.5 0 9 2 11 6-1-6-4-10-11-10.5V7.5z"/></svg>
                </button>
                <button className="ml-icoBtn" title="Reencaminhar">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M12 7.5L17 12l-5 4.5V13c-5.5 0-9 2-11 6 1-6 4-10 11-10.5V7.5z"/></svg>
                </button>
                <div style={{ width: 1, height: 20, background: "#e0e0e0", margin: "0 4px" }} />
                <button className="ml-btn ml-btn-ghost" style={{ fontSize: 12, padding: "4px 10px" }} onClick={handleApprove}>
                  ✓ Aprovar
                </button>
                <button className="ml-btn ml-btn-danger" style={{ fontSize: 12, padding: "4px 10px" }} onClick={handleReject}>
                  ✕ Rejeitar
                </button>
                <button className="ml-icoBtn" title="Imprimir" style={{ marginLeft: "auto" }} onClick={handlePrint}>
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M5 4v3H4a2 2 0 00-2 2v5a2 2 0 002 2h1v2a1 1 0 001 1h8a1 1 0 001-1v-2h1a2 2 0 002-2V9a2 2 0 00-2-2h-1V4a1 1 0 00-1-1H6a1 1 0 00-1 1zm2 0h6v3H7V4zm7 11v1H6v-1a1 1 0 011-1h6a1 1 0 011 1zm-9-4a1 1 0 110-2 1 1 0 010 2z"/></svg>
                </button>
              </div>

              {/* Content */}
              <div className="ml-rp-body-scroll">
                <div className="ml-rp-header">
                  <div className="ml-rp-subject">
                    <span className="ml-badge" style={{ background: priorityBg(selectedProcess.priority), color: priorityColor(selectedProcess.priority), fontSize: 11 }}>
                      {priorityLabel(selectedProcess.priority)}
                    </span>
                    <span>{selectedProcess.subject}</span>
                    {selectedProcess.flagged && <span title="Marcado">🚩</span>}
                  </div>
                  {/* Meta grid */}
                  <div className="ml-rp-meta">
                    <div>
                      <div className="ml-rp-meta-label">Nº Processo</div>
                      <div className="ml-rp-meta-value">{selectedProcess.processNumber}</div>
                    </div>
                    <div>
                      <div className="ml-rp-meta-label">Tipo</div>
                      <div className="ml-rp-meta-value">{selectedProcess.typeName}</div>
                    </div>
                    {selectedProcess.patient && <>
                      <div>
                        <div className="ml-rp-meta-label">Paciente</div>
                        <div className="ml-rp-meta-value">{selectedProcess.patient}</div>
                      </div>
                      <div>
                        <div className="ml-rp-meta-label">NIF/BI</div>
                        <div className="ml-rp-meta-value">{selectedProcess.patientNif}</div>
                      </div>
                    </>}
                    {selectedProcess.insurer && <>
                      <div>
                        <div className="ml-rp-meta-label">Asseguradora</div>
                        <div className="ml-rp-meta-value">{selectedProcess.insurer}</div>
                      </div>
                      <div>
                        <div className="ml-rp-meta-label">Nº Apólice</div>
                        <div className="ml-rp-meta-value">{selectedProcess.policy}</div>
                      </div>
                    </>}
                  </div>
                  {/* Sender row */}
                  <div className="ml-rp-sender-row">
                    <div className="ml-rp-avatar" style={{ background: selectedProcess.color }}>{selectedProcess.initials}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, fontSize: 14 }}>{selectedProcess.sender}</div>
                      <div style={{ fontSize: 12, color: "#707070" }}>&lt;{selectedProcess.email}&gt;</div>
                    </div>
                    <div style={{ fontSize: 12, color: "#707070" }}>{selectedProcess.dateFull}</div>
                  </div>
                </div>

                {/* Body */}
                <div className="ml-rp-body" dangerouslySetInnerHTML={{ __html: selectedProcess.body }} />

                {/* Status bar */}
                <div className="ml-rp-status">
                  <span>Estado:</span>
                  <span className="ml-status-pill" style={statusStyle(statusClass(selectedProcess.status))}>
                    ● {selectedProcess.statusName}
                  </span>
                  <span style={{ marginLeft: "auto", color: "#707070", fontSize: 12 }}>
                    Prioridade: {priorityLabel(selectedProcess.priority)}
                  </span>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* ═══════════════ MODAL: Novo Processo ═══════════════ */}
      {showNewProcess && (
        <div className="ml-modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowNewProcess(false); }}>
          <div className="ml-modal ml-modal-lg">
            <div className="ml-modal-header">
              <span className="ml-modal-title">{replyMode ? "Responder ao Processo" : "Novo Processo Clínico"}</span>
              <div style={{ display: "flex", alignItems: "center", gap: 12, flex: 1, justifyContent: "flex-end" }}>
                <div className="ml-progress-text">{formProgress()}% preenchido</div>
                <div className="ml-progress-bar">
                  <div className="ml-progress-fill" style={{ width: formProgress() + "%" }} />
                </div>
                <button className="ml-icoBtn" onClick={() => setShowNewProcess(false)}>
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"/></svg>
                </button>
              </div>
            </div>

            {/* Tabs */}
            <div className="ml-tabs" style={{ padding: "0 20px", margin: 0, borderBottom: "1px solid #e0e0e0", flexShrink: 0 }}>
              {["Identificação", "Dados Clínicos", "Documentação", "Revisão"].map((t, i) => (
                <button key={i} className={`ml-tab${modalTab === i ? " active" : ""}`} onClick={() => setModalTab(i)}>{t}</button>
              ))}
            </div>

            <div className="ml-modal-body">
              {/* Tab 0: Identificação */}
              {modalTab === 0 && (
                <>
                  <div className="ml-section-header">
                    <div className="ml-section-icon"><svg viewBox="0 0 20 20" fill="currentColor" style={{ width: 14, height: 14 }}><path d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm1 3a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1zm0 3a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1zm0 3a1 1 0 011-1h5a1 1 0 110 2H6a1 1 0 01-1-1z"/></svg></div>
                    <span className="ml-section-title">Identificação do Processo</span>
                  </div>
                  <div className="ml-form-row">
                    <div className="ml-form-field">
                      <label className="ml-form-label">Tipo de Processo <span className="ml-form-required">*</span></label>
                      <select className="ml-form-input" value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
                        <option value="">— Selecionar —</option>
                        <option value="transfer">🚑 Transferência de Paciente</option>
                        <option value="exam">🔬 Pedido de Exame</option>
                        <option value="consult">👨‍⚕️ Pedido de Consulta Especializada</option>
                        <option value="surgery">🏥 Pedido Cirúrgico</option>
                        <option value="auth">🛡️ Autorização Asseguradora</option>
                        <option value="result">📊 Resultado de Exame</option>
                        <option value="report">📋 Relatório Clínico</option>
                        <option value="prescription">💊 Prescrição Médica</option>
                        <option value="internment">🛏️ Internamento</option>
                        <option value="high">📤 Alta Clínica</option>
                        <option value="second_opinion">🔄 2ª Opinião Médica</option>
                        <option value="telemedicine">💻 Telemedicina</option>
                      </select>
                    </div>
                    <div className="ml-form-field">
                      <label className="ml-form-label">Nº Processo</label>
                      <input className="ml-form-input" value={form.number} readOnly />
                    </div>
                  </div>
                  <div className="ml-form-row">
                    <div className="ml-form-field">
                      <label className="ml-form-label">Instituição de Origem</label>
                      <input className="ml-form-input" value="Hospital Américo Boavida - Luanda" readOnly />
                    </div>
                    <div className="ml-form-field">
                      <label className="ml-form-label">Instituição de Destino <span className="ml-form-required">*</span></label>
                      <select className="ml-form-input" value={form.destination} onChange={e => setForm(f => ({ ...f, destination: e.target.value }))}>
                        <option value="">— Selecionar —</option>
                        <optgroup label="Hospitais">
                          <option value="hab">Hospital Américo Boavida</option>
                          <option value="hpl">Hospital Principal de Luanda</option>
                          <option value="hjm">Hospital José Maria Mendes</option>
                          <option value="hsa">Hospital Santa Maria</option>
                        </optgroup>
                        <optgroup label="Clínicas">
                          <option value="cse">Clínica Sagrada Esperança</option>
                          <option value="cvm">Clínica Vila Mariana</option>
                          <option value="csao">Clínica Santo António</option>
                        </optgroup>
                        <optgroup label="Laboratórios">
                          <option value="medan">Laboratório MedAnálises</option>
                          <option value="biotech">Laboratório BioTech</option>
                        </optgroup>
                        <optgroup label="Asseguradoras">
                          <option value="multicare">Multicare Angola</option>
                          <option value="ens">ENS - Empresa Nacional de Seguros</option>
                          <option value="alianca">Aliança Seguros</option>
                        </optgroup>
                      </select>
                    </div>
                  </div>
                  <div className="ml-form-field">
                    <label className="ml-form-label">Assunto <span className="ml-form-required">*</span></label>
                    <input className="ml-form-input" value={form.subject} placeholder="Ex: Transferência urgente - AVC isquémico"
                      onChange={e => setForm(f => ({ ...f, subject: e.target.value }))} />
                  </div>

                  {/* Patient selection */}
                  <div className="ml-section-header" style={{ marginTop: 20 }}>
                    <div className="ml-section-icon"><svg viewBox="0 0 20 20" fill="currentColor" style={{ width: 14, height: 14 }}><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-6 8a6 6 0 0112 0H4z"/></svg></div>
                    <span className="ml-section-title">Paciente</span>
                    <button className="ml-btn ml-btn-ghost" style={{ fontSize: 11, padding: "2px 8px", marginLeft: "auto" }}
                      onClick={() => setShowPatientDb(true)}>+ Selecionar</button>
                    <button className="ml-btn ml-btn-ghost" style={{ fontSize: 11, padding: "2px 8px" }}
                      onClick={() => { setShowPatientDb(false); setShowNewPatient(true); }}>+ Novo Paciente</button>
                  </div>
                  {selectedPatient ? (
                    <div className="ml-patient-card">
                      <button style={{ position: "absolute", top: 8, right: 8, color: "#c50f1f", background: "none", border: "none", cursor: "pointer", fontSize: 16, lineHeight: 1 }}
                        onClick={() => setSelectedPatient(null)}>✕</button>
                      <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 4 }}>{selectedPatient.name}</div>
                      <div style={{ fontSize: 12, color: "#424242", display: "flex", gap: 16, flexWrap: "wrap" }}>
                        {selectedPatient.nif && <span>NIF: {selectedPatient.nif}</span>}
                        {selectedPatient.birth && <span>Idade: {calculateAge(selectedPatient.birth)} anos</span>}
                        {selectedPatient.blood && <span>Grupo: {selectedPatient.blood}</span>}
                        {selectedPatient.phone && <span>Tel: {selectedPatient.phone}</span>}
                      </div>
                      {selectedPatient.allergies && (
                        <div style={{ marginTop: 6 }}>
                          <div className="ml-allergy-tags">
                            {selectedPatient.allergies.split(",").map(a => (
                              <span key={a} className="ml-allergy-tag">{a.trim()}</span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div style={{ padding: "14px 16px", background: "#fafafa", border: "1px dashed #d1d1d1", borderRadius: 6, textAlign: "center", color: "#707070", fontSize: 13, marginBottom: 14 }}>
                      Nenhum paciente selecionado — clique em "Selecionar" ou "Novo Paciente"
                    </div>
                  )}
                </>
              )}

              {/* Tab 1: Dados Clínicos */}
              {modalTab === 1 && (
                <>
                  <div className="ml-section-header">
                    <div className="ml-section-icon"><svg viewBox="0 0 20 20" fill="currentColor" style={{ width: 14, height: 14 }}><path d="M10 2a8 8 0 100 16 8 8 0 000-16zM9 5h2v4h4v2h-4v4H9v-4H5V9h4V5z"/></svg></div>
                    <span className="ml-section-title">Diagnóstico & Classificação</span>
                  </div>
                  <div className="ml-form-row">
                    <div className="ml-form-field">
                      <label className="ml-form-label">Código CID-10</label>
                      <input className="ml-form-input" value={form.cid10} placeholder="Ex: I63 - Enfarto cerebral"
                        onChange={e => setForm(f => ({ ...f, cid10: e.target.value }))} />
                    </div>
                    <div className="ml-form-field">
                      <label className="ml-form-label">Especialidade Médica</label>
                      <select className="ml-form-input" value={form.specialty} onChange={e => setForm(f => ({ ...f, specialty: e.target.value }))}>
                        <option value="">— Selecionar —</option>
                        {["Cardiologia","Neurologia","Ortopedia","Pediatria","Ginecologia/Obstetrícia","Cirurgia Geral","Medicina Interna","Oncologia","Psiquiatria","Dermatologia","Oftalmologia","ORL","Urologia","Nefrologia","Pneumologia","Endocrinologia","Gastroenterologia","Medicina de Urgência"].map(s => (
                          <option key={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="ml-form-field">
                    <label className="ml-form-label">Diagnóstico Principal <span className="ml-form-required">*</span></label>
                    <textarea className="ml-form-textarea" value={form.diagnosis} placeholder="Descreva o diagnóstico principal..."
                      onChange={e => setForm(f => ({ ...f, diagnosis: e.target.value }))} />
                  </div>
                  <div className="ml-form-field">
                    <label className="ml-form-label">História Clínica / Anamnese</label>
                    <textarea className="ml-form-textarea" value={form.history} placeholder="História clínica relevante, antecedentes..."
                      onChange={e => setForm(f => ({ ...f, history: e.target.value }))} />
                  </div>

                  {/* Sinais Vitais */}
                  <div className="ml-section-header" style={{ marginTop: 20 }}>
                    <div className="ml-section-icon"><svg viewBox="0 0 20 20" fill="currentColor" style={{ width: 14, height: 14 }}><path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z"/></svg></div>
                    <span className="ml-section-title">Sinais Vitais</span>
                  </div>
                  <div className="ml-vitals-grid">
                    {vitalFields.map(v => {
                      const val = form[v.key as keyof typeof form] as string;
                      const level = vitalAlert(v.key, val);
                      return (
                        <div key={v.key} className={`ml-vital${level ? " " + level : ""}`}>
                          <label>{v.label}</label>
                          <input type="text" value={val} placeholder={v.placeholder}
                            style={{ color: level ? vitalColor(level) : "#242424" }}
                            onChange={e => setForm(f => ({ ...f, [v.key]: e.target.value }))} />
                          {level && (
                            <div className="ml-vital-status" style={{ color: vitalColor(level) }}>
                              {level === "alert" ? "⚠ Crítico" : level === "warning" ? "↑ Alterado" : "✓ Normal"}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Triagem */}
                  <div className="ml-section-header" style={{ marginTop: 16 }}>
                    <div className="ml-section-icon"><svg viewBox="0 0 20 20" fill="currentColor" style={{ width: 14, height: 14 }}><path d="M10 2l8 14H2L10 2z"/></svg></div>
                    <span className="ml-section-title">Triagem de Prioridade</span>
                  </div>
                  <div className="ml-triage-grid">
                    {[
                      { key: "emergency", label: "Emergência", desc: "Risco de vida imediato", icon: "🔴", bg: "#fde7e9", border: "#a4262c" },
                      { key: "urgent", label: "Urgente", desc: "< 30 min", icon: "🟠", bg: "#fff4ce", border: "#ca5010" },
                      { key: "normal", label: "Normal", desc: "< 2 horas", icon: "🔵", bg: "#ebf3fc", border: "#0078d4" },
                      { key: "low", label: "Baixa", desc: "Programado", icon: "🟢", bg: "#f1faf1", border: "#107c10" },
                    ].map(opt => (
                      <div key={opt.key} className="ml-triage-opt"
                        style={form.priority === opt.key ? { borderColor: opt.border, background: opt.bg } : {}}
                        onClick={() => setForm(f => ({ ...f, priority: opt.key }))}>
                        <div className="ml-triage-dot" style={{ background: opt.border }}>{opt.icon}</div>
                        <div className="ml-triage-label" style={{ color: form.priority === opt.key ? opt.border : "#242424" }}>{opt.label}</div>
                        <div className="ml-triage-desc">{opt.desc}</div>
                      </div>
                    ))}
                  </div>

                  {/* Alergias */}
                  <div className="ml-form-field">
                    <label className="ml-form-label">Alergias Conhecidas</label>
                    <div style={{ display: "flex", gap: 6 }}>
                      <input className="ml-form-input" value={form.allergyInput} placeholder="Ex: Penicilina — pressione Enter para adicionar"
                        style={{ flex: 1 }}
                        onChange={e => setForm(f => ({ ...f, allergyInput: e.target.value }))}
                        onKeyDown={e => {
                          if (e.key === "Enter" && form.allergyInput.trim()) {
                            setFormAllergies(a => [...a, form.allergyInput.trim()]);
                            setForm(f => ({ ...f, allergyInput: "" }));
                          }
                        }} />
                      <button className="ml-btn ml-btn-ghost" onClick={() => {
                        if (form.allergyInput.trim()) {
                          setFormAllergies(a => [...a, form.allergyInput.trim()]);
                          setForm(f => ({ ...f, allergyInput: "" }));
                        }
                      }}>+ Adicionar</button>
                    </div>
                    {formAllergies.length > 0 && (
                      <div className="ml-allergy-tags">
                        {formAllergies.map((al, i) => (
                          <span key={i} className="ml-allergy-tag">
                            {al}
                            <button onClick={() => setFormAllergies(a => a.filter((_, j) => j !== i))}>×</button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </>
              )}

              {/* Tab 2: Documentação */}
              {modalTab === 2 && (
                <>
                  <div className="ml-section-header">
                    <div className="ml-section-icon"><svg viewBox="0 0 20 20" fill="currentColor" style={{ width: 14, height: 14 }}><path d="M9 2a2 2 0 00-2 2v1H5a2 2 0 00-2 2v9a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2V4a2 2 0 00-2-2H9zm0 2h2v1H9V4zM5 7h10v9H5V7z"/></svg></div>
                    <span className="ml-section-title">Seguro & Autorização</span>
                  </div>
                  <label className="ml-checkbox-field">
                    <input type="checkbox" checked={form.insurance}
                      onChange={e => setForm(f => ({ ...f, insurance: e.target.checked }))} />
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>Paciente tem seguro de saúde</div>
                      <div style={{ fontSize: 11, color: "#707070" }}>Preencha os dados da apólice</div>
                    </div>
                  </label>
                  {form.insurance && (
                    <div style={{ marginTop: 10, marginBottom: 14 }}>
                      <div className="ml-form-row">
                        <div className="ml-form-field">
                          <label className="ml-form-label">Seguradora</label>
                          <input className="ml-form-input" value={form.insurerName} placeholder="Nome da seguradora"
                            onChange={e => setForm(f => ({ ...f, insurerName: e.target.value }))} />
                        </div>
                        <div className="ml-form-field">
                          <label className="ml-form-label">Nº Apólice</label>
                          <input className="ml-form-input" value={form.policyNum} placeholder="Ex: MC-2024-78451"
                            onChange={e => setForm(f => ({ ...f, policyNum: e.target.value }))} />
                        </div>
                      </div>
                      <div className="ml-form-field">
                        <label className="ml-form-label">Nº Autorização (se disponível)</label>
                        <input className="ml-form-input" value={form.authNum} placeholder="Ex: AUT-2026-4521"
                          onChange={e => setForm(f => ({ ...f, authNum: e.target.value }))} />
                      </div>
                    </div>
                  )}

                  <div className="ml-section-header" style={{ marginTop: 16 }}>
                    <div className="ml-section-icon"><svg viewBox="0 0 20 20" fill="currentColor" style={{ width: 14, height: 14 }}><path d="M10 2a8 8 0 100 16 8 8 0 000-16zm4.7 5.3l-5 5a1 1 0 01-1.4 0l-2-2a1 1 0 011.4-1.4L9 10.17l4.3-4.3a1 1 0 011.4 1.4z"/></svg></div>
                    <span className="ml-section-title">Declarações & Consentimentos</span>
                  </div>
                  {[
                    { key: "consent", label: "Consentimento informado obtido", hint: "Paciente ou representante legal assinou o consentimento" },
                    { key: "dnr", label: "Paciente com Ordem DNR", hint: "Não reanimar — documentação em arquivo" },
                    { key: "isolation", label: "Requer precauções de isolamento", hint: "Indicar medidas específicas nas notas" },
                    { key: "criticalPat", label: "Paciente crítico / instável", hint: "Requer monitorização contínua durante transferência" },
                  ].map(item => (
                    <label key={item.key} className="ml-checkbox-field">
                      <input type="checkbox" checked={form[item.key as keyof typeof form] as boolean}
                        onChange={e => setForm(f => ({ ...f, [item.key]: e.target.checked }))} />
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 600 }}>{item.label}</div>
                        <div style={{ fontSize: 11, color: "#707070" }}>{item.hint}</div>
                      </div>
                    </label>
                  ))}

                  <div className="ml-section-header" style={{ marginTop: 20 }}>
                    <div className="ml-section-icon"><svg viewBox="0 0 20 20" fill="currentColor" style={{ width: 14, height: 14 }}><path d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"/></svg></div>
                    <span className="ml-section-title">Documentos Anexados</span>
                  </div>
                  <div style={{ border: "2px dashed #d1d1d1", borderRadius: 8, padding: "24px 20px", textAlign: "center", color: "#707070", background: "#fafafa", cursor: "pointer" }}>
                    <div style={{ fontSize: 28, marginBottom: 8 }}>📎</div>
                    <div style={{ fontWeight: 600, marginBottom: 4 }}>Arrastar ficheiros ou clicar para carregar</div>
                    <div style={{ fontSize: 12 }}>PDF, JPEG, PNG, DICOM — máx. 50 MB por ficheiro</div>
                  </div>
                </>
              )}

              {/* Tab 3: Revisão */}
              {modalTab === 3 && (
                <>
                  <div style={{ background: "#f5f5f5", borderRadius: 8, padding: 16, marginBottom: 16 }}>
                    <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 12, color: "#242424" }}>Resumo do Processo</div>
                    {[
                      ["Nº Processo", form.number],
                      ["Tipo", form.type || "—"],
                      ["Destino", form.destination || "—"],
                      ["Assunto", form.subject || "—"],
                      ["Paciente", selectedPatient?.name || "—"],
                      ["Diagnóstico", form.diagnosis || "—"],
                      ["Prioridade", priorityLabel(form.priority)],
                    ].map(([label, val]) => (
                      <div key={label} style={{ display: "flex", gap: 12, padding: "5px 0", borderBottom: "1px solid #e0e0e0" }}>
                        <span style={{ width: 120, fontSize: 12, fontWeight: 600, color: "#707070", flexShrink: 0 }}>{label}</span>
                        <span style={{ fontSize: 13, color: "#242424" }}>{val}</span>
                      </div>
                    ))}
                  </div>
                  {(!form.type || !form.destination || !form.subject.trim()) && (
                    <div style={{ background: "#fff4ce", border: "1px solid #f7630c", borderRadius: 6, padding: "10px 14px", fontSize: 13, color: "#8a6d0b", marginBottom: 12 }}>
                      ⚠ Campos obrigatórios em falta: {[!form.type && "Tipo", !form.destination && "Destino", !form.subject.trim() && "Assunto"].filter(Boolean).join(", ")}
                    </div>
                  )}
                  <div className="ml-form-field">
                    <label className="ml-form-label">Notas Adicionais</label>
                    <textarea className="ml-form-textarea" value={form.notes} placeholder="Observações finais, instruções especiais..."
                      onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
                  </div>
                </>
              )}
            </div>

            <div className="ml-modal-footer">
              {modalTab > 0 && (
                <button className="ml-btn ml-btn-ghost" onClick={() => setModalTab(t => t - 1)}>← Anterior</button>
              )}
              {modalTab < 3 ? (
                <button className="ml-btn ml-btn-primary" onClick={() => setModalTab(t => t + 1)}>Seguinte →</button>
              ) : (
                <button className="ml-btn ml-btn-primary" onClick={submitProcess}>
                  <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/></svg>
                  {replyMode ? "Enviar Resposta" : "Criar & Enviar Processo"}
                </button>
              )}
              <button className="ml-btn ml-btn-ghost" onClick={() => setShowNewProcess(false)}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════ MODAL: Base de Dados de Pacientes ═══════════════ */}
      {showPatientDb && (
        <div className="ml-modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowPatientDb(false); }}>
          <div className="ml-modal ml-modal-lg">
            <div className="ml-modal-header">
              <span className="ml-modal-title">Base de Dados de Pacientes ({patients.length})</span>
              <div style={{ display: "flex", gap: 8, marginLeft: "auto" }}>
                <button className="ml-btn ml-btn-primary" style={{ fontSize: 12 }} onClick={() => { setShowPatientDb(false); setShowNewPatient(true); }}>+ Novo Paciente</button>
                <button className="ml-icoBtn" onClick={() => setShowPatientDb(false)}>
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"/></svg>
                </button>
              </div>
            </div>
            <div style={{ padding: "12px 20px", borderBottom: "1px solid #e0e0e0" }}>
              <div className="ml-search" style={{ maxWidth: "100%" }}>
                <svg width="16" height="16" viewBox="0 0 20 20" fill="#707070"><path d="M12.9 14.32a8 8 0 111.41-1.41l5.35 5.33-1.42 1.42-5.33-5.34zM8 14A6 6 0 108 2a6 6 0 000 12z"/></svg>
                <input placeholder="Pesquisar por nome, NIF ou telefone..." value={patientDbSearch}
                  onChange={e => setPatientDbSearch(e.target.value)} />
              </div>
            </div>
            <div className="ml-modal-body" style={{ padding: 0 }}>
              {filteredPatients.length === 0 ? (
                <div style={{ padding: 40, textAlign: "center", color: "#707070" }}>Nenhum paciente encontrado</div>
              ) : filteredPatients.map(p => (
                <div key={p.id} className="ml-patient-db-item">
                  <div style={{ width: 40, height: 40, borderRadius: "50%", background: "#0F6CBD", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 14, flexShrink: 0 }}>
                    {p.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600, fontSize: 14, color: "#242424" }}>{p.name}</div>
                    <div style={{ fontSize: 12, color: "#707070", marginTop: 2 }}>
                      NIF: {p.nif} · {p.birth ? `${calculateAge(p.birth)} anos` : ""} {p.blood ? `· ${p.blood}` : ""} {p.conditions ? `· ${p.conditions}` : ""}
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 4 }}>
                    <button className="ml-btn ml-btn-primary" style={{ fontSize: 12, padding: "4px 10px" }} onClick={() => {
                      setSelectedPatient(p);
                      setShowPatientDb(false);
                      showToast("Paciente selecionado", "success");
                    }}>Selecionar</button>
                    <button className="ml-icoBtn" title="Eliminar" style={{ color: "#c50f1f" }} onClick={() => deletePatient(p.id)}>
                      <svg viewBox="0 0 20 20" fill="currentColor"><path d="M8.5 3c-.83 0-1.5.67-1.5 1.5V5H4a1 1 0 100 2h1v9a2 2 0 002 2h6a2 2 0 002-2V7h1a1 1 0 100-2h-3v-.5c0-.83-.67-1.5-1.5-1.5h-3z"/></svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <div className="ml-modal-footer">
              <button className="ml-btn ml-btn-ghost" onClick={() => setShowPatientDb(false)}>Fechar</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════ MODAL: Novo Paciente ═══════════════ */}
      {showNewPatient && (
        <div className="ml-modal-overlay" onClick={e => { if (e.target === e.currentTarget) setShowNewPatient(false); }}>
          <div className="ml-modal ml-modal-sm" style={{ maxWidth: 520 }}>
            <div className="ml-modal-header">
              <span className="ml-modal-title">Registar Novo Paciente</span>
              <button className="ml-icoBtn" style={{ marginLeft: "auto" }} onClick={() => setShowNewPatient(false)}>
                <svg viewBox="0 0 20 20" fill="currentColor"><path d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"/></svg>
              </button>
            </div>
            <div className="ml-modal-body">
              <div className="ml-form-row">
                <div className="ml-form-field" style={{ gridColumn: "1 / -1" }}>
                  <label className="ml-form-label">Nome Completo <span className="ml-form-required">*</span></label>
                  <input className="ml-form-input" value={newPatForm.name} placeholder="Nome completo do paciente"
                    onChange={e => setNewPatForm(f => ({ ...f, name: e.target.value }))} />
                </div>
              </div>
              <div className="ml-form-row">
                <div className="ml-form-field">
                  <label className="ml-form-label">NIF / BI <span className="ml-form-required">*</span></label>
                  <input className="ml-form-input" value={newPatForm.nif} placeholder="Ex: 005478921LA045"
                    onChange={e => setNewPatForm(f => ({ ...f, nif: e.target.value }))} />
                </div>
                <div className="ml-form-field">
                  <label className="ml-form-label">Data de Nascimento <span className="ml-form-required">*</span></label>
                  <input type="date" className="ml-form-input" value={newPatForm.birth}
                    onChange={e => setNewPatForm(f => ({ ...f, birth: e.target.value }))} />
                </div>
              </div>
              <div className="ml-form-row">
                <div className="ml-form-field">
                  <label className="ml-form-label">Género</label>
                  <select className="ml-form-input" value={newPatForm.gender} onChange={e => setNewPatForm(f => ({ ...f, gender: e.target.value }))}>
                    <option value="">— Selecionar —</option>
                    <option value="M">Masculino</option>
                    <option value="F">Feminino</option>
                  </select>
                </div>
                <div className="ml-form-field">
                  <label className="ml-form-label">Grupo Sanguíneo</label>
                  <select className="ml-form-input" value={newPatForm.blood} onChange={e => setNewPatForm(f => ({ ...f, blood: e.target.value }))}>
                    <option value="">— Selecionar —</option>
                    {["A+","A-","B+","B-","AB+","AB-","O+","O-"].map(b => <option key={b}>{b}</option>)}
                  </select>
                </div>
              </div>
              <div className="ml-form-row">
                <div className="ml-form-field">
                  <label className="ml-form-label">Contacto Telefónico</label>
                  <input className="ml-form-input" value={newPatForm.phone} placeholder="+244 9XX XXX XXX"
                    onChange={e => setNewPatForm(f => ({ ...f, phone: e.target.value }))} />
                </div>
                <div className="ml-form-field" />
              </div>
              <div className="ml-form-field">
                <label className="ml-form-label">Morada</label>
                <input className="ml-form-input" value={newPatForm.address} placeholder="Morada completa"
                  onChange={e => setNewPatForm(f => ({ ...f, address: e.target.value }))} />
              </div>
              <div className="ml-form-field">
                <label className="ml-form-label">Alergias Conhecidas</label>
                <input className="ml-form-input" value={newPatForm.allergies} placeholder="Ex: Penicilina, Amendoim (separar por vírgulas)"
                  onChange={e => setNewPatForm(f => ({ ...f, allergies: e.target.value }))} />
              </div>
              <div className="ml-form-field">
                <label className="ml-form-label">Condições Crónicas</label>
                <textarea className="ml-form-textarea" value={newPatForm.conditions} placeholder="Diabetes, Hipertensão, Asma, etc."
                  style={{ minHeight: 70 }}
                  onChange={e => setNewPatForm(f => ({ ...f, conditions: e.target.value }))} />
              </div>
            </div>
            <div className="ml-modal-footer">
              <button className="ml-btn ml-btn-ghost" onClick={() => setShowNewPatient(false)}>Cancelar</button>
              <button className="ml-btn ml-btn-primary" onClick={saveNewPatient}>
                <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor"><path d="M10 2a8 8 0 100 16 8 8 0 000-16zm4.7 5.3l-5 5a1 1 0 01-1.4 0l-2-2a1 1 0 011.4-1.4L9 10.17l4.3-4.3a1 1 0 011.4 1.4z"/></svg>
                Guardar Paciente
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════ Toast ═══════════════ */}
      {toast && (
        <div className={`ml-toast${toast.type ? " " + toast.type : ""}`}>
          {toast.type === "success" && "✓ "}
          {toast.type === "danger" && "✕ "}
          {toast.msg}
        </div>
      )}
    </div>
  );
}
