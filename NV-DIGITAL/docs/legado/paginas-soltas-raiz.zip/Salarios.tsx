import { useState, useMemo } from "react";
import { useApp } from "../store/AppContext";
import { Salario } from "../store/AppContext";
import { formatCurrency } from "../store/storage";
import { Session } from "../store/auth";

const MESES = [
  "Janeiro","Fevereiro","Março","Abril","Maio","Junho",
  "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro",
];
const VINCULOS = ["Efectivo","Contrato","Prestação de Serviços","Estágio"];

function getMesAtual(): string {
  return String(new Date().getMonth() + 1).padStart(2, "0");
}
function getAnoAtual(): number {
  return new Date().getFullYear();
}

const EMPTY_FORM = { nome: "", vinculo: "Efectivo", funcao: "", salarioBase: 0, extra: 0, desconto: 0 };

export default function Salarios({ session }: { session: Session }) {
  const { data, addSalario, updateSalario, removeSalario } = useApp();
  const moeda = data.config.moeda || "AOA";

  const [mes, setMes] = useState(getMesAtual());
  const [ano, setAno] = useState(getAnoAtual());
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);

  const canEdit = ["admin", "gestor", "financeiro"].includes(session.funcao || "");

  const lista = useMemo(
    () => (data.salarios || []).filter((s) => s.mes === mes && s.ano === ano),
    [data.salarios, mes, ano]
  );

  const totalBase = lista.reduce((sum, s) => sum + s.salarioBase, 0);
  const totalExtra = lista.reduce((sum, s) => sum + s.extra, 0);
  const totalDesconto = lista.reduce((sum, s) => sum + s.desconto, 0);
  const totalLiquido = lista.reduce((sum, s) => sum + (s.salarioBase + s.extra - s.desconto), 0);

  function openAdd() {
    setEditId(null);
    setForm({ ...EMPTY_FORM });
    setShowModal(true);
  }

  function openEdit(s: Salario) {
    setEditId(s.id);
    setForm({ nome: s.nome, vinculo: s.vinculo, funcao: s.funcao, salarioBase: s.salarioBase, extra: s.extra, desconto: s.desconto });
    setShowModal(true);
  }

  async function handleSave() {
    if (!form.nome.trim()) { setMsg({ text: "Nome é obrigatório.", ok: false }); return; }
    setSaving(true);
    try {
      const payload = { ...form, mes, ano };
      if (editId !== null) await updateSalario(editId, payload);
      else await addSalario(payload);
      setMsg({ text: editId !== null ? "Salário actualizado." : "Salário registado.", ok: true });
      setShowModal(false);
    } catch (err: any) {
      setMsg({ text: err.message || "Erro ao guardar.", ok: false });
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: number) {
    if (!window.confirm("Eliminar este registo de salário?")) return;
    try {
      await removeSalario(id);
      setMsg({ text: "Registo eliminado.", ok: true });
    } catch { setMsg({ text: "Erro ao eliminar.", ok: false }); }
  }

  function setField(f: string, v: any) {
    setForm((prev) => ({ ...prev, [f]: v }));
  }

  const anos = Array.from({ length: 5 }, (_, i) => getAnoAtual() - 2 + i);

  return (
    <div className="p-5 space-y-5 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground">Salários</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {MESES[parseInt(mes, 10) - 1]} {ano} · {lista.length} {lista.length === 1 ? "registo" : "registos"}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={mes}
            onChange={(e) => setMes(e.target.value)}
            className="text-sm border border-border rounded-lg px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-primary/30"
          >
            {MESES.map((m, i) => (
              <option key={i} value={String(i + 1).padStart(2, "0")}>{m}</option>
            ))}
          </select>
          <select
            value={ano}
            onChange={(e) => setAno(Number(e.target.value))}
            className="text-sm border border-border rounded-lg px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-primary/30"
          >
            {anos.map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
          {canEdit && (
            <button
              onClick={openAdd}
              className="flex items-center gap-1.5 bg-primary text-white text-sm font-semibold px-4 py-1.5 rounded-lg hover:opacity-90 transition-opacity"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
              </svg>
              Adicionar
            </button>
          )}
        </div>
      </div>

      {/* Feedback message */}
      {msg && (
        <div className={`rounded-lg px-4 py-2.5 text-sm font-medium ${msg.ok ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-red-50 text-red-600 border border-red-200"}`}>
          {msg.text}
        </div>
      )}

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Base Total", value: formatCurrency(totalBase, moeda), color: "bg-blue-50 text-blue-700" },
          { label: "Extras", value: formatCurrency(totalExtra, moeda), color: "bg-emerald-50 text-emerald-700" },
          { label: "Descontos", value: formatCurrency(totalDesconto, moeda), color: "bg-amber-50 text-amber-700" },
          { label: "Líquido Total", value: formatCurrency(totalLiquido, moeda), color: "bg-primary/10 text-primary" },
        ].map((c) => (
          <div key={c.label} className={`rounded-xl p-4 ${c.color}`}>
            <div className="text-xs font-semibold uppercase tracking-wide opacity-70 mb-1">{c.label}</div>
            <div className="text-lg font-bold">{c.value}</div>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-border shadow-sm overflow-hidden">
        {lista.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="opacity-30 mb-3">
              <rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2"/><line x1="12" y1="12" x2="12" y2="16"/><line x1="10" y1="14" x2="14" y2="14"/>
            </svg>
            <p className="text-sm">Nenhum salário registado para {MESES[parseInt(mes, 10) - 1]} {ano}</p>
            {canEdit && (
              <button onClick={openAdd} className="mt-3 text-sm text-primary font-medium hover:underline">
                Adicionar primeiro registo
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="text-left px-4 py-2.5 font-semibold text-muted-foreground text-xs uppercase">Nome</th>
                  <th className="text-left px-4 py-2.5 font-semibold text-muted-foreground text-xs uppercase">Vínculo</th>
                  <th className="text-left px-4 py-2.5 font-semibold text-muted-foreground text-xs uppercase">Função</th>
                  <th className="text-right px-4 py-2.5 font-semibold text-muted-foreground text-xs uppercase">Base</th>
                  <th className="text-right px-4 py-2.5 font-semibold text-muted-foreground text-xs uppercase">Extra</th>
                  <th className="text-right px-4 py-2.5 font-semibold text-muted-foreground text-xs uppercase">Desconto</th>
                  <th className="text-right px-4 py-2.5 font-semibold text-muted-foreground text-xs uppercase">Líquido</th>
                  {canEdit && <th className="px-4 py-2.5" />}
                </tr>
              </thead>
              <tbody>
                {lista.map((s) => (
                  <tr key={s.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-3 font-medium text-foreground">{s.nome}</td>
                    <td className="px-4 py-3 text-muted-foreground">
                      <span className="bg-blue-50 text-blue-700 text-xs px-2 py-0.5 rounded-full font-medium">{s.vinculo}</span>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{s.funcao || "—"}</td>
                    <td className="px-4 py-3 text-right text-foreground font-mono">{formatCurrency(s.salarioBase, moeda)}</td>
                    <td className="px-4 py-3 text-right text-emerald-600 font-mono">{s.extra > 0 ? formatCurrency(s.extra, moeda) : "—"}</td>
                    <td className="px-4 py-3 text-right text-red-500 font-mono">{s.desconto > 0 ? formatCurrency(s.desconto, moeda) : "—"}</td>
                    <td className="px-4 py-3 text-right font-bold text-foreground font-mono">
                      {formatCurrency(s.salarioBase + s.extra - s.desconto, moeda)}
                    </td>
                    {canEdit && (
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1 justify-end">
                          <button onClick={() => openEdit(s)} className="p-1.5 rounded hover:bg-blue-50 text-blue-600 transition-colors" title="Editar">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 013 3L12 15l-4 1 1-4z"/>
                            </svg>
                          </button>
                          <button onClick={() => handleDelete(s.id)} className="p-1.5 rounded hover:bg-red-50 text-red-500 transition-colors" title="Eliminar">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
                            </svg>
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-muted/30 font-bold">
                  <td colSpan={3} className="px-4 py-3 text-sm text-muted-foreground">Totais ({lista.length})</td>
                  <td className="px-4 py-3 text-right font-mono">{formatCurrency(totalBase, moeda)}</td>
                  <td className="px-4 py-3 text-right text-emerald-600 font-mono">{formatCurrency(totalExtra, moeda)}</td>
                  <td className="px-4 py-3 text-right text-red-500 font-mono">{formatCurrency(totalDesconto, moeda)}</td>
                  <td className="px-4 py-3 text-right text-primary font-mono">{formatCurrency(totalLiquido, moeda)}</td>
                  {canEdit && <td />}
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-border flex items-center justify-between">
              <h2 className="font-bold text-foreground">{editId !== null ? "Editar Salário" : "Adicionar Salário"}</h2>
              <button onClick={() => setShowModal(false)} className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="px-6 py-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-muted-foreground uppercase mb-1">Nome *</label>
                <input
                  className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                  value={form.nome} onChange={(e) => setField("nome", e.target.value)} placeholder="Nome completo"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground uppercase mb-1">Vínculo</label>
                  <select className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                    value={form.vinculo} onChange={(e) => setField("vinculo", e.target.value)}>
                    {VINCULOS.map((v) => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground uppercase mb-1">Função</label>
                  <input className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                    value={form.funcao} onChange={(e) => setField("funcao", e.target.value)} placeholder="Ex: Técnico" />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground uppercase mb-1">Salário Base</label>
                  <input type="number" min="0" step="100"
                    className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                    value={form.salarioBase} onChange={(e) => setField("salarioBase", parseFloat(e.target.value) || 0)} />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground uppercase mb-1">Extra</label>
                  <input type="number" min="0" step="100"
                    className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                    value={form.extra} onChange={(e) => setField("extra", parseFloat(e.target.value) || 0)} />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-muted-foreground uppercase mb-1">Desconto</label>
                  <input type="number" min="0" step="100"
                    className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                    value={form.desconto} onChange={(e) => setField("desconto", parseFloat(e.target.value) || 0)} />
                </div>
              </div>
              <div className="bg-muted/30 rounded-lg px-4 py-2.5 flex items-center justify-between">
                <span className="text-sm font-semibold text-muted-foreground">Líquido</span>
                <span className="text-sm font-bold text-primary">
                  {formatCurrency(form.salarioBase + form.extra - form.desconto, moeda)}
                </span>
              </div>
              {msg && !msg.ok && (
                <div className="bg-red-50 text-red-600 text-sm px-3 py-2 rounded-lg border border-red-200">{msg.text}</div>
              )}
            </div>
            <div className="px-6 py-4 border-t border-border flex justify-end gap-2">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 text-sm font-medium text-muted-foreground hover:bg-muted rounded-lg transition-colors">
                Cancelar
              </button>
              <button onClick={handleSave} disabled={saving}
                className="px-5 py-2 text-sm font-semibold bg-primary text-white rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50">
                {saving ? "A guardar..." : "Guardar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
