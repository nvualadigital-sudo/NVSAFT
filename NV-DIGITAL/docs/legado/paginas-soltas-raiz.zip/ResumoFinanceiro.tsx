import { useState, useMemo } from "react";
import { useApp } from "../store/AppContext";
import { formatCurrency } from "../store/storage";
import { Session } from "../store/auth";

const MESES = [
  "Janeiro","Fevereiro","Março","Abril","Maio","Junho",
  "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro",
];

function getMesAtual(): string {
  return String(new Date().getMonth() + 1).padStart(2, "0");
}
function getAnoAtual(): number {
  return new Date().getFullYear();
}

function parseDateMes(dateStr: string): string {
  if (!dateStr) return "";
  // Handle DD/MM/YYYY format
  const parts = dateStr.split("/");
  if (parts.length === 3) return parts[1].padStart(2, "0");
  // Handle YYYY-MM-DD
  const parts2 = dateStr.split("-");
  if (parts2.length === 3) return parts2[1].padStart(2, "0");
  return "";
}
function parseDateAno(dateStr: string): number {
  if (!dateStr) return 0;
  const parts = dateStr.split("/");
  if (parts.length === 3) return Number(parts[2]);
  const parts2 = dateStr.split("-");
  if (parts2.length === 3) return Number(parts2[0]);
  return 0;
}

export default function ResumoFinanceiro({ session }: { session: Session }) {
  const { data } = useApp();
  const moeda = data.config.moeda || "AOA";

  const [mes, setMes] = useState(getMesAtual());
  const [ano, setAno] = useState(getAnoAtual());

  const anos = Array.from({ length: 5 }, (_, i) => getAnoAtual() - 2 + i);

  // Receita: faturas emitidas/pagas do mês
  const receitaBruta = useMemo(() => {
    return data.faturas
      .filter((f) => {
        const fMes = parseDateMes(f.data);
        const fAno = parseDateAno(f.data);
        return (f.estado === "emitida" || f.estado === "paga") && fMes === mes && fAno === ano;
      })
      .reduce((sum, f) => sum + Number(f.total), 0);
  }, [data.faturas, mes, ano]);

  // Receita paga (cash in hand)
  const receitaPaga = useMemo(() => {
    return data.faturas
      .filter((f) => {
        const fMes = parseDateMes(f.data);
        const fAno = parseDateAno(f.data);
        return f.estado === "paga" && fMes === mes && fAno === ano;
      })
      .reduce((sum, f) => sum + Number(f.total), 0);
  }, [data.faturas, mes, ano]);

  // Entradas manuais de conta corrente do mês
  const entradasCC = useMemo(() => {
    return data.movimentosCC
      .filter((m) => {
        const mMes = parseDateMes(m.data);
        const mAno = parseDateAno(m.data);
        return m.tipo === "entrada" && mMes === mes && mAno === ano;
      })
      .reduce((sum, m) => sum + Number(m.valor), 0);
  }, [data.movimentosCC, mes, ano]);

  // Saídas de conta corrente do mês
  const saidasCC = useMemo(() => {
    return data.movimentosCC
      .filter((m) => {
        const mMes = parseDateMes(m.data);
        const mAno = parseDateAno(m.data);
        return m.tipo === "saida" && mMes === mes && mAno === ano;
      })
      .reduce((sum, m) => sum + Number(m.valor), 0);
  }, [data.movimentosCC, mes, ano]);

  // Salários do mês
  const salariosMes = useMemo(() => {
    return (data.salarios || []).filter((s) => s.mes === mes && s.ano === ano);
  }, [data.salarios, mes, ano]);

  const totalSalarios = salariosMes.reduce((sum, s) => sum + (s.salarioBase + s.extra - s.desconto), 0);

  // Caixa = receita paga - salários - saídas CC
  const caixaLiquida = receitaPaga - totalSalarios - saidasCC;

  // Faturas do mês
  const faturasMes = useMemo(() => {
    return data.faturas.filter((f) => {
      const fMes = parseDateMes(f.data);
      const fAno = parseDateAno(f.data);
      return fMes === mes && fAno === ano;
    });
  }, [data.faturas, mes, ano]);

  const totalFaturasRascunho = faturasMes.filter((f) => f.estado === "rascunho").length;
  const totalFaturasEmitidas = faturasMes.filter((f) => f.estado === "emitida").length;
  const totalFaturasPagas = faturasMes.filter((f) => f.estado === "paga").length;

  const StatCard = ({ label, value, sub, color, icon }: { label: string; value: string; sub?: string; color: string; icon: React.ReactNode }) => (
    <div className={`rounded-xl p-5 flex items-start gap-4 ${color}`}>
      <div className="mt-0.5 flex-shrink-0">{icon}</div>
      <div>
        <div className="text-xs font-semibold uppercase tracking-wide opacity-70 mb-0.5">{label}</div>
        <div className="text-2xl font-bold">{value}</div>
        {sub && <div className="text-xs opacity-60 mt-0.5">{sub}</div>}
      </div>
    </div>
  );

  return (
    <div className="p-5 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground">Resumo Financeiro</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {MESES[parseInt(mes, 10) - 1]} {ano}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select value={mes} onChange={(e) => setMes(e.target.value)}
            className="text-sm border border-border rounded-lg px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-primary/30">
            {MESES.map((m, i) => (
              <option key={i} value={String(i + 1).padStart(2, "0")}>{m}</option>
            ))}
          </select>
          <select value={ano} onChange={(e) => setAno(Number(e.target.value))}
            className="text-sm border border-border rounded-lg px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-primary/30">
            {anos.map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
        </div>
      </div>

      {/* Main stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <StatCard
          label="Receita Bruta (Facturada)"
          value={formatCurrency(receitaBruta, moeda)}
          sub={`${faturasMes.filter(f => f.estado === "emitida" || f.estado === "paga").length} faturas emitidas/pagas`}
          color="bg-blue-50 text-blue-800"
          icon={<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>}
        />
        <StatCard
          label="Recebido (Pago)"
          value={formatCurrency(receitaPaga, moeda)}
          sub={`${totalFaturasPagas} faturas pagas`}
          color="bg-emerald-50 text-emerald-800"
          icon={<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>}
        />
        <StatCard
          label="Saídas (Salários + Despesas)"
          value={formatCurrency(totalSalarios + saidasCC, moeda)}
          sub={`${salariosMes.length} colaboradores · ${formatCurrency(saidasCC, moeda)} outras despesas`}
          color="bg-red-50 text-red-800"
          icon={<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>}
        />
      </div>

      {/* Caixa líquida - highlighted */}
      <div className={`rounded-2xl p-6 flex items-center justify-between ${caixaLiquida >= 0 ? "bg-primary text-white" : "bg-red-600 text-white"}`}>
        <div>
          <div className="text-sm font-semibold opacity-80 mb-1">Caixa Líquida do Mês</div>
          <div className="text-3xl font-bold">{formatCurrency(Math.abs(caixaLiquida), moeda)}</div>
          <div className="text-sm opacity-70 mt-1">{caixaLiquida >= 0 ? "Resultado positivo" : "Resultado negativo"}</div>
        </div>
        <div className="opacity-20">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/>
          </svg>
        </div>
      </div>

      {/* Breakdown tables side by side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Faturação breakdown */}
        <div className="bg-white rounded-xl border border-border shadow-sm">
          <div className="px-5 py-3.5 border-b border-border">
            <h3 className="font-semibold text-foreground text-sm">Faturação do Mês</h3>
          </div>
          <div className="divide-y divide-border">
            {[
              { label: "Rascunhos", count: totalFaturasRascunho, color: "text-amber-600" },
              { label: "Emitidas (por receber)", count: totalFaturasEmitidas, amount: data.faturas.filter(f => parseDateMes(f.data) === mes && parseDateAno(f.data) === ano && f.estado === "emitida").reduce((s, f) => s + Number(f.total), 0), color: "text-blue-600" },
              { label: "Pagas", count: totalFaturasPagas, amount: receitaPaga, color: "text-emerald-600" },
              { label: "Total facturado", count: faturasMes.length, amount: receitaBruta, color: "text-primary font-bold" },
            ].map((row) => (
              <div key={row.label} className="flex items-center justify-between px-5 py-3">
                <div className="flex items-center gap-2">
                  <span className={`text-sm ${row.color}`}>{row.label}</span>
                  <span className="text-xs bg-muted text-muted-foreground px-1.5 py-0.5 rounded-full">{row.count}</span>
                </div>
                {row.amount !== undefined && (
                  <span className={`text-sm font-mono font-semibold ${row.color}`}>{formatCurrency(row.amount, moeda)}</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Salários breakdown */}
        <div className="bg-white rounded-xl border border-border shadow-sm">
          <div className="px-5 py-3.5 border-b border-border flex items-center justify-between">
            <h3 className="font-semibold text-foreground text-sm">Salários do Mês</h3>
            <span className="text-xs text-muted-foreground">{salariosMes.length} colaboradores</span>
          </div>
          {salariosMes.length === 0 ? (
            <div className="flex items-center justify-center py-10 text-muted-foreground text-sm">
              Nenhum salário registado neste mês
            </div>
          ) : (
            <div className="divide-y divide-border max-h-48 overflow-y-auto">
              {salariosMes.map((s) => (
                <div key={s.id} className="flex items-center justify-between px-5 py-2.5">
                  <div>
                    <div className="text-sm font-medium text-foreground">{s.nome}</div>
                    <div className="text-xs text-muted-foreground">{s.funcao || s.vinculo}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold font-mono text-foreground">
                      {formatCurrency(s.salarioBase + s.extra - s.desconto, moeda)}
                    </div>
                    {(s.extra > 0 || s.desconto > 0) && (
                      <div className="text-xs text-muted-foreground">
                        base {formatCurrency(s.salarioBase, moeda)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
          <div className="border-t border-border px-5 py-3 flex items-center justify-between bg-muted/20">
            <span className="text-sm font-semibold text-muted-foreground">Total Salários</span>
            <span className="text-sm font-bold text-red-600 font-mono">{formatCurrency(totalSalarios, moeda)}</span>
          </div>
        </div>
      </div>

      {/* Breakdown summary box */}
      <div className="bg-white rounded-xl border border-border shadow-sm">
        <div className="px-5 py-3.5 border-b border-border">
          <h3 className="font-semibold text-foreground text-sm">Demonstração de Resultado</h3>
        </div>
        <div className="divide-y divide-border">
          {[
            { label: "Receita Recebida (paga)", value: receitaPaga, positive: true },
            { label: "Entradas extras (conta corrente)", value: entradasCC, positive: true },
            { label: "Salários pagos", value: -totalSalarios, positive: totalSalarios === 0 },
            { label: "Outras despesas (conta corrente)", value: -saidasCC, positive: saidasCC === 0 },
          ].map((row) => (
            <div key={row.label} className="flex items-center justify-between px-5 py-3">
              <span className="text-sm text-muted-foreground">{row.label}</span>
              <span className={`text-sm font-semibold font-mono ${row.value >= 0 ? "text-emerald-600" : "text-red-500"}`}>
                {row.value >= 0 ? "+" : ""}{formatCurrency(Math.abs(row.value), moeda)}
              </span>
            </div>
          ))}
          <div className="flex items-center justify-between px-5 py-4 bg-muted/20">
            <span className="font-bold text-foreground">Caixa Líquida</span>
            <span className={`text-lg font-bold font-mono ${caixaLiquida >= 0 ? "text-primary" : "text-red-600"}`}>
              {formatCurrency(caixaLiquida, moeda)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
